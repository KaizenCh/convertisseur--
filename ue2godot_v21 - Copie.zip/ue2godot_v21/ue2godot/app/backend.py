# -*- coding: utf-8 -*-
"""
Moteur de l'application — tout ce qui n'est pas de la présentation.

SÉPARATION UI / MOTEUR
-----------------------
Ce module contient l'analyse de source, la configuration, la découverte
de Godot, la copie d'assets, l'exécution distante Unreal et la
construction headless. Il ne construit AUCUN widget de mise en page.

La raison est concrète : l'interface a déjà été remplacée une fois, et le
moteur a dû être réextrait à la main d'un fichier de 6500 lignes où les
deux étaient mêlés. En les séparant, changer l'apparence ne met plus en
danger la chaîne de conversion, et le moteur reste testable sans afficher
quoi que ce soit.

Les seules dépendances Qt conservées ici sont QObject/Signal (pour émettre
la progression sans connaître son destinataire) et QProcess (pour lancer
Godot sans geler l'appelant). Aucun widget.
"""


from __future__ import annotations

import json
import os
import re
import sys
import shutil
import subprocess
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from PySide6.QtCore import QObject, QProcess, Signal
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox


import ue2godot
from ue2godot.core.config import ResolvedConfig, deep_merge, compute_config_hash
from ue2godot.orchestrator.step5_copy import copy_step5


APP_NAME = "UE5 → GODOT CONSTRUCTOR"
APP_VERSION = "0.2.0"
CONFIG_EXTENSION = ".gconstructor.json"


# ============================================================================
# PERSISTED CONFIGURATION
# ============================================================================

DEFAULT_CONFIG: dict[str, Any] = {
    "schema_version": 1,
    "project": {
        "name": "",
        "godot_project": "",
        "config_path": "",
    },
    "source": {
        "unreal_map": "",
        "export_output": "",
        # Étape 0 (ue5_preprocess_detach_all.py + break manuel des LevelInstances)
        # ne laisse aucune trace vérifiable dans le manifest (voir source de vérité,
        # §11). C'est une attestation humaine explicite, pas une case cochée par défaut.
        "preprocessing_confirmed": False,
    },
    "construction": {
        "workflow": "full_reconstruction",
        "objective": "maximum",
        "fidelity": "maximum",
        "fidelity_percent": 100,
        "modules": {
            "landscape": True,
            "materials": True,
            "decals": True,
            "lighting": True,
            "vfx": True,
            # Audio n'a jamais reçu de traitement dédié à aucun stade du pipeline
            # (ni export, ni marqueurs de type VFX_MARKERS_NOT_CONVERTED) — ce n'est
            # pas un choix assumé comme Niagara, c'est un point mort. On ne le
            # présente donc pas comme un module fonctionnel activé par défaut.
            "audio": False,
            "level_instances": True,
        },
        # Ne s'applique que si modules.vfx est coché — sinon le mode est
        # forcé à "none" (voir run_unreal_export_steps). "markers" reste
        # le défaut : jamais de reconstruction visuelle non demandée
        # explicitement (§13.C.24 — ne jamais faire croire qu'une
        # conversion a eu lieu). "substitutes" active la reconstruction
        # par particules (voir vfx_builder.gd, système partiel — pas la
        # parité complète des 12 catégories/8 lois physiques de la
        # référence, voir sa documentation en tête de fichier).
        "vfx_mode": "markers",
    },
    "advanced": {
        "transform_policy": "preserve",
        "hierarchy_policy": "preserve",
        "asset_resolution": "strict",
        "validation_mode": "strict",
        "fallback_policy": "report",
        "overwrite_policy": "safe",
        "resume_enabled": True,
        "keep_intermediate": True,
        "verbose_logs": False,
        "godot_executable": "",
        # Chemin de UnrealEditor.exe. Vide = détection automatique parmi les
        # emplacements d'installation Epic usuels (voir
        # UnrealAuthorizationManager._guess_editor_executable). À renseigner
        # si plusieurs versions du moteur sont installées : la détection
        # automatique prend la plus récente, qui n'est pas forcément celle
        # avec laquelle le projet a été créé.
        "unreal_executable": "",
        # Garde-fou anti-manifeste-vide : seuil en dessous duquel le scan
        # est abandonné SANS rien écrire (un niveau par défaut chargé par
        # erreur contient typiquement 1 à 5 acteurs). À baisser seulement
        # si vous convertissez réellement un niveau minuscule.
        "min_expected_actors": 20,
        # Charge la map cible si elle n'est pas active. Désactivé par
        # défaut : recharger un niveau perd les modifications non
        # sauvegardées, ce qu'on ne fait jamais d'autorité.
        "force_map_reload": False,
        "constructor_script": "",
        # Racine res:// où les assets exportés (Meshes/Decals + les 3 JSON) sont
        # copiés côté projet Godot. Correspond à `godot_asset_root` documenté
        # dans ue5_godot_asset_map.json.
        "godot_asset_root": "UEAssets",
        # Convention d'axe attendue (voir source de vérité §6.4/§12.4) : stockée
        # ici pour être comparée à AXIS_MAP_LABEL trouvé dans l'asset map, au lieu
        # de rester une trace de documentation jamais vérifiée.
        "expected_axis_convention": "(ue.x, ue.z, ue.y) * 0.01",
    },
    "ui": {
        "expert_mode": False,
        "theme": "dark",
    },
}


# ============================================================================
# GENERIC HELPERS
# ============================================================================

def deep_copy_config() -> dict[str, Any]:
    return json.loads(json.dumps(DEFAULT_CONFIG))


def format_number(value: int | float | None) -> str:
    if value is None:
        return "—"
    return f"{value:,}".replace(",", " ")


def now_string() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def find_first_existing(root: Path, candidates: list[str]) -> Optional[Path]:
    for relative in candidates:
        candidate = root / relative
        if candidate.exists():
            return candidate
    return None


def read_json(path: Path) -> Optional[dict[str, Any]]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def recursive_find_json(root: Path, names: set[str]) -> list[Path]:
    if not root.exists() or not root.is_dir():
        return []

    result: list[Path] = []
    try:
        for path in root.rglob("*.json"):
            if path.name in names:
                result.append(path)
    except (OSError, PermissionError):
        pass
    return result


def count_glb(root: Path) -> int:
    if not root.exists() or not root.is_dir():
        return 0

    try:
        return sum(1 for _ in root.rglob("*.glb"))
    except (OSError, PermissionError):
        return 0


def count_png(root: Path) -> int:
    if not root.exists() or not root.is_dir():
        return 0

    try:
        return sum(1 for _ in root.rglob("*.png"))
    except (OSError, PermissionError):
        return 0


# ============================================================================
# SOURCE ANALYSIS
# ============================================================================

@dataclass
class SourceInventory:
    source_root: str = ""
    manifest: str = ""
    asset_map: str = ""
    decal_map: str = ""
    mesh_directory: str = ""
    decal_directory: str = ""

    manifest_found: bool = False
    asset_map_found: bool = False
    decal_map_found: bool = False
    mesh_directory_found: bool = False

    mesh_files: int = 0
    decal_files: int = 0

    # geometry / structure (level_manifest_v10.json — voir source de vérité §4)
    placements: Optional[int] = None
    unique_meshes: Optional[int] = None
    unique_skeletal_meshes: Optional[int] = None
    skeletal_mesh_placements: Optional[int] = None
    level_instances: Optional[int] = None
    landscapes: Optional[int] = None
    lights: Optional[int] = None
    vfx: Optional[int] = None
    decals: Optional[int] = None
    audio: Optional[int] = None
    materials: Optional[int] = None

    # Contrat "reconstruction" du manifest — jamais consommé par le
    # reconstructeur .gd lui-même, mais l'orchestrateur, lui, doit le lire.
    ready_for_godot_geometry: Optional[bool] = None
    ready_for_godot_fx: Optional[bool] = None
    reconstruction_blockers: list[str] = field(default_factory=list)

    # asset map (ue5_godot_asset_map.json)
    asset_map_entries: Optional[int] = None
    asset_map_failures: Optional[int] = None
    landscape_entry_present: Optional[bool] = None
    axis_map_label: str = ""

    # decal map (ue5_godot_decal_map.json)
    decal_material_entries: Optional[int] = None
    decal_placement_total: Optional[int] = None

    manifest_version: str = ""
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    @property
    def is_detected(self) -> bool:
        return bool(self.source_root)

    @property
    def core_valid(self) -> bool:
        return (
            self.manifest_found
            and self.asset_map_found
            and self.mesh_directory_found
            and self.mesh_files > 0
        )


class SourceAnalyzer:
    """
    Structural analyzer only.

    It does not convert anything.
    It does not modify Unreal.
    It does not execute project scripts.

    Its purpose is to discover the conversion package / map source and
    summarize what is currently available, using the *real* schema of
    level_manifest_v10.json / ue5_godot_asset_map.json / ue5_godot_decal_map.json
    (see "Source de vérité" §4-5). This replaces an earlier version that
    guessed at generic-sounding field names that never actually existed in
    the manifest — it silently reported "non détecté" on real, valid data.
    """

    MANIFEST_NAMES = {
        "level_manifest_v10.json",
        "level_manifest_v9.json",
        "level_manifest_v8.json",
    }

    ASSET_MAP_NAMES = {
        "ue5_godot_asset_map.json",
    }

    DECAL_MAP_NAMES = {
        "ue5_godot_decal_map.json",
    }

    # Clé synthétique documentée pour l'entrée Landscape ajoutée par
    # unreal_export_landscape.py dans l'asset map (§5).
    LANDSCAPE_SYNTHETIC_KEY = "/AutoTerrain/Landscape.BakedLandscape"

    def analyze(self, source: str) -> SourceInventory:
        input_path = Path(source).expanduser()

        if not input_path.exists():
            inventory = SourceInventory(source_root=str(input_path))
            inventory.errors.append("Le chemin source n'existe pas.")
            return inventory

        # If a file like .umap / .uproject is selected, resolve its directory or parent export location
        if input_path.is_file():
            root = input_path.parent
        else:
            root = input_path

        # Find closest export or project directory
        curr = root
        search_roots = [root]
        for _ in range(5):
            if (curr / "level_manifest_v10.json").exists() or (curr / "GodotAssets").exists():
                root = curr
                break
            if (curr / "Export").exists():
                search_roots.append(curr / "Export")
            if curr.parent == curr:
                break
            curr = curr.parent

        inventory = SourceInventory(source_root=str(root))

        manifest = find_first_existing(
            root,
            [
                "level_manifest_v10.json",
                "manifest/level_manifest_v10.json",
                "level_manifest.json",
            ],
        )

        if manifest is None:
            matches = recursive_find_json(root, self.MANIFEST_NAMES)
            manifest = matches[0] if matches else None

        if manifest:
            inventory.manifest = str(manifest)
            inventory.manifest_found = True
            self._read_manifest(manifest, inventory)
        else:
            inventory.notes.append(
                "Manifest introuvable dans le dossier sélectionné. L'étape 1 (Manifest) générera "
                "level_manifest_v10.json à partir de cette map Unreal."
            )

        asset_map = find_first_existing(
            root,
            [
                "ue5_godot_asset_map.json",
                "GodotAssets/ue5_godot_asset_map.json",
                "assets/ue5_godot_asset_map.json",
            ],
        )

        if asset_map is None:
            matches = recursive_find_json(root, self.ASSET_MAP_NAMES)
            asset_map = matches[0] if matches else None

        if asset_map:
            inventory.asset_map = str(asset_map)
            inventory.asset_map_found = True
            self._read_asset_map(asset_map, inventory)
        else:
            inventory.notes.append(
                "Asset map introuvable (ue5_godot_asset_map.json). L'étape 2 (Meshes) générera l'asset map."
            )

        decal_map = find_first_existing(
            root,
            [
                "ue5_godot_decal_map.json",
                "GodotAssets/ue5_godot_decal_map.json",
                "assets/ue5_godot_decal_map.json",
            ],
        )

        if decal_map is None:
            matches = recursive_find_json(root, self.DECAL_MAP_NAMES)
            decal_map = matches[0] if matches else None

        if decal_map:
            inventory.decal_map = str(decal_map)
            inventory.decal_map_found = True
            self._read_decal_map(decal_map, inventory)
        # Absence de decal_map n'est pas systématiquement une erreur : toutes
        # les maps n'ont pas de decals. Le vrai contrôle (cohérence avec le
        # nombre de decals du manifest) se fait dans _cross_validate().

        mesh_dir = self._find_mesh_directory(root)
        if mesh_dir:
            inventory.mesh_directory = str(mesh_dir)
            inventory.mesh_directory_found = True
            inventory.mesh_files = count_glb(mesh_dir)
        else:
            inventory.notes.append(
                "Dossier de meshes introuvable (GodotAssets/Meshes). L'étape 2 (Meshes) exportera les GLB."
            )

        decal_dir = self._find_decal_directory(root)
        if decal_dir:
            inventory.decal_directory = str(decal_dir)
            inventory.decal_files = count_png(decal_dir)

        self._cross_validate(inventory)

        return inventory

    def _find_mesh_directory(self, root: Path) -> Optional[Path]:
        candidates = [
            root / "GodotAssets" / "Meshes",
            root / "assets" / "Meshes",
            root / "Meshes",
        ]

        for candidate in candidates:
            if candidate.exists() and candidate.is_dir():
                return candidate

        try:
            for candidate in root.rglob("Meshes"):
                if candidate.is_dir() and any(candidate.glob("*.glb")):
                    return candidate
        except (OSError, PermissionError):
            pass

        return None

    def _find_decal_directory(self, root: Path) -> Optional[Path]:
        candidates = [
            root / "GodotAssets" / "Decals",
            root / "assets" / "Decals",
            root / "Decals",
        ]

        for candidate in candidates:
            if candidate.exists() and candidate.is_dir():
                return candidate

        try:
            for candidate in root.rglob("Decals"):
                if candidate.is_dir() and any(candidate.glob("*.png")):
                    return candidate
        except (OSError, PermissionError):
            pass

        return None

    # ------------------------------------------------------------------
    # level_manifest_v10.json — voir Source de vérité §4
    # ------------------------------------------------------------------

    def _read_manifest(self, path: Path, inventory: SourceInventory) -> None:
        data = read_json(path)
        if data is None:
            inventory.errors.append("Le manifest existe mais n'est pas lisible (JSON invalide).")
            return

        # manifest_version est resté figé à "10.0" à travers 8 sous-versions
        # de correctifs de comportement (V10.1 → V10.8, voir §9/§12) : ce champ
        # ne doit pas être présenté comme un numéro de version fiable.
        inventory.manifest_version = str(data.get("manifest_version") or "inconnue")

        geometry = data.get("geometry") if isinstance(data.get("geometry"), dict) else {}
        level_instances = data.get("level_instances") if isinstance(data.get("level_instances"), dict) else {}
        materials = data.get("materials") if isinstance(data.get("materials"), dict) else {}
        effects = data.get("effects") if isinstance(data.get("effects"), dict) else {}
        world_features = data.get("world_features") if isinstance(data.get("world_features"), dict) else {}
        reconstruction = data.get("reconstruction") if isinstance(data.get("reconstruction"), dict) else {}

        inventory.unique_meshes = self._len_of(geometry.get("unique_meshes"))
        inventory.placements = self._len_of(geometry.get("placements"))
        inventory.unique_skeletal_meshes = self._len_of(geometry.get("unique_skeletal_meshes"))
        inventory.skeletal_mesh_placements = self._len_of(geometry.get("skeletal_mesh_placements"))

        inventory.level_instances = self._len_of(level_instances.get("placements"))

        inventory.materials = self._len_of(materials.get("unique_materials"))

        inventory.vfx = self._len_of(effects.get("niagara"))
        inventory.decals = self._len_of(effects.get("decals"))

        inventory.landscapes = self._len_of(world_features.get("landscape"))
        inventory.lights = self._len_of(world_features.get("lights"))
        inventory.audio = self._len_of(world_features.get("audio"))

        # Contrat formel "prêt pour Godot" (§4/§11) : le reconstructeur .gd
        # actuel ne le lit jamais, mais l'orchestrateur, lui, le doit.
        if isinstance(reconstruction.get("ready_for_godot_geometry"), bool):
            inventory.ready_for_godot_geometry = reconstruction["ready_for_godot_geometry"]
        if isinstance(reconstruction.get("ready_for_godot_fx"), bool):
            inventory.ready_for_godot_fx = reconstruction["ready_for_godot_fx"]

        for key, value in reconstruction.items():
            if key in ("ready_for_godot_geometry", "ready_for_godot_fx"):
                continue
            if isinstance(value, str) and value:
                inventory.reconstruction_blockers.append(f"{key}: {value}")
            elif isinstance(value, list) and value:
                inventory.reconstruction_blockers.append(
                    f"{key}: {len(value)} élément(s)"
                )

    # ------------------------------------------------------------------
    # ue5_godot_asset_map.json — voir Source de vérité §5
    # ------------------------------------------------------------------

    def _read_asset_map(self, path: Path, inventory: SourceInventory) -> None:
        data = read_json(path)
        if data is None:
            inventory.errors.append("L'asset map existe mais n'est pas lisible (JSON invalide).")
            return

        assets = data.get("assets") if isinstance(data.get("assets"), dict) else {}
        inventory.asset_map_entries = len(assets)

        failures = data.get("failures")
        if isinstance(failures, list):
            inventory.asset_map_failures = len(failures)

        inventory.landscape_entry_present = self.LANDSCAPE_SYNTHETIC_KEY in assets

        landscape_entry = assets.get(self.LANDSCAPE_SYNTHETIC_KEY)
        if isinstance(landscape_entry, dict):
            axis_label = landscape_entry.get("axis_map") or landscape_entry.get("axis_map_label")
            if isinstance(axis_label, str):
                inventory.axis_map_label = axis_label

    # ------------------------------------------------------------------
    # ue5_godot_decal_map.json — voir Source de vérité §5
    # ------------------------------------------------------------------

    def _read_decal_map(self, path: Path, inventory: SourceInventory) -> None:
        data = read_json(path)
        if data is None:
            inventory.errors.append("La decal map existe mais n'est pas lisible (JSON invalide).")
            return

        decal_materials = data.get("decal_materials") if isinstance(data.get("decal_materials"), dict) else {}
        inventory.decal_material_entries = len(decal_materials)

        total = data.get("decal_placement_total")
        if isinstance(total, int) and not isinstance(total, bool):
            inventory.decal_placement_total = total

    # ------------------------------------------------------------------
    # Vérifications croisées — automatisent ce qui était documenté comme
    # "contrôle manuel" dans la source de vérité (§1, §9, §10, §12, §13.C.25)
    # ------------------------------------------------------------------

    def _cross_validate(self, inventory: SourceInventory) -> None:
        # 1. Comptage GLB physiques vs. registre déclaré. Le Landscape ajoute
        #    1 entrée synthétique à l'asset map mais son GLB est écrit à la
        #    main (pas forcément dans le même dossier), donc on tolère +1.
        if inventory.asset_map_entries is not None and inventory.mesh_files:
            expected_min = inventory.asset_map_entries - (1 if inventory.landscape_entry_present else 0)
            if inventory.mesh_files < expected_min:
                inventory.errors.append(
                    f"L'asset map référence {inventory.asset_map_entries} assets, mais seulement "
                    f"{inventory.mesh_files} fichiers GLB sont présents sur disque : au moins "
                    f"{expected_min - inventory.mesh_files} export(s) manquant(s) ou déplacé(s)."
                )
            elif inventory.mesh_files > inventory.asset_map_entries:
                inventory.warnings.append(
                    f"{inventory.mesh_files} fichiers GLB présents pour {inventory.asset_map_entries} "
                    "entrées déclarées dans l'asset map — des GLB orphelins (anciens exports) "
                    "traînent peut-être dans le dossier Meshes."
                )

        # 2. Cohérence manifest.geometry.unique_meshes <-> asset_map.assets
        #    (documentée comme contrôle manuel au §1 : "L'orchestrateur devrait
        #    automatiser cette vérification.")
        if inventory.unique_meshes is not None and inventory.asset_map_entries is not None:
            expected = inventory.unique_meshes + (1 if inventory.landscape_entry_present else 0)
            if inventory.asset_map_entries != expected:
                inventory.errors.append(
                    f"Incohérence manifest ↔ asset map : {inventory.unique_meshes} unique_meshes "
                    f"dans le manifest, {inventory.asset_map_entries} entrées dans l'asset map "
                    f"(attendu {expected}). Ordre d'exécution probablement rompu : le manifest ou "
                    "l'export des meshes a peut-être été relancé après une autre étape, écrasant "
                    "un travail précédent (voir §1 de la source de vérité — étapes 1/2 réécrivent "
                    "leur JSON from scratch)."
                )

        if inventory.asset_map_failures:
            inventory.warnings.append(
                f"{inventory.asset_map_failures} échec(s) d'export signalés dans l'asset map."
            )

        # 3. Landscape déclaré dans le manifest mais jamais bake côté asset map.
        if (inventory.landscapes or 0) > 0 and inventory.asset_map_found and not inventory.landscape_entry_present:
            inventory.warnings.append(
                "Le manifest décrit un Landscape mais aucune entrée Landscape "
                f"({self.LANDSCAPE_SYNTHETIC_KEY}) n'est présente dans l'asset map — "
                "unreal_export_landscape.py n'a probablement pas été exécuté (ou a été "
                "exécuté avant une relance du manifest/asset map, qui l'a écrasé)."
            )

        # 4. Decals déclarés dans le manifest mais decal map absente/vide.
        if (inventory.decals or 0) > 0:
            if not inventory.decal_map_found:
                inventory.warnings.append(
                    f"{inventory.decals} decal(s) déclaré(s) dans le manifest mais "
                    "ue5_godot_decal_map.json est introuvable — unreal_export_decals_vfx.py "
                    "n'a probablement pas été exécuté."
                )
            elif not inventory.decal_files:
                inventory.warnings.append(
                    "La decal map est présente mais aucun PNG n'a été trouvé dans le dossier Decals."
                )

        # 5. SkeletalMesh : capturés dans le manifest mais jamais exportés en
        #    GLB par le pipeline actuel (trou connu, §9 point 4).
        if (inventory.unique_skeletal_meshes or 0) > 0:
            inventory.warnings.append(
                f"Le manifest référence {inventory.unique_skeletal_meshes} SkeletalMesh unique(s) "
                f"({inventory.skeletal_mesh_placements or 0} placement(s)), mais l'exporteur actuel "
                "n'exporte que les StaticMesh en GLB : ces éléments seront absents de la scène "
                "reconstruite tant que ce trou n'est pas comblé côté export."
            )

        # 6. Audio : point mort non tranché du pipeline (§13.C.25). On ne le
        #    passe jamais sous silence dans l'interface.
        if (inventory.audio or 0) > 0:
            inventory.notes.append(
                f"{inventory.audio} élément(s) audio détecté(s) dans le manifest. Le pipeline actuel "
                "ne les exporte ni ne les marque comme non convertis : ils seront simplement absents "
                "de la scène reconstruite (choix non tranché, pas une conversion silencieuse)."
            )

        # 7. Contrat "prêt pour Godot" jamais consulté par le reconstructeur
        #    lui-même — l'orchestrateur doit être le premier à s'y fier.
        if inventory.ready_for_godot_geometry is False:
            inventory.errors.append(
                "Le manifest indique lui-même reconstruction.ready_for_godot_geometry = false : "
                "au moins un échec de transform, de mesh manquant, de Level Instance ou d'instance "
                "ISM/HISM a été détecté côté scan Unreal."
            )
        if inventory.ready_for_godot_fx is False:
            inventory.warnings.append(
                "Le manifest indique reconstruction.ready_for_godot_fx = false : les décals/VFX "
                "risquent d'être incomplets ou absents."
            )

        # 8. Convention d'axe : stockée dans l'asset map mais historiquement
        #    jamais comparée à quoi que ce soit (§10, §12.4). On la remonte au
        #    moins comme information affichée plutôt qu'enfouie dans le JSON.
        if inventory.axis_map_label:
            inventory.notes.append(
                f"Convention d'axe déclarée par le Landscape bake : {inventory.axis_map_label}"
            )

        if inventory.manifest_found and inventory.asset_map_found:
            inventory.notes.append(
                f"Manifest détecté : manifest_version={inventory.manifest_version or 'inconnue'} "
                "(ce champ n'a historiquement jamais changé entre correctifs — ne pas s'y fier "
                "seul pour dater le fichier)."
            )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _len_of(value: Any) -> Optional[int]:
        """Longueur d'un dict/list JSON, sans jamais inventer de chiffre."""
        if isinstance(value, (dict, list)):
            return len(value)
        return None


# ============================================================================
# PIPELINE MODEL
# ============================================================================

@dataclass
class PipelineStep:
    key: str
    label: str
    description: str
    state: str = "pending"
    detail: str = ""


# Ordre RÉEL de dépendance des données (voir source de vérité §1/§10) :
# manifest et meshes RÉÉCRIVENT leurs JSON en entier à chaque exécution ;
# landscape et decals ne font qu'APPEND dessus. Landscape doit donc
# systématiquement venir après manifest+meshes, jamais avant — une version
# antérieure de cette liste plaçait "landscape" avant "manifest", ce qui ne
# correspondait à aucune fonction réelle du dépôt (il n'existe qu'un seul
# step3_landscape.run(), qui lit et patche un manifest supposé déjà exister).
# Cette liste est construite dynamiquement par run_unreal_export_steps() —
# voir _build_pipeline_step_list() — pour rester la source de vérité sur
# l'ordre, plutôt qu'une déclaration statique qui peut diverger du code.
def _build_pipeline_step_list() -> list["PipelineStep"]:
    return [
        PipelineStep("preprocess", "Prétraitement UE5",
                     "Détacher les acteurs (KEEP_WORLD) ; les LevelInstances "
                     "restantes doivent être cassées à la main dans l'éditeur."),
        PipelineStep("manifest", "Manifest",
                     "Scanner la map et produire level_manifest_v10.json (réécrit "
                     "en entier)."),
        PipelineStep("meshes", "Meshes",
                     "Exporter les StaticMesh uniques en GLB (réécrit ue5_godot_"
                     "asset_map.json en entier)."),
        PipelineStep("landscape", "Landscape",
                     "Assigner/vérifier le matériau du Landscape, puis reconstruire "
                     "sa géométrie et bake sa texture (append sur les 2 JSON)."),
        PipelineStep("decals", "Decals / VFX",
                     "Résoudre les textures de décal et placer les marqueurs VFX/"
                     "audio (append)."),
        PipelineStep("crosscheck", "Vérification croisée",
                     "Comparer run_id/compte d'assets entre les 3 JSON avant toute "
                     "reconstruction Godot."),
    ]


# ============================================================================
# FUTURE ORCHESTRATOR CONTRACT
# ============================================================================

class OrchestratorAdapter(QObject):
    """
    Integration boundary between the PySide6 UI and the real Godot side.

    The UE5 -> Godot reconstruction ALGORITHM is NOT duplicated here — it
    remains entirely in the existing Godot EditorScript. What this adapter
    DOES really execute (real file I/O, not a simulation) is the part the
    source of truth documents as "étape 5 : copie manuelle" (§1, §11) :
    copying the exported Meshes/Decals + the 3 JSON files into the target
    Godot project, then opening that project. Everything after that point
    (the actual scene construction) is a manual step inside Godot, and is
    presented as such rather than faked.
    """

    log = Signal(str)
    progress = Signal(int)
    step_changed = Signal(str)
    finished = Signal(dict)
    failed = Signal(str)

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.process: Optional[subprocess.Popen] = None
        # Compteurs de la dernière copie réelle — capturés pour que l'UI
        # puisse afficher autre chose qu'un texte générique une fois
        # l'étape terminée (voir MainWindow._on_orchestrator_finished).
        self.last_copy_stats: dict[str, int] = {}
        # État de la construction headless (entry_headless.gd), voir
        # build_scene_headless() — QProcess plutôt que subprocess.run pour
        # ne jamais geler l'UI le temps de l'import + de la construction,
        # qui peuvent prendre plusieurs dizaines de secondes sur une grosse
        # map.
        self._headless_proc: Optional[QProcess] = None
        self._headless_plan: dict[str, Any] = {}
        self.last_build_report: dict[str, Any] = {}

    # Emplacements Windows habituels où Godot est installé sans être ajouté
    # au PATH (winget, installeur manuel, portable dézippé dans un dossier
    # perso). Complète la recherche PATH, ne la remplace pas.
    _COMMON_INSTALL_DIRS = (
        r"C:\Godot",
        r"C:\Program Files\Godot",
        r"C:\Program Files (x86)\Godot",
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Godot"),
        os.path.expandvars(r"%USERPROFILE%\Downloads"),
        os.path.expandvars(r"%USERPROFILE%\Desktop"),
    )

    @staticmethod
    def read_project_godot_version(project_root: str) -> Optional[str]:
        """Version majeure.mineure de Godot déclarée par le projet cible.

        Lue depuis `config/features` dans project.godot (ex: PackedStringArray
        ("4.7", "Forward Plus")). Ouvrir un projet 4.7 avec un binaire 4.3
        provoque une migration ou un refus silencieux ; construire avec une
        version différente de celle qui ouvrira la scène est une source
        d'incohérence qu'il vaut mieux détecter que subir.
        """
        if not project_root:
            return None
        cfg = Path(project_root) / "project.godot"
        if not cfg.is_file():
            return None
        try:
            text = cfg.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None
        match = re.search(r'config/features\s*=\s*PackedStringArray\(([^)]*)\)', text)
        if match:
            for token in re.findall(r'"([^"]+)"', match.group(1)):
                if re.fullmatch(r"\d+\.\d+", token):
                    return token
        match = re.search(r'config_version\s*=\s*(\d+)', text)
        if match and match.group(1) == "5":
            return "4"
        return None

    @staticmethod
    def executable_version(path: str) -> Optional[str]:
        """Version majeure.mineure déduite du NOM du binaire Godot.

        Les builds officiels embarquent leur version dans le nom
        (Godot_v4.7.2-stable_win64.exe). On ne lance pas le binaire pour la
        lire : ce serait plus fiable mais coûterait un démarrage de processus
        à chaque recherche, et le nom suffit pour les builds officiels — les
        seuls pour lesquels la détection automatique opère de toute façon.
        """
        match = re.search(r'[vV]?(\d+)\.(\d+)', Path(path).name)
        return f"{match.group(1)}.{match.group(2)}" if match else None

    @classmethod
    def find_godot(cls, executable: str = "", log: Optional[Any] = None,
                   project_root: str = "") -> Optional[str]:
        """Résolution de l'exécutable Godot — délègue à godot_version.

        IMPLÉMENTATION UNIQUE. Une seconde recherche vivait ici, en
        parallèle du module `orchestrator/godot_version.py` qui fait la
        même chose en mieux (comparaison de version avec le projet cible,
        trace des candidats écartés) — et c'est la copie d'ici qui
        tournait, si bien que corriger l'autre n'aurait rien changé.
        C'est le troisième doublon de ce type trouvé dans ce dépôt ; il
        est fusionné comme les précédents.

        La signature est conservée pour ne casser aucun appelant.
        """
        from ue2godot.orchestrator.godot_version import resolve_godot

        resolution = resolve_godot(
            godot_project_root=project_root,
            configured_executable=executable,
        )

        if log is not None:
            for line in resolution.trace:
                log(f"[find_godot] {line}")
            # Un désaccord de version ne bloque pas — l'utilisateur peut
            # avoir de bonnes raisons — mais il doit être dit, parce que le
            # symptôme apparaît bien plus loin sous une forme qui n'évoque
            # jamais « mauvaise version de moteur ».
            if resolution.executable and not resolution.is_version_safe:
                log(f"[find_godot] ATTENTION : {resolution.summary()}")

        return resolution.executable

    def prepare(self, config: dict[str, Any], inventory: SourceInventory) -> dict[str, Any]:
        selected_modules = [
            key for key, enabled in config["construction"]["modules"].items()
            if enabled
        ]
        return {
            "created_at": now_string(),
            "source": inventory.source_root,
            "manifest": inventory.manifest,
            "asset_map": inventory.asset_map,
            "decal_map": inventory.decal_map,
            "mesh_directory": inventory.mesh_directory,
            "decal_directory": inventory.decal_directory,
            "godot_project": config["project"]["godot_project"],
            "godot_asset_root": config["advanced"].get("godot_asset_root", "UEAssets"),
            "constructor_script": config["advanced"].get("constructor_script", ""),
            "godot_executable": config["advanced"].get("godot_executable", ""),
            "objective": config["construction"]["objective"],
            "fidelity": config["construction"]["fidelity"],
            "modules": selected_modules,
            "overwrite_policy": config["advanced"].get("overwrite_policy", "safe"),
            "fallback_policy": config["advanced"].get("fallback_policy", "report"),
            "resume_enabled": bool(config["advanced"].get("resume_enabled", True)),
            "keep_intermediate": bool(config["advanced"].get("keep_intermediate", True)),
            "verbose_logs": bool(config["advanced"].get("verbose_logs", False)),
            "decals_selected": bool(config["construction"]["modules"].get("decals", False)),
        }

    # ------------------------------------------------------------------
    # ÉTAPE 5 — copie des assets exportés vers le projet Godot cible.
    #
    # Documentée comme "entièrement manuelle aujourd'hui" dans la source de
    # vérité (§1, §11). C'est la seule partie du pipeline UE5 -> Godot que
    # cet orchestrateur automatise réellement lui-même (le reste reste dans
    # le .gd, un EditorScript qui ne peut pas être piloté sans intervention
    # manuelle dans l'éditeur — voir §2, §11).
    # ------------------------------------------------------------------

    def copy_assets(self, plan: dict[str, Any]) -> bool:
        project = Path(plan.get("godot_project", "")).expanduser()
        if not project.is_dir() or not (project / "project.godot").is_file():
            self.failed.emit("Projet Godot invalide ou project.godot introuvable.")
            return False

        source_root = plan.get("source", "")
        cfg_dict = {
            "paths": {
                "ue_export_root": source_root,
                "godot_project_root": str(project),
                "godot_asset_root": plan.get("godot_asset_root", "res://UEAssets")
            }
        }
        # La copie n'exploite pas les conventions de pack, mais le profil
        # est tout de même résolu : le config_hash doit correspondre à celui
        # des étapes Unreal, sinon la vérification croisée les déclarerait
        # divergentes alors que rien n'a changé.
        from ue2godot.profiles.loader import load_profile, detect_profile_for_source
        profile = load_profile(plan.get("profile") or detect_profile_for_source(source_root))
        res_cfg = ResolvedConfig.resolve(cfg_dict, profile, {})

        self.log.emit(f"[copy] source : {source_root}")
        self.log.emit(f"[copy] destination : {project}")
        report = copy_step5(res_cfg)

        copied = report.counters.get("files_copied", 0)
        errors = report.errors

        # Tous les compteurs de l'étape, pas seulement le total : c'est la
        # différence entre "172 fichiers" et "172 fichiers dont 0 JSON", qui
        # est précisément le genre d'écart qu'on cherche en débogage.
        for key, value in report.counters.items():
            self.log.emit(f"[copy] {key} = {value}")
        for warning in report.warnings:
            self.log.emit(f"[copy] ⚠ {warning}")
        for error in errors:
            self.log.emit(f"[copy] ✕ {error}")

        self.last_copy_stats = {"copied": copied, "skipped": 0, "errors": len(errors)}

        if report.status == "FAILED":
            self.failed.emit(f"Échec de la copie step5: {', '.join(errors)}")
            return False

        self.log.emit(f"Step 5 Copy (ue2godot) terminée : {copied} fichier(s) copié(s) et vérifié(s).")

        # Le constructeur Godot n'est pas un fichier de l'export Unreal :
        # il fait partie du framework livré avec cette application.
        # Step 5 copie les données produites par Unreal, mais doit aussi
        # déployer dans le projet cible le runtime Godot réellement invoqué
        # par l'étape headless. Sans cette copie, l'appel suivant à
        # res://addons/ue2godot/entry_headless.gd échoue simplement parce que
        # le script n'existe pas dans le projet cible.
        framework_root = Path(__file__).resolve().parent / "godot" / "addons" / "ue2godot"
        target_addon = project / "addons" / "ue2godot"
        entry_headless = framework_root / "entry_headless.gd"

        if not entry_headless.is_file():
            self.failed.emit(
                f"Runtime Godot du framework introuvable : {entry_headless}"
            )
            return False

        try:
            copied_runtime = 0
            for src in framework_root.rglob("*"):
                if not src.is_file():
                    continue
                rel = src.relative_to(framework_root)
                dst = target_addon / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                copied_runtime += 1

            deployed_entry = target_addon / "entry_headless.gd"
            if not deployed_entry.is_file():
                self.failed.emit(
                    "Déploiement du runtime Godot incomplet : entry_headless.gd est absent du projet cible."
                )
                return False

            self.log.emit(
                f"Runtime Godot ue2godot déployé : {copied_runtime} fichier(s) dans {target_addon}."
            )
        except (OSError, shutil.Error) as exc:
            self.failed.emit(f"Déploiement du runtime Godot impossible : {exc}")
            return False

        return True

    def open_godot(self, plan: dict[str, Any]) -> bool:
        project = Path(plan.get("godot_project", "")).expanduser()
        if not project.is_dir() or not (project / "project.godot").is_file():
            self.failed.emit("Projet Godot invalide ou project.godot introuvable.")
            return False

        godot = self.find_godot(plan.get("godot_executable", ""), log=self.log.emit,
                                project_root=plan.get("godot_project", ""))
        if not godot:
            self.failed.emit(
                "Godot n'a pas été trouvé. Configure l'exécutable dans les options avancées."
            )
            return False

        self.step_changed.emit("godot_open")

        try:
            self.process = subprocess.Popen(
                [godot, "--editor", "--path", str(project)],
                cwd=str(project),
            )
        except OSError as exc:
            self.failed.emit(f"Impossible de lancer Godot : {exc}")
            return False

        self.log.emit(f"Godot ouvert : {project}")
        script = plan.get("constructor_script", "")
        if script:
            self.log.emit(f"Constructeur sélectionné : {script}")
            self.log.emit(
                "Le constructeur est un EditorScript : son exécution reste effectuée depuis Godot "
                "(FileSystem → clic droit sur le script → Run), comme prévu par le script existant. "
                "Cet orchestrateur ne le lance pas à ta place."
            )
        else:
            self.log.emit(
                "Aucun EditorScript explicite configuré. Le projet Godot a été ouvert sans lancer de logique supplémentaire."
            )
        self.step_changed.emit("done")
        self.finished.emit({"opened": True, "project": str(project)})
        return True

    def execute(self, plan: dict[str, Any]) -> None:
        # Réellement exécuté : copie des données exportées, déploiement du
        # runtime Godot livré avec le framework, puis lancement de la
        # construction headless. Rien n'est simulé.
        if not self.copy_assets(plan):
            return
        self.open_godot(plan)

    # ------------------------------------------------------------------
    # ÉTAPE 6 (optionnelle) — construction headless via entry_headless.gd.
    #
    # godot/addons/ue2godot/entry_headless.gd et
    # ue2godot.orchestrator.adapters.godot_cli.GodotCLIAdapter existaient
    # tous les deux, correctement écrits, mais n'étaient appelés par rien
    # dans tout le dépôt (ANALYSE_PROFONDE_S15 §15.5/§15.6) — la
    # reconstruction de scène restait donc systématiquement présentée
    # comme "manuelle : clic droit → Run dans l'éditeur Godot", alors que
    # le point d'entrée headless qui rend ce clic inutile existe. Cette
    # méthode l'utilise réellement, en deux passes (--import puis
    # --script), sans jamais prétendre que la scène est bonne avant d'avoir
    # vérifié la présence réelle du .tscn sur disque (voir §10 de la
    # source de vérité : pas de code de retour fiable à travers l'éditeur,
    # donc c'est le fichier de sortie qui fait foi, pas le seul exit code).
    # ------------------------------------------------------------------

    def build_scene_headless(self, plan: dict[str, Any]) -> bool:
        project = Path(plan.get("godot_project", "")).expanduser()
        if not project.is_dir() or not (project / "project.godot").is_file():
            self.failed.emit("Projet Godot invalide ou project.godot introuvable.")
            return False

        godot = self.find_godot(plan.get("godot_executable", ""), log=self.log.emit,
                                project_root=plan.get("godot_project", ""))
        if not godot:
            self.failed.emit(
                "Godot n'a pas été trouvé. Configure l'exécutable dans les options avancées."
            )
            return False

        manifest_path = plan.get("manifest", "")
        if not manifest_path:
            self.failed.emit("Aucun manifest détecté — impossible de lancer la construction headless.")
            return False

        entry_script = project / "addons" / "ue2godot" / "entry_headless.gd"
        if not entry_script.is_file():
            self.failed.emit(
                "Runtime Godot absent du projet cible : res://addons/ue2godot/entry_headless.gd. "
                "Le déploiement du constructeur doit être effectué avant la construction headless."
            )
            return False

        self._headless_plan = dict(plan)
        self._headless_plan["_godot_exe"] = godot
        self._headless_plan["_project_path"] = str(project)

        self.step_changed.emit("headless_import")
        self.log.emit(f"Import headless des assets dans {project}…")

        self._headless_proc = QProcess(self)
        self._headless_proc.setWorkingDirectory(str(project))
        self._headless_proc.readyReadStandardOutput.connect(self._on_headless_stdout)
        self._headless_proc.readyReadStandardError.connect(self._on_headless_stdout)
        self._headless_proc.finished.connect(self._on_headless_import_finished)
        import_args = ["--headless", "--path", str(project), "--import"]
        self.log.emit(f"[cmd] {godot} {' '.join(import_args)}")
        self._headless_proc.start(godot, import_args)
        return True

    def _on_headless_stdout(self) -> None:
        if self._headless_proc is None:
            return
        data = bytes(self._headless_proc.readAllStandardOutput()).decode("utf-8", errors="replace")
        data += bytes(self._headless_proc.readAllStandardError()).decode("utf-8", errors="replace")
        for line in data.splitlines():
            if line.strip():
                self.log.emit(line.strip())

    def _on_headless_import_finished(self, exit_code: int, _exit_status) -> None:
        try:
            self._headless_proc.finished.disconnect(self._on_headless_import_finished)
        except (RuntimeError, TypeError):
            pass

        self.log.emit(f"[cmd] import headless terminé, code de retour {exit_code}")
        if exit_code != 0:
            self.failed.emit(
                f"L'import headless des assets a échoué (code {exit_code}). "
                "Vérifie que l'exécutable Godot configuré correspond bien à la version du projet."
            )
            return

        project = self._headless_plan.get("_project_path", "")
        godot = self._headless_plan.get("_godot_exe", "")
        # Le manifest à passer est celui COPIÉ dans le projet Godot
        # (res://level_manifest_v10.json, écrit par step5_copy à la racine
        # du projet), jamais le chemin d'export côté Unreal (plan["manifest"]) —
        # entry_headless.gd tourne avec --path <projet>, donc son res://
        # résout dans le projet Godot, pas dans C:/Export. Passer le chemin
        # d'export par erreur ferait échouer le chargement du manifest côté
        # Godot alors que le fichier existe bel et bien, juste au mauvais
        # endroit pour ce processus.
        manifest_path = "res://level_manifest_v10.json"
        report_path = str(Path(project) / "ue2godot_build_report.json")

        self.step_changed.emit("headless_build")
        self.log.emit("Import terminé — construction de la scène (entry_headless.gd)…")

        self._headless_proc = QProcess(self)
        self._headless_proc.setWorkingDirectory(project)
        self._headless_proc.readyReadStandardOutput.connect(self._on_headless_stdout)
        self._headless_proc.readyReadStandardError.connect(self._on_headless_stdout)
        self._headless_proc.finished.connect(self._on_headless_build_finished)
        build_args = [
            "--headless", "--path", project,
            "--script", "res://addons/ue2godot/entry_headless.gd", "--",
            "--manifest", manifest_path,
            "--report", report_path,
        ]
        self.log.emit(f"[cmd] {godot} {' '.join(build_args)}")
        self._headless_proc.start(godot, build_args)

    def _on_headless_build_finished(self, exit_code: int, _exit_status) -> None:
        try:
            self._headless_proc.finished.disconnect(self._on_headless_build_finished)
        except (RuntimeError, TypeError):
            pass

        project = self._headless_plan.get("_project_path", "")
        report_path = Path(project) / "ue2godot_build_report.json"
        self.log.emit(f"[cmd] construction headless terminée, code de retour {exit_code}")

        report: dict[str, Any] = {}
        if report_path.is_file():
            report = read_json(report_path) or {}

        # La source de vérité qui compte n'est jamais le seul code de
        # retour du processus Godot (§10 : pas de code fiable à travers
        # l'éditeur) — c'est la présence réelle du .tscn déclaré dans le
        # rapport. Un exit_code à 0 avec un rapport "FAILED" ou un fichier
        # de scène absent n'est PAS un succès.
        self.last_build_report = report

        # Le rapport de construction est LE document qui explique un résultat
        # vide. L'enfouir dans un fichier obligeait à aller le lire à la main ;
        # il est désormais déplié dans le journal, déclaré contre construit.
        if report:
            declared = report.get("declared", {})
            stats = report.get("stats", {})
            self.log.emit(f"[build] statut : {report.get('status', '?')}")
            if declared:
                self.log.emit(
                    "[build] déclaré par le manifeste — "
                    + ", ".join(f"{k}={v}" for k, v in declared.items())
                )
            if stats:
                self.log.emit(
                    "[build] réellement construit — "
                    + ", ".join(f"{k}={v}" for k, v in stats.items())
                )
            self.log.emit(f"[build] nœuds dans la scène : {report.get('built_nodes', 0)}")
            for warning in report.get("warnings", []):
                self.log.emit(f"[build] ⚠ {warning}")
            for error in report.get("errors", []):
                self.log.emit(f"[build] ✕ {error}")
        else:
            self.log.emit(
                f"[build] AUCUN rapport lu à {report_path} — le script de "
                "construction n'a probablement pas atteint sa fin."
            )

        report_status = report.get("status", "UNKNOWN")
        output_scene = report.get("output_scene", "")
        scene_exists = bool(output_scene) and (Path(project) / output_scene.replace("res://", "")).is_file()

        if exit_code != 0 or report_status not in ("OK", "OK_WITH_WARNINGS") or not scene_exists:
            reasons = []
            if exit_code != 0:
                reasons.append(f"code de sortie Godot {exit_code}")
            if report_status != "OK":
                reasons.append(f"rapport de construction : {report_status}")
                for err in report.get("errors", []):
                    reasons.append(err)
            if output_scene and not scene_exists:
                reasons.append(f"le fichier de scène déclaré ({output_scene}) est introuvable sur disque")
            if not report:
                reasons.append(f"aucun rapport lu à {report_path}")
            self.failed.emit("Construction headless échouée — " + " ; ".join(reasons))
            return

        stats = report.get("stats", {})
        self.step_changed.emit("done")
        self.finished.emit({
            "built": True, "project": project,
            "output_scene": output_scene, "stats": stats,
        })


# ============================================================================
# CUSTOM WIDGETS
# ============================================================================

