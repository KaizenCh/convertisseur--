"""Le branchement UI ↔ moteur, vérifié sans afficher de fenêtre.

Ces tests existent parce que l'interface a déjà été remplacée une fois :
ils garantissent que la nouvelle mise en page appelle bien le moteur, et
qu'aucune action n'est redevenue un simple aperçu visuel.
"""
import os
import sys
import unittest
import importlib.util

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def load_main():
    spec = importlib.util.spec_from_file_location("ue2godot_main",
                                                  os.path.join(ROOT, "main.py"))
    module = importlib.util.module_from_spec(spec)
    sys.modules["ue2godot_main"] = module
    spec.loader.exec_module(module)
    return module


class TestBackendSeparation(unittest.TestCase):
    def test_backend_imports_without_any_ui(self):
        from ue2godot.app.backend import OrchestratorAdapter, SourceAnalyzer
        self.assertTrue(callable(SourceAnalyzer))
        self.assertTrue(hasattr(OrchestratorAdapter, "copy_assets"))
        self.assertTrue(hasattr(OrchestratorAdapter, "build_scene_headless"))
        self.assertTrue(hasattr(OrchestratorAdapter, "find_godot"))

    def test_backend_declares_no_layout_widgets(self):
        # Le moteur ne doit importer aucun widget de mise en page : c'est
        # ce qui permet de rechanger d'interface sans y toucher.
        source = open(os.path.join(ROOT, "ue2godot", "app", "backend.py"),
                      encoding="utf-8").read()
        for forbidden in ("QVBoxLayout", "QHBoxLayout", "QMainWindow",
                          "QFrame", "QLabel(", "QPushButton("):
            self.assertNotIn(forbidden, source,
                             f"le moteur ne doit pas manipuler {forbidden}")


class TestWiring(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module = load_main()
        from PySide6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication(sys.argv)

    def setUp(self):
        self.window = self.module.MainWindow()
        self.module.QMessageBox.warning = staticmethod(lambda *a, **k: None)
        self.module.QMessageBox.information = staticmethod(lambda *a, **k: None)

    def test_engine_is_instantiated(self):
        self.assertTrue(hasattr(self.window, "orchestrator"))
        self.assertTrue(hasattr(self.window, "source_analyzer"))
        self.assertIn("construction", self.window.config)

    def test_no_placeholder_button_remains_wired_to_actions(self):
        source = open(os.path.join(ROOT, "main.py"), encoding="utf-8").read()
        # La classe peut subsister ; ce qui ne doit plus exister, c'est son
        # usage sur un point d'action.
        uses = [line for line in source.splitlines()
                if "PlaceholderButton(" in line and "class PlaceholderButton" not in line]
        self.assertEqual(uses, [], f"boutons encore factices : {uses}")

    def test_actions_degrade_gracefully_without_configuration(self):
        for name in ("run_verification", "run_unreal_exports", "run_godot_build",
                     "open_godot_project", "open_output_folder", "show_build_report"):
            with self.subTest(action=name):
                getattr(self.window, name)()  # ne doit pas lever

    def test_text_fields_drive_the_configuration(self):
        self.window.enter_advanced_mode()
        self.window.source_input.setText("/tmp/source-x")
        self.assertEqual(self.window.config["source"]["unreal_map"], "/tmp/source-x")
        self.window.project_input.setText("/tmp/godot-x")
        self.assertEqual(self.window.config["project"]["godot_project"], "/tmp/godot-x")

    def test_log_events_are_recorded_and_capped(self):
        for index in range(20):
            self.window.log_event(f"m{index}", "info", "test")
        self.assertGreaterEqual(len(self.window._central_log_entries), 20)

    def test_engine_output_reaches_the_log_without_explicit_launch(self):
        # La connexion doit être permanente : une action déclenchée hors
        # d'un lancement explicite doit quand même laisser une trace.
        before = len(self.window._central_log_entries)
        self.window.orchestrator.log.emit("message moteur")
        self.assertGreater(len(self.window._central_log_entries), before)

    def test_engine_noise_is_classified_not_dropped(self):
        self.window.orchestrator.log.emit("[  42% ] reimport | x.glb")
        last = self.window._central_log_entries[-1]
        self.assertEqual(last["level"], "engine")

    def test_all_advanced_pages_build(self):
        self.window.enter_advanced_mode()
        for index in range(5):
            with self.subTest(page=index):
                self.window.select_page(index)

    def test_every_workflow_can_be_selected(self):
        for workflow in self.module.WORKFLOWS:
            with self.subTest(workflow=workflow.key):
                self.window.select_workflow(workflow.key)

    def test_module_flags_map_to_real_config_keys(self):
        flags = self.window._module_flags()
        for key in flags:
            self.assertIn(key, self.window.config["construction"]["modules"])

    def test_vfx_mode_maps_to_framework_values(self):
        self.assertIn(self.window._vfx_mode(), ("markers", "substitutes", "none"))

    def test_plan_carries_the_paths_the_engine_needs(self):
        self.window.config["source"]["unreal_map"] = "/tmp/src"
        self.window.config["project"]["godot_project"] = "/tmp/gd"
        plan = self.window._build_plan()
        for key in ("source", "godot_project", "godot_asset_root"):
            self.assertIn(key, plan)
        self.assertTrue(plan["godot_asset_root"].startswith("res://"))


if __name__ == "__main__":
    unittest.main()
