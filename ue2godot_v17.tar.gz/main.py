
from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QFont, QPainter, QPen, QColor
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QMessageBox,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QRadioButton,
    QPushButton,
    QScrollArea,
    QSplitter,
    QSizePolicy,
    QStackedWidget,
    QTextEdit,
    QToolButton,
    QVBoxLayout,
    QWidget,
)


# ============================================================================
# UE2GODOT STUDIO
# ============================================================================
#
# PURE UI / UX PREVIEW
#
# This file is intentionally standalone.
#
# It DOES NOT:
#   - import the UE2Godot framework
#   - inspect an Unreal project
#   - inspect a Godot project
#   - scan directories
#   - read manifests
#   - read asset maps
#   - execute Unreal
#   - execute Godot
#   - create files
#   - modify projects
#   - perform reconstruction
#
# Every action is a visual placeholder.
#
# The purpose of this file is to visualize the FINAL desktop application
# architecture before reconnecting the real business logic.
#
# FINAL UX STRUCTURE
#
#   01 ACTION
#   02 PROJECT & CONFIGURATION
#   03 PIPELINE
#
# Global shell:
#   - collapsible sidebar
#   - collapsible context inspector
#   - global log drawer
#   - persistent status bar
#   - single dark/light visual language
#   - guided Simple Mode for non-technical users
#   - full Advanced Mode retained without omission
#
# ============================================================================


APP_NAME = "UE2Godot Studio"
APP_VERSION = "UI / UX Preview"


# ----------------------------------------------------------------------
# MOTEUR — branchement réel
#
# Cette interface était un prototype visuel : chaque bouton ouvrait une
# boîte « Preview only ». Le moteur de conversion vit dans
# ue2godot.app.backend et n'a AUCUNE dépendance à cette mise en page ;
# c'est ce qui permet de rebrancher une interface sans mettre en danger la
# chaîne de conversion.
# ----------------------------------------------------------------------
from ue2godot.app.backend import (
    OrchestratorAdapter, SourceAnalyzer, SourceInventory,
    DEFAULT_CONFIG, deep_copy_config, read_json, now_string, format_number,
)
from ue2godot.orchestrator import operations as ops


# ============================================================================
# DATA
# ============================================================================


@dataclass(frozen=True)
class Workflow:
    key: str
    number: str
    title: str
    subtitle: str
    description: str
    accent: str
    modules: tuple[str, ...]


WORKFLOWS = (
    Workflow(
        key="full",
        number="01",
        title="Full Reconstruction",
        subtitle="Complete UE5 → Godot",
        description=(
            "Reconstruct the complete prepared scene while preserving the "
            "available framework capabilities and validation path."
        ),
        accent="#8b7cff",
        modules=(
            "Manifest",
            "Assets",
            "Landscape",
            "Materials",
            "Decals",
            "Lighting",
            "VFX",
            "Audio",
            "Level Instances",
            "Godot",
            "Validation",
        ),
    ),
    Workflow(
        key="assets",
        number="02",
        title="Assets",
        subtitle="Geometry & exported assets",
        description=(
            "Focus on the prepared asset reconstruction path without forcing "
            "unrelated reconstruction modules."
        ),
        accent="#5c9cff",
        modules=(
            "Manifest",
            "Static Meshes",
            "Skeletal Meshes",
            "Godot",
            "Validation",
        ),
    ),
    Workflow(
        key="landscape",
        number="03",
        title="Landscape",
        subtitle="Terrain reconstruction",
        description=(
            "Focus the workflow around the Landscape reconstruction path and "
            "its required source data."
        ),
        accent="#4fc39b",
        modules=(
            "Manifest",
            "Assets",
            "Landscape",
            "Bake",
            "Godot",
            "Validation",
        ),
    ),
    Workflow(
        key="specialized",
        number="04",
        title="Specialized Modules",
        subtitle="Focused environment conversion",
        description=(
            "Expose specialized conversion capabilities such as materials, "
            "decals, VFX and audio without forcing the complete workflow."
        ),
        accent="#e4a94d",
        modules=(
            "Materials",
            "Decals",
            "VFX",
            "Audio",
            "Validation",
        ),
    ),
    Workflow(
        key="custom",
        number="05",
        title="Custom Pipeline",
        subtitle="Compose your reconstruction",
        description=(
            "Select the capabilities needed for the current reconstruction "
            "and visualize their dependencies before execution."
        ),
        accent="#dc7181",
        modules=(
            "Manifest",
            "Assets",
            "Landscape",
            "Materials",
            "Decals",
            "VFX",
            "Audio",
            "Godot",
            "Validation",
        ),
    ),
)


MODULE_INFO = {
    "Manifest": (
        "Scene structure",
        "Provides the structural source of truth for placements, hierarchy "
        "and exported scene information.",
    ),
    "Static Meshes": (
        "Static geometry",
        "Resolves prepared static mesh assets and their scene placements.",
    ),
    "Skeletal Meshes": (
        "Skeletal geometry",
        "Represents the prepared skeletal asset conversion path.",
    ),
    "Landscape": (
        "Terrain reconstruction",
        "Rebuilds the prepared Landscape representation and supporting data.",
    ),
    "Materials": (
        "Material conversion",
        "Represents the material conversion surface available to the pipeline.",
    ),
    "Decals": (
        "Decal conversion",
        "Represents decal materials and textures in the specialized pipeline.",
    ),
    "Lighting": (
        "Lighting representation",
        "Represents lighting-related reconstruction information exposed by "
        "the framework.",
    ),
    "VFX": (
        "Visual effects",
        "Represents Niagara/VFX marker or substitute handling available "
        "through the framework.",
    ),
    "Audio": (
        "Audio representation",
        "Represents audio marker handling. This preview does not claim "
        "full 3D audio parity.",
    ),
    "Level Instances": (
        "Level Instance structure",
        "Represents Level Instance placement and hierarchy information.",
    ),
    "Godot": (
        "Godot construction",
        "Constructs the resulting Godot scene from the prepared data.",
    ),
    "Validation": (
        "Validation & report",
        "Checks the resulting process and exposes the final report surface.",
    ),
}


# ============================================================================
# COMMON UI
# ============================================================================


class PlaceholderButton(QPushButton):
    """
    Button used exclusively for visual interaction.

    It never touches the filesystem or framework.
    """

    def __init__(self, text: str, parent: Optional[QWidget] = None):
        super().__init__(text, parent)
        self.clicked.connect(self._preview)

    def _preview(self):
        QMessageBox.information(
            self,
            "Preview only",
            "This control is intentionally visual.\n\n"
            "No framework, project or external file is accessed.",
        )


class Surface(QFrame):
    """
    Main visual surface.

    Deliberately uses generous internal padding so nested content never
    touches the edges.
    """

    def __init__(
        self,
        title: str = "",
        subtitle: str = "",
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)
        self.setObjectName("surface")

        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(22, 20, 22, 22)
        self.root.setSpacing(14)

        if title:
            header = QHBoxLayout()
            header.setSpacing(12)

            title_label = QLabel(title)
            title_label.setObjectName("surfaceTitle")
            header.addWidget(title_label)

            if subtitle:
                subtitle_label = QLabel(subtitle)
                subtitle_label.setObjectName("surfaceSubtitle")
                header.addWidget(subtitle_label)

            header.addStretch()
            self.root.addLayout(header)

    def content(self):
        return self.root


class Pill(QLabel):
    def __init__(
        self,
        text: str,
        kind: str = "neutral",
        parent: Optional[QWidget] = None,
    ):
        super().__init__(text, parent)
        self.setObjectName(f"pill_{kind}")


class EmptyState(QFrame):
    def __init__(
        self,
        title: str,
        description: str,
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)
        self.setObjectName("emptyState")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(8)

        title_label = QLabel(title)
        title_label.setObjectName("emptyTitle")
        layout.addWidget(title_label)

        desc = QLabel(description)
        desc.setObjectName("muted")
        desc.setWordWrap(True)
        layout.addWidget(desc)


# ============================================================================
# WORKFLOW CARD
# ============================================================================


class WorkflowCard(QFrame):
    selected = Signal(str)

    def __init__(self, workflow: Workflow):
        super().__init__()
        self.workflow = workflow

        self.setObjectName("workflowCard")
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(235)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 22)
        layout.setSpacing(13)

        # Header
        header = QHBoxLayout()
        header.setSpacing(12)

        number = QLabel(workflow.number)
        number.setObjectName("workflowNumber")
        header.addWidget(number)

        title = QLabel(workflow.title)
        title.setObjectName("workflowTitle")
        header.addWidget(title)

        header.addStretch()

        badge = Pill("PREVIEW", "preview")
        header.addWidget(badge)

        layout.addLayout(header)

        subtitle = QLabel(workflow.subtitle)
        subtitle.setObjectName("workflowSubtitle")
        layout.addWidget(subtitle)

        description = QLabel(workflow.description)
        description.setObjectName("workflowDescription")
        description.setWordWrap(True)
        layout.addWidget(description)

        layout.addStretch()

        # Module summary
        module_row = QHBoxLayout()
        module_row.setSpacing(6)

        visible = workflow.modules[:6]

        for module in visible:
            chip = QLabel(module)
            chip.setObjectName("moduleChip")
            module_row.addWidget(chip)

        if len(workflow.modules) > len(visible):
            more = QLabel(f"+{len(workflow.modules) - len(visible)}")
            more.setObjectName("moduleChip")
            module_row.addWidget(more)

        module_row.addStretch()
        layout.addLayout(module_row)

        action = QLabel("Configure workflow  →")
        action.setObjectName("cardAction")
        layout.addWidget(action)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.selected.emit(self.workflow.key)
        super().mousePressEvent(event)


# ============================================================================
# SIDEBAR
# ============================================================================


class Sidebar(QFrame):
    pageSelected = Signal(int)

    def __init__(self):
        super().__init__()

        self.setObjectName("sidebar")
        self.expanded = True

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 18, 14, 14)
        layout.setSpacing(7)

        brand = QLabel("UE2G")
        brand.setObjectName("brand")
        layout.addWidget(brand)

        brand_name = QLabel("UE2Godot Studio")
        brand_name.setObjectName("brandName")
        self.brandName = brand_name
        layout.addWidget(brand_name)

        workflow_label = QLabel("WORKFLOW")
        workflow_label.setObjectName("sidebarSection")
        layout.addWidget(workflow_label)

        layout.addSpacing(5)

        self.buttons = []

        pages = (
            ("01", "Action", "Choose what you want to reconstruct."),
            ("02", "Setup", "Project, sources and configuration."),
            ("03", "Pipeline", "Execution, validation and result."),
            ("04", "Result", "Final reconstruction summary and report."),
        )

        for index, (number, title, tooltip) in enumerate(pages):
            button = QToolButton()
            button.setObjectName("navButton")
            button.setCheckable(True)
            button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            button.setText(f"{number}   {title}")
            button.setToolTip(tooltip)
            button.clicked.connect(
                lambda checked=False, i=index: self.pageSelected.emit(i)
            )

            layout.addWidget(button)
            self.buttons.append(button)

        layout.addSpacing(18)

        self.current_title = QLabel("CURRENT")
        self.current_title.setObjectName("sidebarSection")
        layout.addWidget(self.current_title)

        self.current_workflow = QLabel("Full Reconstruction")
        self.current_workflow.setObjectName("sidebarCurrent")
        self.current_workflow.setWordWrap(True)
        layout.addWidget(self.current_workflow)

        layout.addStretch()

        state = QFrame()
        state.setObjectName("sidebarState")

        state_layout = QVBoxLayout(state)
        state_layout.setContentsMargins(12, 12, 12, 12)
        state_layout.setSpacing(5)

        state_title = QLabel("APPLICATION")
        state_title.setObjectName("sidebarStateTitle")
        state_layout.addWidget(state_title)

        ready = QLabel("●  Ready")
        ready.setObjectName("readyText")
        state_layout.addWidget(ready)

        preview = QLabel("Standalone preview")
        preview.setObjectName("muted")
        state_layout.addWidget(preview)

        layout.addWidget(state)

        self.toggle_button = QPushButton("Hide Sidebar")
        self.toggle_button.setObjectName("sidebarToggle")
        self.toggle_button.setToolTip("Show / hide the left navigation sidebar")
        layout.addWidget(self.toggle_button)

        hint = QLabel("UI / UX PREVIEW")
        hint.setObjectName("sidebarHint")
        hint.setAlignment(Qt.AlignCenter)
        layout.addWidget(hint)

    def set_current_page(self, index: int):
        for i, button in enumerate(self.buttons):
            button.setChecked(i == index)

    def set_workflow(self, workflow: Workflow):
        self.current_workflow.setText(workflow.title)

    def set_expanded(self, expanded: bool):
        self.expanded = expanded

        self.brandName.setVisible(expanded) if hasattr(
            self, "brandName"
        ) else None


# ============================================================================
# CONTEXT INSPECTOR
# ============================================================================


class ContextPanel(QFrame):
    moduleSelected = Signal(str)

    def __init__(self):
        super().__init__()

        self.setObjectName("contextPanel")
        self.current_module = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        header = QHBoxLayout()

        title = QLabel("CONTEXT")
        title.setObjectName("panelTitle")
        header.addWidget(title)

        header.addStretch()

        self.hide_button = QPushButton("Hide")
        self.hide_button.setObjectName("panelToggle")
        self.hide_button.setToolTip("Show / hide the right context sidebar")
        header.addWidget(self.hide_button)

        badge = Pill("LIVE PREVIEW", "preview")
        header.addWidget(badge)

        layout.addLayout(header)

        self.workflow_title = QLabel("Full Reconstruction")
        self.workflow_title.setObjectName("contextWorkflow")
        self.workflow_title.setWordWrap(True)
        layout.addWidget(self.workflow_title)

        self.workflow_description = QLabel(
            "Complete UE5 → Godot reconstruction"
        )
        self.workflow_description.setObjectName("muted")
        self.workflow_description.setWordWrap(True)
        layout.addWidget(self.workflow_description)

        layout.addSpacing(5)

        separator = QFrame()
        separator.setObjectName("separator")
        separator.setFixedHeight(1)
        layout.addWidget(separator)

        section = QLabel("CURRENT MODULE")
        section.setObjectName("eyebrow")
        layout.addWidget(section)

        self.module_title = QLabel("No module selected")
        self.module_title.setObjectName("contextModuleTitle")
        self.module_title.setWordWrap(True)
        layout.addWidget(self.module_title)

        self.module_desc = QLabel(
            "Select a module from the configuration surface to inspect "
            "its purpose and current visual state."
        )
        self.module_desc.setObjectName("contextDescription")
        self.module_desc.setWordWrap(True)
        layout.addWidget(self.module_desc)

        self.module_state = Pill("NOT SELECTED", "neutral")
        layout.addWidget(self.module_state)

        layout.addStretch()

        note = QFrame()
        note.setObjectName("contextNote")

        note_layout = QVBoxLayout(note)
        note_layout.setContentsMargins(14, 14, 14, 14)
        note_layout.setSpacing(6)

        note_title = QLabel("Preview boundary")
        note_title.setObjectName("noteTitle")
        note_layout.addWidget(note_title)

        note_text = QLabel(
            "This panel is informational only. "
            "No real framework operation is triggered."
        )
        note_text.setObjectName("muted")
        note_text.setWordWrap(True)
        note_layout.addWidget(note_text)

        layout.addWidget(note)

    def set_workflow(self, workflow: Workflow):
        self.workflow_title.setText(workflow.title)
        self.workflow_description.setText(workflow.subtitle)

    def set_module(self, module: str):
        self.current_module = module

        title, description = MODULE_INFO.get(
            module,
            ("Module", "No description available."),
        )

        self.module_title.setText(title)
        self.module_desc.setText(description)
        self.module_state.setText("SELECTED")


# ============================================================================
# GLOBAL LOG DRAWER
# ============================================================================


class LogDrawer(QFrame):
    def __init__(self):
        super().__init__()

        self.setObjectName("logDrawer")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(9)

        header = QHBoxLayout()
        header.setSpacing(8)

        title = QLabel("GLOBAL LOGS")
        title.setObjectName("panelTitle")
        header.addWidget(title)

        badge = Pill("ACTIVITY TIMELINE", "neutral")
        header.addWidget(badge)

        header.addStretch()

        self.hide_button = QPushButton("Hide")
        self.hide_button.setObjectName("panelToggle")
        self.hide_button.setToolTip("Show / hide the global log timeline")
        header.addWidget(self.hide_button)

        self.filter_buttons = []
        for text in ("All", "Info", "Warnings", "Errors"):
            button = QPushButton(text)
            button.setObjectName("logFilter")
            button.clicked.connect(
                lambda checked=False, value=text: self.apply_filter(value)
            )
            header.addWidget(button)
            self.filter_buttons.append(button)

        clear = QPushButton("Clear")
        clear.setObjectName("smallButton")
        clear.clicked.connect(self.clear)
        header.addWidget(clear)
        layout.addLayout(header)

        body = QHBoxLayout()
        body.setSpacing(12)

        self.timeline = QListWidget()
        self.timeline.setObjectName("activityTimeline")
        self.timeline.setMinimumWidth(440)

        events = (
            ("22:41:02", "PREPROCESS", "✓", "Source context normalized and preparation checks completed."),
            ("22:41:14", "MANIFEST", "✓", "Scene structure prepared: 58 Level Instances and 7,872 placements."),
            ("22:42:08", "MESH EXPORT", "✓", "166 unique mesh resources prepared for the reconstruction preview."),
            ("22:43:21", "LANDSCAPE", "✓", "Terrain reconstruction stage completed in preview mode."),
            ("22:44:02", "SPECIALIZED", "✓", "Materials, VFX, decals, audio and lighting markers processed."),
            ("22:44:18", "GODOT IMPORT", "✓", "Prepared scene data handed to the Godot build stage."),
            ("22:45:31", "GODOT BUILD", "✓", "Scene construction completed successfully in preview."),
            ("22:45:39", "VALIDATION", "✓", "Structure, assets, placements and scene generation validated."),
        )
        for timestamp, stage, state, detail in events:
            item = QListWidgetItem(f"{timestamp}   {stage:<16} {state}")
            item.setData(Qt.UserRole, detail)
            self.timeline.addItem(item)

        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        self.detail.setObjectName("activityDetail")
        self.detail.setPlainText("Select an activity to inspect its preview details.")

        self.timeline.currentItemChanged.connect(self.show_event_detail)
        self.timeline.setCurrentRow(0)

        body.addWidget(self.timeline, 1)
        body.addWidget(self.detail, 1)
        layout.addLayout(body, 1)

    def show_event_detail(self, current, previous=None):
        if current is None:
            self.detail.setPlainText("No activity selected.")
            return
        self.detail.setPlainText(str(current.data(Qt.UserRole)))

    def add(self, message: str):
        item = QListWidgetItem(f"preview       INFO             · {message}")
        item.setData(Qt.UserRole, message)
        self.timeline.addItem(item)
        self.timeline.setCurrentItem(item)

    def apply_filter(self, value: str):
        self.detail.setPlainText(f"Log filter selected: {value}\n\nActivity filtering is preview-only.")

    def clear(self):
        self.timeline.clear()
        self.detail.setPlainText("[preview] Activity timeline cleared.")


# ============================================================================
# ADVANCED / EXPERT
# ============================================================================


class AdvancedDialog(QDialog):
    """
    Advanced configuration surface.

    The controls are intentionally local-only in this standalone build, but
    they now behave like real settings: values are loaded from the main
    configuration, can be changed, and are persisted back into the UI state.
    The future framework adapter can consume the same dictionary without
    changing this dialog.
    """

    FIELDS = (
        ("Transform & Hierarchy", "Axis conversion, world transforms and hierarchy handling.",
         "transform", ("UE5 world transforms", "Preserve hierarchy", "Flatten hierarchy")),
        ("Asset Resolution", "Manifest references, asset-map resolution and fallback policy.",
         "asset_resolution", ("Strict manifest", "Flexible matching", "Best effort")),
        ("Validation", "Strictness, consistency checks and report behaviour.",
         "validation", ("Strict", "Standard", "Fast")),
        ("Fallback", "Behaviour when a prepared resource cannot be resolved.",
         "fallback", ("Block", "Warn & continue", "Skip")),
        ("Output & Overwrite", "Destination policy and overwrite strategy.",
         "output", ("Safe / no overwrite", "Ask before overwrite", "Overwrite")),
        ("Resume & Intermediate Data", "Pipeline continuation and intermediate-state representation.",
         "resume", ("Enabled", "Disabled")),
        ("Godot Runtime", "Editor/headless construction and runtime-facing settings.",
         "runtime", ("Editor", "Headless", "Auto")),
        ("Logging", "Verbosity, categories and diagnostic output.",
         "logging", ("Normal", "Detailed", "Debug")),
    )

    DEFAULTS = {
        "transform": "UE5 world transforms",
        "asset_resolution": "Strict manifest",
        "validation": "Standard",
        "fallback": "Warn & continue",
        "output": "Safe / no overwrite",
        "resume": "Enabled",
        "runtime": "Auto",
        "logging": "Normal",
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.owner = parent
        self.setWindowTitle("Advanced / Expert")
        self.resize(820, 660)
        self.controls = {}

        current = dict(getattr(parent, "advanced_config", self.DEFAULTS))

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 26, 28, 26)
        root.setSpacing(18)

        header = QVBoxLayout()
        header.setSpacing(5)
        title = QLabel("Advanced / Expert")
        title.setObjectName("dialogTitle")
        header.addWidget(title)
        subtitle = QLabel(
            "These settings are now stored as part of the UI configuration. "
            "The real framework can consume them later through the integration layer."
        )
        subtitle.setObjectName("muted")
        subtitle.setWordWrap(True)
        header.addWidget(subtitle)
        root.addLayout(header)

        scroll_content = QWidget()
        grid = QGridLayout(scroll_content)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)

        for i, (name, description, key, options) in enumerate(self.FIELDS):
            card = QFrame()
            card.setObjectName("expertCard")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(16, 15, 16, 15)
            card_layout.setSpacing(7)

            title_label = QLabel(name)
            title_label.setObjectName("expertTitle")
            card_layout.addWidget(title_label)

            desc = QLabel(description)
            desc.setObjectName("muted")
            desc.setWordWrap(True)
            card_layout.addWidget(desc)

            combo = QComboBox()
            combo.addItems(options)
            combo.setCurrentText(current.get(key, self.DEFAULTS[key]))
            self.controls[key] = combo
            card_layout.addWidget(combo)
            grid.addWidget(card, i // 2, i % 2)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidget(scroll_content)
        root.addWidget(scroll, 1)

        bottom = QHBoxLayout()
        summary = QLabel("Changes stay local until you press Apply.")
        summary.setObjectName("muted")
        bottom.addWidget(summary)
        bottom.addStretch()

        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        bottom.addWidget(cancel)

        apply_button = QPushButton("Apply settings")
        apply_button.setObjectName("primaryButton")
        apply_button.clicked.connect(self.apply_settings)
        bottom.addWidget(apply_button)
        root.addLayout(bottom)

    def apply_settings(self):
        values = {key: combo.currentText() for key, combo in self.controls.items()}
        if self.owner is not None:
            self.owner.advanced_config = values
            self.owner.advanced_configured = len(values)
            self.owner._sync_configuration_summary()
            self.owner._sync_pipeline_configuration_summary()
            self.owner.logs.add("Advanced configuration updated.")
        self.accept()


# ============================================================================
# PIPELINE VISUALIZATION
# ============================================================================


PIPELINE_DEFINITION = (
    ("01", "UE5 Source", "source"),
    ("02", "Preprocess", "preprocess"),
    ("03", "Manifest", "manifest"),
    ("04", "Assets", "assets"),
    ("05", "Landscape", "landscape"),
    ("06", "Specialized", "specialized"),
    ("07", "Godot Build", "godot"),
    ("08", "Validation", "validation"),
    ("09", "Result", "result"),
)


class DependencyGraphWidget(QWidget):
    """
    Visual dependency graph for the custom pipeline.

    This is still a UI preview: it does not inspect or execute the framework.
    The graph is intentionally explicit so dependency reasons remain visible.
    """

    moduleClicked = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(310)
        self.selected_modules = set()
        self.setCursor(Qt.ArrowCursor)

    def set_modules(self, modules):
        self.selected_modules = set(modules)
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            # Keep the graph informational in preview mode.
            self.moduleClicked.emit("Dependency graph")
        super().mousePressEvent(event)

    def _node_state(self, key):
        if key in {"manifest", "godot", "validation"}:
            return "READY"
        if key in self.selected_modules or (
            key == "assets" and ("Assets" in self.selected_modules or "Static Meshes" in self.selected_modules)
        ):
            return "SELECTED"
        if key == "landscape" and "Landscape" in self.selected_modules:
            return "SELECTED"
        if key == "specialized" and any(
            m in self.selected_modules for m in ("Materials", "Decals", "Lighting", "VFX", "Audio")
        ):
            return "SELECTED"
        if key in {"preprocess", "result", "source"}:
            return "READY"
        return "AVAILABLE"

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w = self.width()
        h = self.height()

        bg = QColor("#151a23")
        border = QColor("#2a303c")
        node_bg = QColor("#191e28")
        node_selected = QColor("#202633")
        text = QColor("#e8ebef")
        muted = QColor("#7e8797")
        accent = QColor("#8b7cff")
        ready = QColor("#91d0b3")
        connector = QColor("#465062")

        painter.fillRect(self.rect(), bg)

        # Compact, responsive 3-level layout.
        node_w = min(190, max(145, int(w * 0.18)))
        node_h = 72
        gap_x = max(22, int((w - 3 * node_w) / 4))
        x1 = gap_x
        x2 = (w - node_w) // 2
        x3 = w - gap_x - node_w

        positions = {
            "manifest": (x1, 28),
            "assets": (x2, 105),
            "landscape": (x3, 105),
            "specialized": (x1, 105),
            "godot": (x2, 205),
            "validation": (x3, 205),
        }

        # Correct the visual grouping so Specialized occupies the left branch.
        positions["assets"] = (x2, 105)
        positions["landscape"] = (x3, 105)
        positions["specialized"] = (x1, 205)
        positions["godot"] = (x2, 205)
        positions["validation"] = (x3, 205)

        edges = (
            ("manifest", "assets"),
            ("manifest", "landscape"),
            ("manifest", "specialized"),
            ("assets", "godot"),
            ("landscape", "godot"),
            ("specialized", "godot"),
            ("godot", "validation"),
        )

        def center(key):
            x, y = positions[key]
            return x + node_w / 2, y + node_h / 2

        def bottom(key):
            x, y = positions[key]
            return x + node_w / 2, y + node_h

        def top(key):
            x, y = positions[key]
            return x + node_w / 2, y

        painter.setPen(QPen(connector, 2))
        for source, target in edges:
            sx, sy = bottom(source)
            tx, ty = top(target)
            mid_y = (sy + ty) / 2
            painter.drawLine(sx, sy, sx, mid_y)
            painter.drawLine(sx, mid_y, tx, mid_y)
            painter.drawLine(tx, mid_y, tx, ty)

            # Arrow head.
            painter.drawLine(tx, ty, tx - 4, ty - 7)
            painter.drawLine(tx, ty, tx + 4, ty - 7)

        labels = {
            "manifest": ("MANIFEST", "Source of truth"),
            "assets": ("MESH ASSETS", "Requires Manifest"),
            "landscape": ("LANDSCAPE", "Requires Manifest"),
            "specialized": ("SPECIALIZED", "Selected modules"),
            "godot": ("GODOT BUILD", "Requires prepared data"),
            "validation": ("VALIDATION", "Requires Godot Build"),
        }

        for key, (title, subtitle) in labels.items():
            x, y = positions[key]
            state = self._node_state(key)
            fill = node_selected if state == "SELECTED" else node_bg
            painter.setBrush(fill)
            painter.setPen(QPen(accent if state == "SELECTED" else border, 1))
            painter.drawRoundedRect(x, y, node_w, node_h, 9, 9)

            painter.setPen(text)
            painter.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
            painter.drawText(x + 12, y + 23, title)

            painter.setPen(muted)
            painter.setFont(QFont("Segoe UI", 8))
            painter.drawText(x + 12, y + 42, subtitle)

            painter.setPen(ready if state == "READY" else accent if state == "SELECTED" else muted)
            painter.setFont(QFont("Segoe UI", 7, QFont.Weight.Bold))
            painter.drawText(x + 12, y + 59, state)


class PipelineStageCard(QFrame):
    """Compact clickable pipeline block with state, detail and optional progress."""

    stageClicked = Signal(str, str, str, str, str)

    def __init__(
        self,
        number: str,
        title: str,
        state: str,
        detail: str,
        metric: str = "",
        progress: int | None = None,
        parent=None,
    ):
        super().__init__(parent)
        self.setObjectName("pipelineStageCard")
        self._stage_number = number
        self._stage_title = title
        self._stage_state = state
        self._stage_detail = detail
        self._stage_metric = metric
        self.setCursor(Qt.PointingHandCursor)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 13, 15, 13)
        layout.setSpacing(7)

        header = QHBoxLayout()
        number_label = QLabel(number)
        number_label.setObjectName("pipelineStageNumber")
        header.addWidget(number_label)

        title_label = QLabel(title)
        title_label.setObjectName("pipelineStageTitle")
        header.addWidget(title_label)
        header.addStretch()

        state_kind = {
            "COMPLETED": "ready",
            "RUNNING": "running",
            "PENDING": "neutral",
            "BLOCKED": "blocked",
            "READY": "ready",
        }.get(state, "neutral")
        header.addWidget(Pill(state, state_kind))
        layout.addLayout(header)

        detail_label = QLabel(detail)
        detail_label.setObjectName("pipelineStageDetail")
        detail_label.setWordWrap(True)
        layout.addWidget(detail_label)

        if progress is not None:
            progress_row = QHBoxLayout()
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(progress)
            bar.setTextVisible(False)
            bar.setObjectName("pipelineProgress")
            progress_row.addWidget(bar, 1)

            value = QLabel(f"{progress}%")
            value.setObjectName("pipelineProgressValue")
            progress_row.addWidget(value)
            layout.addLayout(progress_row)

        if metric:
            metric_label = QLabel(metric)
            metric_label.setObjectName("pipelineStageMetric")
            metric_label.setWordWrap(True)
            layout.addWidget(metric_label)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.stageClicked.emit(
                self._stage_number,
                self._stage_title,
                self._stage_state,
                self._stage_detail,
                self._stage_metric,
            )
        super().mousePressEvent(event)


class ReadinessItem(QFrame):
    def __init__(self, label: str, state: str, detail: str, blocking: bool = False, parent=None):
        super().__init__(parent)
        self.setObjectName("readinessItem")

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(10)

        icon = QLabel("✕" if state == "BLOCKING" else "⚠" if state == "WARNING" else "✓")
        icon.setObjectName(
            "readinessBlocking" if state == "BLOCKING"
            else "readinessWarning" if state == "WARNING"
            else "readinessReady"
        )
        icon.setFixedWidth(18)
        layout.addWidget(icon)

        info = QVBoxLayout()
        info.setSpacing(2)

        title = QLabel(label)
        title.setObjectName("readinessTitle")
        info.addWidget(title)

        desc = QLabel(detail)
        desc.setObjectName("muted")
        desc.setWordWrap(True)
        info.addWidget(desc)

        layout.addLayout(info, 1)

        kind = "blocked" if state == "BLOCKING" else "warning" if state == "WARNING" else "ready"
        layout.addWidget(Pill(state, kind))


class ReadinessCenter(QFrame):
    """Preflight-style visual readiness summary; preview-only."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("readinessCenter")

        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(18, 17, 18, 17)
        self.root.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("RECONSTRUCTION READINESS")
        title.setObjectName("surfaceTitle")
        header.addWidget(title)
        header.addStretch()

        self.global_state = Pill("READY TO BUILD", "ready")
        header.addWidget(self.global_state)
        self.root.addLayout(header)

        self.items_layout = QVBoxLayout()
        self.items_layout.setSpacing(7)
        self.root.addLayout(self.items_layout)

    def set_state(self, items):
        while self.items_layout.count():
            item = self.items_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        blocking = sum(1 for item in items if item[1] == "BLOCKING")
        warnings = sum(1 for item in items if item[1] == "WARNING")

        if blocking:
            self.global_state.setText(f"{blocking} BLOCKING ITEM{'S' if blocking != 1 else ''}")
            self.global_state.setObjectName("pill_blocked")
        elif warnings:
            self.global_state.setText(f"{warnings} WARNING{'S' if warnings != 1 else ''}")
            self.global_state.setObjectName("pill_warning")
        else:
            self.global_state.setText("READY TO BUILD")
            self.global_state.setObjectName("pill_ready")
        self.global_state.style().unpolish(self.global_state)
        self.global_state.style().polish(self.global_state)

        for label, state, detail in items:
            self.items_layout.addWidget(ReadinessItem(label, state, detail))


# ============================================================================
# CONFIGURATION / VALIDATION SURFACES
# ============================================================================

PRESETS = (
    (
        "maximum",
        "Maximum Fidelity",
        "Full reconstruction / all supported modules",
        "full",
        "Maximum",
    ),
    (
        "balanced",
        "Balanced",
        "Geometry + landscape + essential modules",
        "landscape",
        "Balanced",
    ),
    (
        "geometry",
        "Geometry Only",
        "Mesh reconstruction",
        "assets",
        "High",
    ),
    (
        "custom",
        "Custom",
        "User-defined pipeline",
        "custom",
        "Maximum",
    ),
)


class ConfigurationSummary(QFrame):
    """Compact, reusable summary of the current visual configuration."""

    editRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("configurationSummary")

        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(18, 17, 18, 17)
        self.root.setSpacing(11)

        header = QHBoxLayout()
        title = QLabel("CONFIGURATION SUMMARY")
        title.setObjectName("surfaceTitle")
        header.addWidget(title)
        header.addStretch()

        self.preset_pill = Pill("MAXIMUM FIDELITY", "preview")
        header.addWidget(self.preset_pill)

        edit = QPushButton("EDIT CONFIGURATION")
        edit.setObjectName("secondaryButton")
        edit.clicked.connect(self.editRequested.emit)
        header.addWidget(edit)
        self.root.addLayout(header)

        self.objective = QLabel()
        self.objective.setObjectName("configSummaryValue")
        self.root.addWidget(self.objective)

        self.fidelity = QLabel()
        self.fidelity.setObjectName("configSummaryValue")
        self.root.addWidget(self.fidelity)

        self.modules = QLabel()
        self.modules.setObjectName("configSummaryModules")
        self.modules.setWordWrap(True)
        self.root.addWidget(self.modules)

        self.vfx = QLabel()
        self.vfx.setObjectName("configSummaryValue")
        self.root.addWidget(self.vfx)

        self.advanced = QLabel()
        self.advanced.setObjectName("configSummaryValue")
        self.root.addWidget(self.advanced)

    def set_configuration(
        self,
        preset: str,
        objective: str,
        fidelity: str,
        modules,
        vfx_mode: str,
        advanced_count: int,
    ):
        self.preset_pill.setText(preset.upper())
        self.objective.setText(f"Objective   ·   {objective}")
        self.fidelity.setText(f"Fidelity   ·   {fidelity}")
        self.modules.setText("Modules     ·   " + "   ".join(f"✓ {m}" for m in modules))
        self.vfx.setText(f"VFX         ·   {vfx_mode}")
        self.advanced.setText(f"Advanced    ·   {advanced_count} configured")


class PresetCard(QFrame):
    selected = Signal(str)

    def __init__(self, key: str, title: str, description: str, parent=None):
        super().__init__(parent)
        self.key = key
        self.setObjectName("presetCard")
        self.setCursor(Qt.PointingHandCursor)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(13, 11, 13, 11)
        layout.setSpacing(10)

        self.radio = QRadioButton()
        self.radio.setObjectName("presetRadio")
        self.radio.clicked.connect(lambda: self.selected.emit(self.key))
        layout.addWidget(self.radio, 0, Qt.AlignTop)

        text = QVBoxLayout()
        text.setSpacing(3)
        title_label = QLabel(title)
        title_label.setObjectName("presetTitle")
        text.addWidget(title_label)
        desc = QLabel(description)
        desc.setObjectName("muted")
        desc.setWordWrap(True)
        text.addWidget(desc)
        layout.addLayout(text, 1)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.radio.setChecked(True)
            self.selected.emit(self.key)
        super().mousePressEvent(event)

    def set_selected(self, value: bool):
        self.radio.setChecked(value)


class ValidationDashboard(QFrame):
    """Post-reconstruction validation report surface; preview values are explicit."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("validationDashboard")
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 17, 18, 17)
        root.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("RECONSTRUCTION VALIDATION")
        title.setObjectName("surfaceTitle")
        header.addWidget(title)
        header.addStretch()
        header.addWidget(Pill("UI PREVIEW", "preview"))
        root.addLayout(header)

        self.table = QGridLayout()
        self.table.setHorizontalSpacing(16)
        self.table.setVerticalSpacing(7)
        for col, label in enumerate(("CHECK", "EXPECTED", "BUILT", "STATE")):
            w = QLabel(label)
            w.setObjectName("eyebrow")
            self.table.addWidget(w, 0, col)
        root.addLayout(self.table)

        self.structure = QLabel(
            "✓ Manifest integrity    ✓ Asset references    ✓ Placement count    "
            "✓ Transform data    ✓ Godot scene generated"
        )
        self.structure.setObjectName("validationChecks")
        self.structure.setWordWrap(True)
        root.addWidget(self.structure)

        self.score = QLabel("VALIDATION SCORE  ·  PREVIEW ONLY")
        self.score.setObjectName("validationScore")
        root.addWidget(self.score)

    def set_rows(self, rows):
        while self.table.count() > 4:
            item = self.table.takeAt(4)
            if item.widget():
                item.widget().deleteLater()

        for row_index, (name, expected, built, state) in enumerate(rows, 1):
            values = (name, expected, built, state)
            for col, value in enumerate(values):
                label = QLabel(str(value))
                label.setObjectName("validationCellState" if col == 3 else "validationCell")
                self.table.addWidget(label, row_index, col)


class IssuesCenter(QFrame):
    """User-facing issues, kept separate from the technical global log."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("issuesCenter")
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 17, 18, 17)
        root.setSpacing(9)

        header = QHBoxLayout()
        title = QLabel("ISSUES CENTER")
        title.setObjectName("surfaceTitle")
        header.addWidget(title)
        header.addStretch()
        self.blocking = Pill("2 BLOCKING", "blocked")
        self.warnings = Pill("5 WARNINGS", "warning")
        self.info = Pill("12 INFO", "neutral")
        header.addWidget(self.blocking)
        header.addWidget(self.warnings)
        header.addWidget(self.info)
        root.addLayout(header)

        issues = (
            ("🔴", "TRANSFORM WARNING", "Actor: PreviewActor_0142", "Expected transform unavailable"),
            ("🟠", "MODULE WARNING", "Niagara system", "Converted to marker / substitute"),
            ("🔵", "INFO", "Material_027", "Fallback reference recorded"),
        )
        for icon, title_text, source, detail in issues:
            row = QFrame()
            row.setObjectName("issueRow")
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(10, 8, 10, 8)
            row_layout.setSpacing(9)
            icon_label = QLabel(icon)
            icon_label.setFixedWidth(20)
            row_layout.addWidget(icon_label)
            text = QVBoxLayout()
            text.setSpacing(2)
            title_label = QLabel(title_text)
            title_label.setObjectName("issueTitle")
            text.addWidget(title_label)
            source_label = QLabel(source)
            source_label.setObjectName("muted")
            text.addWidget(source_label)
            detail_label = QLabel(detail)
            detail_label.setObjectName("mutueIssue")
            text.addWidget(detail_label)
            row_layout.addLayout(text, 1)
            root.addWidget(row)



# ============================================================================
# CONFIGURATION / PROJECT INTELLIGENCE
# ============================================================================

class ConfigurationDialog(QDialog):
    """Single configuration editor bound to MainWindow's shared configuration state."""

    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.setWindowTitle("Configuration")
        self.resize(820, 700)
        self.setModal(True)

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 26, 28, 26)
        root.setSpacing(16)

        title = QLabel("Configuration")
        title.setObjectName("dialogTitle")
        root.addWidget(title)
        subtitle = QLabel(
            "Edit the reconstruction configuration from one place. "
            "Changes are submitted to the same shared configuration state used by the Setup, Pipeline and summaries."
        )
        subtitle.setObjectName("muted")
        subtitle.setWordWrap(True)
        root.addWidget(subtitle)

        form = QGridLayout()
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(10)
        self.objective_combo = QComboBox()
        self.objective_combo.addItems(["Scene Reconstruction", "Geometry", "Environment", "Visual", "Custom"])
        self.fidelity_combo = QComboBox()
        self.fidelity_combo.addItems(["Maximum", "High", "Balanced", "Fast preview"])
        self.vfx_combo = QComboBox()
        self.vfx_combo.addItems(["Markers + Substitutes", "Markers Only", "Native when available"])
        form.addWidget(owner.field_label("OBJECTIVE"), 0, 0)
        form.addWidget(self.objective_combo, 0, 1)
        form.addWidget(owner.field_label("FIDELITY"), 0, 2)
        form.addWidget(self.fidelity_combo, 0, 3)
        form.addWidget(owner.field_label("VFX STRATEGY"), 1, 0)
        form.addWidget(self.vfx_combo, 1, 1, 1, 3)
        root.addLayout(form)

        modules_surface = Surface("MODULES", "Shared module selection")
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(10)
        self.module_checks = {}
        module_names = (
            "Manifest", "Static Meshes", "Skeletal Meshes", "Landscape", "Materials",
            "Decals", "Lighting", "VFX", "Audio", "Level Instances",
        )
        selected = set(owner._selected_modules())
        for index, module in enumerate(module_names):
            check = QCheckBox(module)
            check.setObjectName("moduleCheck")
            check.setChecked(module in selected)
            self.module_checks[module] = check
            grid.addWidget(check, index // 2, index % 2)
        modules_surface.content().addLayout(grid)
        root.addWidget(modules_surface)

        advanced_surface = Surface("ADVANCED", "Expert configuration remains part of the same configuration state")
        advanced_row = QHBoxLayout()
        advanced_row.addWidget(QLabel(f"{owner.advanced_configured} advanced options configured"))
        advanced_row.addStretch()
        advanced = QPushButton("Advanced / Expert")
        advanced.setObjectName("secondaryButton")
        advanced.clicked.connect(lambda: AdvancedDialog(self).exec())
        advanced_row.addWidget(advanced)
        advanced_surface.content().addLayout(advanced_row)
        root.addWidget(advanced_surface)

        root.addStretch()
        actions = QHBoxLayout()
        actions.addWidget(QLabel("Shared source of truth  ·  Configuration State"))
        actions.addStretch()
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        actions.addWidget(cancel)
        apply = QPushButton("APPLY CONFIGURATION")
        apply.setObjectName("primaryButton")
        apply.clicked.connect(self.apply_configuration)
        actions.addWidget(apply)
        root.addLayout(actions)

        self.objective_combo.setCurrentText(owner.objective_value)
        self.fidelity_combo.setCurrentText(owner.fidelity_value)
        self.vfx_combo.setCurrentText(owner.vfx_value)

    def apply_configuration(self):
        modules = [name for name, check in self.module_checks.items() if check.isChecked()]
        self.owner.apply_configuration(
            objective=self.objective_combo.currentText(),
            fidelity=self.fidelity_combo.currentText(),
            vfx_mode=self.vfx_combo.currentText(),
            modules=modules,
            source="Configuration window",
        )
        self.accept()


class ProjectIntelligencePanel(QFrame):
    """Project understanding surface; values are explicitly preview-only."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("projectIntelligence")
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 17, 18, 17)
        root.setSpacing(11)
        header = QHBoxLayout()
        title = QLabel("PROJECT INTELLIGENCE")
        title.setObjectName("surfaceTitle")
        header.addWidget(title)
        header.addStretch()
        header.addWidget(Pill("UI PREVIEW", "preview"))
        root.addLayout(header)
        subtitle = QLabel("SOURCE ANALYSIS  ·  representative project inventory")
        subtitle.setObjectName("eyebrow")
        root.addWidget(subtitle)

        stats = (
            ("World", "Map"), ("Source Worlds", "17"), ("Level Instances", "58"),
            ("Mesh Placements", "7,872"), ("Unique Meshes", "166"), ("Materials", "43"),
            ("Blueprint Actors", "2,236"), ("Native Actors", "3,469"), ("Niagara", "413"),
            ("Decals", "1,423"),
        )
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(10)
        for i, (label, value) in enumerate(stats):
            card = QFrame()
            card.setObjectName("intelligenceMetric")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(11, 9, 11, 9)
            card_layout.setSpacing(3)
            v = QLabel(value)
            v.setObjectName("intelligenceValue")
            card_layout.addWidget(v)
            l = QLabel(label)
            l.setObjectName("muted")
            card_layout.addWidget(l)
            grid.addWidget(card, i // 5, i % 5)
        root.addLayout(grid)

        categories = (
            ("GEOMETRY", "7,872 placements  ·  166 unique assets"),
            ("ENVIRONMENT", "2 landscapes  ·  1 foliage system"),
            ("GAMEPLAY", "2,236 Blueprint actors"),
            ("SPECIALIZED", "413 Niagara  ·  1,423 decals  ·  211 lights  ·  49 audio"),
        )
        category_grid = QGridLayout()
        category_grid.setHorizontalSpacing(10)
        category_grid.setVerticalSpacing(8)
        for i, (label, detail) in enumerate(categories):
            row = QFrame()
            row.setObjectName("intelligenceCategory")
            lay = QHBoxLayout(row)
            lay.setContentsMargins(11, 8, 11, 8)
            name = QLabel(label)
            name.setObjectName("sectionSubTitle")
            lay.addWidget(name)
            detail_label = QLabel(detail)
            detail_label.setObjectName("muted")
            lay.addWidget(detail_label, 1)
            category_grid.addWidget(row, i // 2, i % 2)
        root.addLayout(category_grid)


class CapabilityMatrix(QFrame):
    """Capability disclosure surface; no conversion guarantee is implied."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("capabilityMatrix")
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 17, 18, 17)
        root.setSpacing(10)
        header = QHBoxLayout()
        title = QLabel("MODULE CAPABILITY MATRIX")
        title.setObjectName("surfaceTitle")
        header.addWidget(title)
        header.addStretch()
        header.addWidget(Pill("CAPABILITY PREVIEW", "preview"))
        root.addLayout(header)
        note = QLabel("Capability describes the intended reconstruction strategy, not guaranteed parity.")
        note.setObjectName("muted")
        note.setWordWrap(True)
        root.addWidget(note)

        rows = (
            ("Static Mesh", "FULL", "Native GLB"),
            ("Skeletal Mesh", "FULL", "Bind pose"),
            ("Landscape", "FULL", "Rebuilt terrain"),
            ("Materials", "PARTIAL", "Converted"),
            ("Decals", "FULL", "Exported"),
            ("Niagara", "MARKER", "Marker / Substitute"),
            ("Audio", "MARKER", "Marker"),
            ("Lighting", "PARTIAL", "Reconstruction-dependent"),
            ("Blueprint", "STRUCTURAL", "Structure / metadata"),
            ("Level Instance", "FULL", "Placement hierarchy"),
        )
        header_row = QHBoxLayout()
        for text, width in (("MODULE", 150), ("STATUS", 105), ("STRATEGY", 1)):
            label = QLabel(text)
            label.setObjectName("eyebrow")
            if width != 1:
                label.setFixedWidth(width)
            header_row.addWidget(label)
        root.addLayout(header_row)
        for module, status, strategy in rows:
            row = QFrame()
            row.setObjectName("capabilityRow")
            lay = QHBoxLayout(row)
            lay.setContentsMargins(10, 7, 10, 7)
            lay.setSpacing(10)
            name = QLabel(module)
            name.setObjectName("fieldStrong")
            name.setFixedWidth(150)
            lay.addWidget(name)
            kind = "ready" if status == "FULL" else ("warning" if status == "PARTIAL" else "neutral")
            lay.addWidget(Pill(status, kind), 0)
            detail = QLabel(strategy)
            detail.setObjectName("muted")
            lay.addWidget(detail, 1)
            root.addWidget(row)

# ============================================================================
# MAIN WINDOW
# ============================================================================


class InterfacePreview(QFrame):
    """Lightweight painted preview of one of the two application modes."""
    def __init__(self, mode="simple", parent=None):
        super().__init__(parent)
        self.mode=mode
        self.setMinimumHeight(250)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setObjectName("modePreview")
    def paintEvent(self, event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r=self.rect().adjusted(10,10,-10,-10)
        p.setPen(QPen(QColor("#303744"),1)); p.setBrush(QColor("#11151d")); p.drawRoundedRect(r,10,10)
        h=r.adjusted(1,1,-1,-1); h.setHeight(28); p.setPen(Qt.NoPen); p.setBrush(QColor("#1b202b")); p.drawRoundedRect(h,9,9); p.drawRect(h.x(),h.y()+9,h.width(),h.height()-9)
        for i in range(3): p.setBrush(QColor("#4a5261")); p.drawEllipse(h.x()+12+i*9,h.y()+10,5,5)
        p.setPen(QColor("#9aa3b3")); p.setFont(QFont("Segoe UI",7,QFont.Bold)); p.drawText(h.x()+48,h.y()+17,"UE2GODOT STUDIO")
        c=r.adjusted(10,38,-10,-10)
        if self.mode=="simple": self._simple(p,c)
        else: self._advanced(p,c)
    def _simple(self,p,r):
        p.setPen(QColor("#f1f3f7")); p.setFont(QFont("Segoe UI",11,QFont.Bold)); p.drawText(r.x(),r.y()+18,"Convert your Unreal project to Godot")
        p.setPen(QColor("#858e9d")); p.setFont(QFont("Segoe UI",6)); p.drawText(r.x(),r.y()+31,"A guided experience with only the choices you need.")
        y=r.y()+49; cw=(r.width()-8)//2
        for i,(t,d) in enumerate((("Project","Choose your project"),("Quality","Choose fidelity"))):
            x=r.x()+i*(cw+8); p.setPen(QPen(QColor("#303744"),1)); p.setBrush(QColor("#191e28")); p.drawRoundedRect(x,y,cw,62,7,7)
            p.setPen(QColor("#e3e7ee")); p.setFont(QFont("Segoe UI",7,QFont.Bold)); p.drawText(x+10,y+20,t)
            p.setPen(QColor("#858e9d")); p.setFont(QFont("Segoe UI",6)); p.drawText(x+10,y+35,d)
            p.setBrush(QColor("#7c6cff")); p.drawRoundedRect(x+10,y+44,cw-20,7,3,3)
        p.setBrush(QColor("#7c6cff")); p.setPen(Qt.NoPen); p.drawRoundedRect(r.x()+r.width()-76,r.bottom()-24,76,20,6,6)
        p.setPen(QColor("#fff")); p.setFont(QFont("Segoe UI",6,QFont.Bold)); p.drawText(r.x()+r.width()-64,r.bottom()-11,"START")
    def _advanced(self,p,r):
        sw=max(48,int(r.width()*.18)); p.setPen(Qt.NoPen); p.setBrush(QColor("#171c25")); p.drawRoundedRect(r.x(),r.y(),sw,r.height(),7,7)
        p.setPen(QColor("#aeb5c2")); p.setFont(QFont("Segoe UI",6,QFont.Bold))
        for i,t in enumerate(("ACTION","CONFIG","PIPELINE","RESULT")): p.drawText(r.x()+8,r.y()+22+i*27,t)
        m=r.adjusted(sw+8,0,0,0); p.setPen(QColor("#f1f3f7")); p.setFont(QFont("Segoe UI",9,QFont.Bold)); p.drawText(m.x(),m.y()+17,"Pipeline / Execution Plan")
        y=m.y()+30
        for i,t in enumerate(("Prepare","Assets","World","Godot","Validate")):
            x=m.x()+i*max(42,(m.width()-8)//5); w=max(38,(m.width()-32)//5)
            p.setPen(QPen(QColor("#303744"),1)); p.setBrush(QColor("#191e28")); p.drawRoundedRect(x,y,w,34,6,6)
            p.setPen(QColor("#d7dbe3")); p.setFont(QFont("Segoe UI",5,QFont.Bold)); p.drawText(x+6,y+14,t)
            p.setPen(QColor("#7d8797")); p.setFont(QFont("Segoe UI",5)); p.drawText(x+6,y+25,"READY")
        lower=y+47; p.setPen(Qt.NoPen); p.setBrush(QColor("#191e28")); p.drawRoundedRect(m.x(),lower,int(m.width()*.62),max(40,m.height()-(lower-m.y())),7,7)
        p.setBrush(QColor("#151a22")); p.drawRoundedRect(m.x()+int(m.width()*.65),lower,int(m.width()*.35),max(40,m.height()-(lower-m.y())),7,7)
        p.setPen(QColor("#858e9d")); p.setFont(QFont("Segoe UI",5)); p.drawText(m.x()+8,lower+15,"Inspector / validation / dependency details"); p.drawText(m.x()+int(m.width()*.65)+8,lower+15,"LIVE LOGS")

class ModeChooser(QWidget):
    """Landing screen shown before entering either user mode."""
    def __init__(self,owner):
        super().__init__(); self.owner=owner; self._build()
    def _build(self):
        root=QVBoxLayout(self); root.setContentsMargins(72,54,72,48); root.setSpacing(18)
        brand=QLabel("UE2GODOT STUDIO"); brand.setObjectName("chooserBrand"); root.addWidget(brand)
        title=QLabel("How would you like to use the application?"); title.setObjectName("chooserTitle"); root.addWidget(title)
        sub=QLabel("Choose the interface that matches your experience. You can change this at any time without closing the application."); sub.setObjectName("chooserSubtitle"); sub.setWordWrap(True); root.addWidget(sub)
        cards=QHBoxLayout(); cards.setSpacing(20)
        cards.addWidget(self._card("Simple interface","For users who just want to choose a project, answer a few questions and start.","Recommended","simple"),1)
        cards.addWidget(self._card("Advanced interface","For developers who want the full pipeline, configuration, validation and technical details.","Full control","advanced"),1)
        root.addLayout(cards,1)
        hint=QLabel("You can switch modes later from inside the application."); hint.setObjectName("chooserHint"); root.addWidget(hint)
    def _card(self,title,desc,badge,mode):
        card=QFrame(); card.setObjectName("modeCard"); lay=QVBoxLayout(card); lay.setContentsMargins(18,18,18,18); lay.setSpacing(12)
        lay.addWidget(InterfacePreview(mode),1)
        row=QHBoxLayout(); t=QLabel(title); t.setObjectName("modeCardTitle"); row.addWidget(t); row.addStretch(); b=QLabel(badge); b.setObjectName("modeCardBadge"); row.addWidget(b); lay.addLayout(row)
        d=QLabel(desc); d.setObjectName("modeCardDescription"); d.setWordWrap(True); lay.addWidget(d)
        btn=QPushButton("Use this interface  →"); btn.setObjectName("modeCardButton"); btn.clicked.connect(lambda checked=False,m=mode:self.owner.choose_mode(m)); lay.addWidget(btn)
        return card

class SimpleWizard(QWidget):
    """Guided front door for users who do not know the internal pipeline."""

    def __init__(self, owner):
        super().__init__()
        self.owner = owner
        self.step = 0
        self.project_path = ""
        self.scope = "whole"
        self.quality = "Maximum"
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(70, 46, 70, 46)
        root.setSpacing(22)

        top = QHBoxLayout()
        brand = QLabel("UE2GODOT STUDIO")
        brand.setObjectName("simpleBrand")
        top.addWidget(brand)
        top.addStretch()
        root.addLayout(top)

        title = QLabel("Convert your Unreal project to Godot")
        title.setObjectName("simpleTitle")
        root.addWidget(title)
        subtitle = QLabel("You do not need to understand the conversion process. We will guide you step by step.")
        subtitle.setObjectName("simpleSubtitle")
        subtitle.setWordWrap(True)
        root.addWidget(subtitle)

        self.progress = QLabel()
        self.progress.setObjectName("simpleProgress")
        root.addWidget(self.progress)

        self.steps = QStackedWidget()
        self.steps.addWidget(self._project_step())
        self.steps.addWidget(self._scope_step())
        self.steps.addWidget(self._quality_step())
        root.addWidget(self.steps, 1)

        nav = QHBoxLayout()
        self.back = QPushButton("← Back")
        self.back.setObjectName("simpleSecondary")
        self.back.clicked.connect(self.previous_step)
        nav.addWidget(self.back)
        nav.addStretch()
        self.next = QPushButton("Continue →")
        self.next.setObjectName("simplePrimary")
        self.next.clicked.connect(self.next_step)
        nav.addWidget(self.next)
        root.addLayout(nav)
        self._refresh()

    def _card(self, title, description, value):
        card = QFrame()
        card.setObjectName("simpleChoice")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(7)
        radio = QRadioButton(title)
        radio.setObjectName("simpleChoiceTitle")
        radio.toggled.connect(lambda checked, v=value: self._choice_changed(v, checked))
        layout.addWidget(radio)
        desc = QLabel(description)
        desc.setObjectName("simpleChoiceDescription")
        desc.setWordWrap(True)
        layout.addWidget(desc)
        card._radio = radio
        card.mousePressEvent = lambda event, r=radio: r.setChecked(True)
        return card

    def _project_step(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 12, 0, 0)
        layout.setSpacing(16)
        heading = QLabel("Where is your Unreal project?")
        heading.setObjectName("simpleStepTitle")
        layout.addWidget(heading)
        help_text = QLabel(
            "Choisissez le projet à convertir : le dossier Content de votre "
            "projet Unreal, ou un dossier d'export déjà produit.")
        help_text.setObjectName("simpleHelp")
        help_text.setWordWrap(True)
        layout.addWidget(help_text)
        row = QHBoxLayout()
        self.project_input = QLineEdit()
        self.project_input.setPlaceholderText(r"C:\Projects\MyUnrealGame")
        self.project_input.textChanged.connect(lambda text: setattr(self, "project_path", text))
        row.addWidget(self.project_input, 1)
        browse = QPushButton("Browse…")
        browse.setObjectName("simpleSecondary")
        # Ouvrait un faux texte ; sélectionne maintenant un vrai dossier et
        # alimente la configuration partagée avec le mode avancé.
        browse.clicked.connect(self._browse_project)
        row.addWidget(browse)
        layout.addLayout(row)
        note = QFrame()
        note.setObjectName("simpleNote")
        nl = QVBoxLayout(note)
        title = QLabel("Recommended")
        title.setObjectName("simpleNoteTitle")
        nl.addWidget(title)
        nl.addWidget(QLabel("Start with the Unreal project itself. The real framework can prepare the technical source data automatically."))
        layout.addWidget(note)
        layout.addStretch()
        return page

    def _browse_project(self):
        path = QFileDialog.getExistingDirectory(
            self, "Dossier source Unreal", self.project_input.text() or str(Path.home()))
        if not path:
            return
        self.project_input.setText(path)
        self.owner.config["source"]["unreal_map"] = path
        self.owner.log_event(f"source sélectionnée : {path}", "step", "assistant")
        self.owner.analyze_source()

    def _scope_step(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 12, 0, 0)
        layout.setSpacing(14)
        heading = QLabel("What do you want to convert?")
        heading.setObjectName("simpleStepTitle")
        layout.addWidget(heading)
        sub = QLabel("If you are unsure, choose the recommended option.")
        sub.setObjectName("simpleHelp")
        layout.addWidget(sub)
        grid = QGridLayout()
        grid.setSpacing(14)
        whole = self._card("Whole project", "Recommended. Rebuild the complete world and supported content.", "whole")
        selected = self._card("Selected content", "Use this when you already know which parts you need.", "selected")
        grid.addWidget(whole, 0, 0)
        grid.addWidget(selected, 0, 1)
        layout.addLayout(grid)
        self.scope_whole = whole._radio
        self.scope_selected = selected._radio
        self.scope_whole.setChecked(True)
        layout.addStretch()
        return page

    def _quality_step(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 12, 0, 0)
        layout.setSpacing(14)
        heading = QLabel("How closely should Godot reproduce your Unreal project?")
        heading.setObjectName("simpleStepTitle")
        layout.addWidget(heading)
        sub = QLabel("This is only a starting choice. Every advanced option remains available later.")
        sub.setObjectName("simpleHelp")
        sub.setWordWrap(True)
        layout.addWidget(sub)
        grid = QVBoxLayout()
        grid.setSpacing(10)
        self.quality_radios = []
        choices = [
            ("Maximum similarity", "Keep as much visual and structural information as possible.", "Maximum"),
            ("Balanced", "A good balance between fidelity and conversion cost.", "Balanced"),
            ("Fast preview", "Prioritize a quick structural result.", "Fast preview"),
        ]
        for title, desc, value in choices:
            card = self._card(title, desc, value)
            grid.addWidget(card)
            self.quality_radios.append(card._radio)
        self.quality_radios[0].setChecked(True)
        layout.addLayout(grid)
        layout.addStretch()
        return page

    def _choice_changed(self, value, checked):
        if not checked:
            return
        if value in ("whole", "selected"):
            self.scope = value
        else:
            self.quality = value

    def next_step(self):
        if self.step < 2:
            self.step += 1
            self._refresh()
        else:
            self.start_conversion()

    def previous_step(self):
        if self.step > 0:
            self.step -= 1
            self._refresh()

    def start_conversion(self):
        objective = "Scene Reconstruction" if self.scope == "whole" else "Custom"
        modules = ["Manifest", "Assets", "Landscape", "Godot", "Validation"]
        self.owner.apply_configuration(
            objective=objective,
            fidelity=self.quality,
            vfx_mode="Markers + Substitutes",
            modules=modules,
            source="Simple mode",
        )
        self.owner.enter_advanced_mode(keep_page=True)
        self.owner.select_page(2)

        # Le mode simple ne « prévisualise » plus : il bascule sur la page
        # pipeline et lance la vérification réelle. C'est volontairement la
        # vérification et non la conversion complète — démarrer un export de
        # vingt minutes sur un simple clic d'assistant, sans que
        # l'utilisateur ait vu l'état de sa source, serait hostile.
        self.owner.log_event("mode simple : configuration appliquée", "step", "assistant")
        if self.owner.config["source"].get("unreal_map"):
            self.owner.run_verification()
        else:
            self.owner.log_event(
                "aucune source sélectionnée — rien à vérifier", "warning", "assistant")

    def _refresh(self):
        self.progress.setText(("1  Project   ·   2  Scope   ·   3  Quality") if self.step == 0 else
                              ("✓ Project   ·   2  Scope   ·   3  Quality") if self.step == 1 else
                              ("✓ Project   ·   ✓ Scope   ·   3  Quality"))
        self.back.setEnabled(self.step > 0)
        self.next.setText("Start conversion →" if self.step == 2 else "Continue →")
        self.steps.setCurrentIndex(self.step)


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        self.current_page = 0
        self.advanced_page = 0
        self.workflow = WORKFLOWS[0]

        self.sidebar_visible = True
        self.context_visible = True
        self.logs_visible = True
        self.focus_mode = False
        self.simple_mode = True
        self.mode_chooser = True
        self.theme_mode = "dark"
        self.current_preset = "maximum"
        self.objective_value = "Scene Reconstruction"
        self.fidelity_value = "Maximum"
        self.vfx_value = "Markers + Substitutes"
        self.advanced_configured = 8
        self.advanced_config = dict(AdvancedDialog.DEFAULTS)
        self.selected_modules = list(self.workflow.modules)

        # --- moteur réel ------------------------------------------------
        self.config = deep_copy_config()
        self.inventory = SourceInventory()
        self.source_analyzer = SourceAnalyzer()
        self.orchestrator = OrchestratorAdapter(self)
        self.plan: dict = {}
        self._central_log_entries: list[dict] = []
        self._last_auth_report = None
        self._operation_status: dict[str, str] = {}

        self.setWindowTitle(f"{APP_NAME} — {APP_VERSION}")
        self.resize(1540, 930)
        self.setMinimumSize(1180, 760)

        self.build_ui()
        self.apply_theme()
        self._connect_backend_signals()

        self.show_mode_chooser()

    def _connect_backend_signals(self):
        """Connexion PERMANENTE du moteur au journal.

        Établie une fois pour toutes, jamais défaite : une connexion posée
        au moment d'un lancement ne couvrirait que ce chemin-là, si bien
        qu'une action déclenchée ailleurs ne laisserait aucune trace — le
        défaut exact qui rendait le journal précédent quasi vide.
        """
        self.orchestrator.log.connect(
            lambda msg: self.log_event(str(msg), self._level_of(str(msg)), "moteur"))
        self.orchestrator.step_changed.connect(
            lambda step: self.log_event(f"étape : {step}", "step", "moteur"))
        self.orchestrator.failed.connect(lambda msg: self._on_backend_failed(str(msg)))
        self.orchestrator.finished.connect(self._on_backend_finished)
        self.orchestrator.progress.connect(self._on_backend_progress)

    @staticmethod
    def _level_of(text: str) -> str:
        stripped = text.strip()
        if stripped.startswith("[") and ("%" in stripped[:12] or "DONE" in stripped[:12]):
            return "engine"
        if "ERREUR" in text or "✕" in text or "Échec" in text:
            return "error"
        if "⚠" in text or "ATTENTION" in text:
            return "warning"
        return "info"


    # ==================================================================
    # BRANCHEMENT RÉEL — journal, sources, exécution
    # ==================================================================

    def log_event(self, message: str, level: str = "info", source: str = ""):
        entry = {"time": now_string(), "message": str(message),
                 "level": level, "source": source}
        self._central_log_entries.append(entry)
        # Borne haute : un import Godot produit des milliers de lignes ;
        # sans plafond le widget finit par ralentir toute l'interface.
        if len(self._central_log_entries) > 5000:
            del self._central_log_entries[:1000]

        drawer = getattr(self, "logs", None)
        if drawer is None:
            return
        # La sortie brute du moteur est CAPTURÉE mais pas affichée par
        # défaut : c'est le filtre qui décide, pas la capture, sinon un
        # débogage fin n'aurait aucune trace à consulter.
        if level != "engine":
            marker = {"error": "✕", "warning": "⚠", "step": "▶", "ok": "✓"}.get(level, "·")
            prefix = f"[{entry['time']}] {marker}"
            if source:
                prefix += f" ({source})"
            try:
                drawer.add(f"{prefix} {message}")
            except Exception:
                pass

    def _on_backend_failed(self, message: str):
        self.log_event(message, "error", "moteur")
        self.set_status(f"Échec : {message[:90]}", "error")

    def _on_backend_finished(self, result):
        data = dict(result) if result else {}
        summary = ", ".join(f"{k}={v}" for k, v in data.items() if k != "stats")
        self.log_event(f"terminé — {summary}", "ok", "moteur")
        self.set_status("Opération terminée", "ok")
        self._refresh_after_run(data)

    def _on_backend_progress(self, value: int):
        bar = getattr(self, "pipeline_current_progress", None)
        if bar is not None:
            try:
                bar.setValue(int(value))
            except Exception:
                pass

    def set_status(self, text: str, tone: str = "info"):
        label = getattr(self, "status_message", None)
        if label is not None:
            try:
                label.setText(text)
            except Exception:
                pass

    # ---------------------------------------------------------------- sources

    def browse_unreal_source(self):
        path = QFileDialog.getExistingDirectory(
            self, "Dossier source Unreal (Content, ou dossier d'export)",
            self.config["source"].get("unreal_map", "") or str(Path.home()))
        if not path:
            return
        self.config["source"]["unreal_map"] = path
        self.log_event(f"source sélectionnée : {path}", "step", "projet")
        self.analyze_source()

    def browse_unreal_map_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Map Unreal (.umap)",
            self.config["source"].get("unreal_map", "") or str(Path.home()),
            "Map Unreal (*.umap);;Tous les fichiers (*)")
        if not path:
            return
        self.config["source"]["unreal_map"] = path
        self.log_event(f"map sélectionnée : {path}", "step", "projet")
        self.analyze_source()

    def browse_godot_project(self):
        path = QFileDialog.getExistingDirectory(
            self, "Projet Godot cible",
            self.config["project"].get("godot_project", "") or str(Path.home()))
        if not path:
            return
        if not (Path(path) / "project.godot").is_file():
            QMessageBox.warning(
                self, "Projet Godot",
                "Ce dossier ne contient pas de project.godot.\n\n"
                "Sélectionnez la racine d'un projet Godot existant : c'est "
                "elle qui détermine aussi la version du moteur à utiliser "
                "pour la construction.")
            return
        self.config["project"]["godot_project"] = path
        version = self.orchestrator.read_project_godot_version(path)
        self.log_event(
            f"projet Godot : {path}" + (f" (moteur {version})" if version else ""),
            "step", "projet")
        self.refresh_project_view()

    def analyze_source(self):
        source = self.config["source"].get("unreal_map", "")
        if not source:
            return
        self.inventory = self.source_analyzer.analyze(source)
        for message in self.inventory.errors:
            self.log_event(message, "error", "analyse")
        for message in self.inventory.warnings:
            self.log_event(message, "warning", "analyse")
        self.refresh_project_view()

    def refresh_project_view(self):
        """Met à jour les champs de la page projet depuis l'état réel."""
        inv = self.inventory
        for attr, value in (
            ("project_input", self.config["project"].get("godot_project", "")),
            ("source_input", self.config["source"].get("unreal_map", "")),
        ):
            widget = getattr(self, attr, None)
            if widget is not None:
                try:
                    widget.setText(value)
                except Exception:
                    pass
        self._refresh_readiness()

    def _refresh_readiness(self):
        center = getattr(self, "readiness", None)
        if center is None:
            return
        inv = self.inventory
        godot = self.config["project"].get("godot_project", "")
        items = [
            ("Source Unreal",
             "OK" if self.config["source"].get("unreal_map") else "BLOCKED",
             self.config["source"].get("unreal_map") or "Aucune source sélectionnée.",
             True),
            ("Manifeste", "OK" if inv.manifest else "WARNING",
             inv.manifest or "Sera produit par l'étape Manifest.", False),
            ("Asset map", "OK" if inv.asset_map else "WARNING",
             inv.asset_map or "Sera produite par l'étape Meshes.", False),
            ("Decal map", "OK" if inv.decal_map else "WARNING",
             inv.decal_map or "Sera produite par l'étape Decals.", False),
            ("Projet Godot", "OK" if godot else "BLOCKED",
             godot or "Aucun projet Godot cible.", True),
        ]
        try:
            center.set_state(items)
        except Exception:
            pass

    def _refresh_after_run(self, data=None):
        if self.config["source"].get("unreal_map"):
            self.analyze_source()

    # ------------------------------------------------------- exécution réelle

    def _require_paths(self) -> bool:
        if not self.config["source"].get("unreal_map"):
            QMessageBox.warning(self, "Source",
                                "Sélectionnez d'abord une source Unreal.")
            return False
        if not self.config["project"].get("godot_project"):
            QMessageBox.warning(self, "Projet Godot",
                                "Sélectionnez d'abord le projet Godot cible.")
            return False
        return True

    def _build_plan(self) -> dict:
        source = self.config["source"].get("unreal_map", "")
        path = Path(source).expanduser()
        return {
            "source": str(path.parent if path.is_file() else path),
            "godot_project": self.config["project"].get("godot_project", ""),
            "godot_executable": self.config["advanced"].get("godot_executable", ""),
            "godot_asset_root": "res://" + self.config["advanced"].get(
                "godot_asset_root", "UEAssets").replace("res://", ""),
            "manifest": self.inventory.manifest or "",
        }

    def run_unreal_exports(self):
        """Étapes 0-4 : elles font `import unreal` pour de vrai et ne
        peuvent donc s'exécuter que dans la session Python de l'éditeur.
        Exécution distante si possible, repli copier-coller sinon."""
        if not self.config["source"].get("unreal_map"):
            QMessageBox.warning(self, "Source", "Sélectionnez d'abord une source Unreal.")
            return

        from ue2godot.core.config import ResolvedConfig
        from ue2godot.orchestrator.adapters.ue_remote import UERemoteAdapter
        from ue2godot.orchestrator.remote_execution import (
            RemoteExecutionError, diagnose_network)
        from ue2godot.orchestrator.permissions import find_uproject

        source = self.config["source"]["unreal_map"]
        path = Path(source).expanduser()
        export_dir = str(path.parent if path.is_file() else path)
        modules = self._module_flags()

        res_cfg = ResolvedConfig.resolve({
            "paths": {"ue_export_root": export_dir,
                      "godot_asset_root": "res://" + self.config["advanced"].get(
                          "godot_asset_root", "UEAssets").replace("res://", "")},
            "landscape": {"enabled": modules.get("landscape", True),
                          "map_filesystem_path": source},
            "decals": {"enabled": modules.get("decals", True)},
            "audio": {"policy": "markers" if modules.get("audio", False) else "ignore"},
            "vfx": {"mode": self._vfx_mode() if modules.get("vfx", True) else "none"},
        }, {}, {})

        report_dir = os.path.join(export_dir, "reports")
        os.makedirs(report_dir, exist_ok=True)
        run_config_path = os.path.join(export_dir, f"run_config_{res_cfg.run_id}.json")
        with open(run_config_path, "w", encoding="utf-8") as handle:
            json.dump(res_cfg.to_dict(), handle, indent=2, ensure_ascii=False)

        uproject = find_uproject(source) or ""
        ini = os.path.join(os.path.dirname(uproject), "Config", "DefaultEngine.ini") \
            if uproject else ""
        adapter = UERemoteAdapter(res_cfg, default_engine_ini=ini)
        module_root = os.path.dirname(os.path.abspath(__file__))

        steps = ["manifest", "meshes"]
        if modules.get("landscape", True):
            steps.append("landscape")
        if modules.get("decals", True):
            steps.append("decals_vfx")

        self.log_event(f"exports Unreal demandés : {', '.join(steps)}", "step", "unreal")

        try:
            remote = adapter.can_execute_remotely(timeout=2.0)
        except Exception:
            remote = False

        if not remote:
            for line in diagnose_network(timeout=3.0, default_engine_ini=ini):
                self.log_event(line, "warning", "réseau")
            instructions = adapter.build_fallback_instructions(
                steps, run_config_path, module_root=module_root, report_dir=report_dir)
            for line in instructions:
                self.log_event(line, "info", "repli")
            QMessageBox.information(self, "Exports Unreal", "\n".join(instructions))
            return

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            results = adapter.execute_steps_remotely(
                steps, run_config_path, module_root=module_root)
        except RemoteExecutionError as exc:
            QApplication.restoreOverrideCursor()
            self.log_event(f"exécution distante interrompue : {exc}", "error", "unreal")
            QMessageBox.warning(self, "Exports Unreal", str(exc))
            return
        finally:
            QApplication.restoreOverrideCursor()

        for name, ok, message in results:
            self.log_event(f"{name} : {'OK' if ok else 'ÉCHEC'}",
                           "ok" if ok else "error", "unreal")
            for line in str(message).splitlines():
                if line.strip():
                    self.log_event("    " + line.strip(), "info", "unreal")
        self.analyze_source()

    def run_godot_build(self):
        """Copie, import headless, construction de la scène."""
        if not self._require_paths():
            return
        self.plan = self._build_plan()
        self.log_event("construction Godot : copie puis import puis build",
                       "step", "godot")
        if not self.orchestrator.copy_assets(self.plan):
            return
        self.orchestrator.build_scene_headless(self.plan)

    def open_godot_project(self):
        if not self.config["project"].get("godot_project"):
            QMessageBox.warning(self, "Projet Godot", "Aucun projet Godot cible.")
            return
        self.plan = self._build_plan()
        self.orchestrator.open_godot(self.plan)

    def open_output_folder(self):
        source = self.config["source"].get("unreal_map", "")
        if not source:
            QMessageBox.warning(self, "Sortie", "Aucune source sélectionnée.")
            return
        path = Path(source).expanduser()
        target = path.parent if path.is_file() else path
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(target))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(target)])
            else:
                subprocess.Popen(["xdg-open", str(target)])
        except Exception as exc:
            QMessageBox.warning(self, "Sortie", f"Ouverture impossible : {exc}")

    # ------------------------------------------------------------ config UI

    def _action_button(self, label: str, slot):
        """Bouton réellement branché.

        Remplace PlaceholderButton, qui ouvrait une boîte « Preview only ».
        On garde le même objectName pour que la feuille de style existante
        s'applique sans retouche : brancher l'interface ne doit pas la
        redessiner.
        """
        button = QPushButton(label)
        button.setObjectName("ghost")
        button.setCursor(Qt.PointingHandCursor)
        button.clicked.connect(slot)
        return button

    def run_verification(self):
        """Vérification réelle : analyse de la source + contrôle croisé."""
        if not self.config["source"].get("unreal_map"):
            QMessageBox.warning(self, "Vérification",
                                "Sélectionnez d'abord une source Unreal.")
            return

        self.analyze_source()
        inv = self.inventory
        rows = []
        for label, path, mandatory in (
            ("Manifeste", inv.manifest, True),
            ("Asset map", inv.asset_map, True),
            ("Decal map", inv.decal_map, False),
            ("Dossier meshes", inv.mesh_directory, True),
        ):
            state = "OK" if path else ("BLOCKED" if mandatory else "WARNING")
            rows.append((label, state, path or "absent"))

        # Contrôle croisé : run_id identiques entre les 3 JSON. C'est lui
        # qui détecte qu'une étape a été relancée après une autre et a
        # effacé son travail — invisible autrement.
        if inv.manifest and inv.asset_map:
            try:
                from ue2godot.orchestrator.pipeline import PipelineOrchestrator
                from ue2godot.core.config import ResolvedConfig
                cfg = ResolvedConfig.resolve({}, {}, {})
                report = PipelineOrchestrator(cfg).crosscheck(
                    inv.manifest, inv.asset_map, inv.decal_map or None)
                rows.append(("Cohérence des JSON",
                             "OK" if report.status == "OK" else "BLOCKED",
                             "; ".join(report.errors) or "run_id cohérents"))
                for message in report.errors:
                    self.log_event(message, "error", "vérification")
                for message in report.warnings:
                    self.log_event(message, "warning", "vérification")
            except Exception as exc:
                rows.append(("Cohérence des JSON", "WARNING", str(exc)))

        dashboard = getattr(self, "validation_dashboard", None)
        if dashboard is not None:
            try:
                dashboard.set_rows(rows)
            except Exception:
                pass

        for label, state, detail in rows:
            self.log_event(f"{label} : {state} — {detail}",
                           "error" if state == "BLOCKED" else
                           ("warning" if state == "WARNING" else "ok"),
                           "vérification")
        self.set_status("Vérification terminée", "ok")

    def show_build_report(self):
        """Rapport de construction réel : déclaré contre construit."""
        report = getattr(self.orchestrator, "last_build_report", {}) or {}
        if not report:
            QMessageBox.information(
                self, "Rapport",
                "Aucun rapport de construction disponible.\n\n"
                "Lancez « Build in Godot » : le rapport indiquera alors ce que "
                "le manifeste déclare et ce qui a réellement été construit.")
            return

        lines = [f"Statut : {report.get('status', '?')}",
                 f"Nœuds dans la scène : {report.get('built_nodes', 0)}", ""]
        declared = report.get("declared", {})
        if declared:
            lines.append("Déclaré par le manifeste :")
            lines += [f"  {k} = {v}" for k, v in declared.items()]
            lines.append("")
        stats = report.get("stats", {})
        if stats:
            lines.append("Réellement construit :")
            lines += [f"  {k} = {v}" for k, v in stats.items()]
            lines.append("")
        for warning in report.get("warnings", []):
            lines.append(f"⚠ {warning}")
        for error in report.get("errors", []):
            lines.append(f"✕ {error}")

        QMessageBox.information(self, "Rapport de construction", "\n".join(lines))

    def _module_flags(self) -> dict:
        """Modules actifs, lus de l'UI si elle les expose, du config sinon."""
        selected = set(getattr(self, "selected_modules", []) or [])
        if not selected:
            return dict(self.config["construction"]["modules"])
        mapping = {
            "landscape": "landscape", "terrain": "landscape",
            "decals": "decals", "vfx": "vfx", "audio": "audio",
            "lighting": "lighting", "materials": "materials",
            "level_instances": "level_instances",
        }
        flags = {key: False for key in self.config["construction"]["modules"]}
        for item in selected:
            key = mapping.get(str(item).lower().replace(" ", "_"))
            if key:
                flags[key] = True
        return flags

    def _vfx_mode(self) -> str:
        value = str(getattr(self, "vfx_value", "")).lower()
        if "substitute" in value:
            return "substitutes"
        if "none" in value or "aucun" in value:
            return "none"
        return "markers"

    # ------------------------------------------------------------------
    # MAIN SHELL
    # ------------------------------------------------------------------

    def build_ui(self):

        central = QWidget()
        central.setObjectName("root")
        self.setCentralWidget(central)

        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.header_widget = self.build_header()
        root.addWidget(self.header_widget)
        self.command_strip = self.build_command_strip()
        root.addWidget(self.command_strip)

        body_widget = QWidget()
        body = QHBoxLayout(body_widget)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)

        self.sidebar = Sidebar()
        self.sidebar.pageSelected.connect(self.select_page)
        self.sidebar.toggle_button.clicked.connect(self.toggle_sidebar)
        body.addWidget(self.sidebar)

        self.pages = QStackedWidget()
        self.pages.setObjectName("pages")

        self.mode_chooser_page = ModeChooser(self)
        self.pages.addWidget(self.mode_chooser_page)
        self.simple_home = SimpleWizard(self)
        self.pages.addWidget(self.simple_home)
        self.pages.addWidget(self.build_action_page())
        self.pages.addWidget(self.build_setup_page())
        self.pages.addWidget(self.build_pipeline_page())
        self.pages.addWidget(self.build_result_page())

        body.addWidget(self.pages, 1)

        self.context = ContextPanel()
        self.context.hide_button.clicked.connect(self.toggle_context)
        body.addWidget(self.context)

        self.logs = LogDrawer()
        self.logs.hide_button.clicked.connect(self.toggle_logs)
        self.logs.setMinimumHeight(150)
        self.logs.setMaximumHeight(520)

        self.shell_splitter = QSplitter(Qt.Vertical)
        self.shell_splitter.setObjectName("shellSplitter")
        self.shell_splitter.setChildrenCollapsible(False)
        self.shell_splitter.addWidget(body_widget)
        self.shell_splitter.addWidget(self.logs)
        self.shell_splitter.setStretchFactor(0, 1)
        self.shell_splitter.setStretchFactor(1, 0)
        self.shell_splitter.setSizes([650, 285])
        root.addWidget(self.shell_splitter, 1)

        self.status_bar_widget = self.build_status_bar()
        root.addWidget(self.status_bar_widget)

    # ------------------------------------------------------------------
    # USER-FIRST COMMAND STRIP
    # ------------------------------------------------------------------

    def build_command_strip(self):
        """Persistent, low-friction navigation for the primary user journey.

        Existing sidebar/header navigation remains intact; this strip adds a
        second, more explicit path through the application without removing
        any existing surface.
        """
        bar = QFrame()
        bar.setObjectName("commandStrip")
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(6)

        self.command_buttons = []
        steps = (
            (0, "01", "Action", "Choose what to reconstruct"),
            (1, "02", "Configuration", "Prepare the project and options"),
            (2, "03", "Pipeline", "Observe execution and dependencies"),
            (3, "04", "Result", "Review output and validation"),
        )
        for index, number, label, hint in steps:
            button = QPushButton(f"{number}  {label}")
            button.setObjectName("commandStep")
            button.setToolTip(hint)
            button.clicked.connect(lambda checked=False, i=index: self.select_page(i))
            layout.addWidget(button)
            self.command_buttons.append(button)

        layout.addWidget(self._command_separator())

        self.command_hint = QLabel("Choose what you want to reconstruct")
        self.command_hint.setObjectName("commandHint")
        layout.addWidget(self.command_hint, 1)

        self.command_primary = QPushButton("Continue  →")
        self.command_primary.setObjectName("commandPrimary")
        self.command_primary.setMinimumWidth(118)
        self.command_primary.clicked.connect(self.advance_primary_flow)
        layout.addWidget(self.command_primary)

        focus = QPushButton("Focus")
        focus.setObjectName("commandUtility")
        focus.setToolTip("Hide navigation, context and logs to maximize workspace")
        focus.clicked.connect(self.toggle_focus_mode)
        self.focus_button = focus
        layout.addWidget(focus)

        self._update_command_strip(0)
        return bar

    @staticmethod
    def _command_separator():
        separator = QFrame()
        separator.setObjectName("commandSeparator")
        separator.setFixedWidth(1)
        separator.setMinimumHeight(22)
        separator.setMaximumHeight(22)
        return separator

    def _update_command_strip(self, index):
        hints = (
            "Choose what you want to reconstruct",
            "Prepare the project, source and reconstruction options",
            "Observe the plan, current step, output and validation",
            "Review the reconstruction result, warnings and report",
        )
        if hasattr(self, "command_buttons"):
            for i, button in enumerate(self.command_buttons):
                button.setProperty("active", i == index)
                button.style().unpolish(button)
                button.style().polish(button)
        if hasattr(self, "command_hint"):
            self.command_hint.setText(hints[index])
        if hasattr(self, "command_primary"):
            labels = ("Configure  →", "Open Pipeline  →", "View Result  →", "Back to Config  →")
            self.command_primary.setText(labels[index])

    def advance_primary_flow(self):
        transitions = {0: 1, 1: 2, 2: 3, 3: 1}
        self.select_page(transitions.get(self.current_page, 0))

    def toggle_focus_mode(self):
        self.focus_mode = not self.focus_mode
        if hasattr(self, "sidebar"):
            self.sidebar.setVisible(not self.focus_mode and self.sidebar_visible)
        if hasattr(self, "context"):
            self.context.setVisible(not self.focus_mode and self.context_visible)
        if hasattr(self, "logs"):
            self.logs.setVisible(not self.focus_mode and self.logs_visible)
        if hasattr(self, "focus_button"):
            self.focus_button.setText("Exit Focus" if self.focus_mode else "Focus")
            self.focus_button.setToolTip(
                "Restore navigation, context and logs" if self.focus_mode
                else "Hide navigation, context and logs to maximize workspace"
            )

    # ------------------------------------------------------------------
    # HEADER
    # ------------------------------------------------------------------

    def build_header(self):

        header = QFrame()
        header.setObjectName("header")
        header.setFixedHeight(68)

        layout = QHBoxLayout(header)
        layout.setContentsMargins(18, 10, 18, 10)
        layout.setSpacing(10)

        menu = QToolButton()
        menu.setText("☰")
        menu.setToolTip("Show / hide navigation")
        menu.clicked.connect(self.toggle_sidebar)
        layout.addWidget(menu)

        logo = QLabel("UE2GODOT")
        logo.setObjectName("headerLogo")
        layout.addWidget(logo)

        slash = QLabel("/")
        slash.setObjectName("muted")
        layout.addWidget(slash)

        self.header_page = QLabel("01 Action")
        self.header_page.setObjectName("headerPage")
        layout.addWidget(self.header_page)

        layout.addStretch()

        status = Pill("●  READY", "ready")
        layout.addWidget(status)

        context = QPushButton("Context")
        context.setObjectName("headerButton")
        context.clicked.connect(self.toggle_context)
        self.header_context_button = context
        layout.addWidget(context)

        logs = QPushButton("Logs")
        logs.setObjectName("headerButton")
        logs.clicked.connect(self.toggle_logs)
        self.header_logs_button = logs
        layout.addWidget(logs)

        self.theme_button = QPushButton("☀ Light")
        self.theme_button.setObjectName("headerButton")
        self.theme_button.setToolTip("Switch between the dark and light application themes")
        self.theme_button.clicked.connect(self.toggle_theme)
        layout.addWidget(self.theme_button)

        edit_config = QPushButton("Edit Configuration")
        edit_config.setObjectName("headerButton")
        edit_config.setToolTip("Open the shared configuration editor")
        edit_config.clicked.connect(self.open_configuration_dialog)
        self.header_edit_button = edit_config
        layout.addWidget(edit_config)

        self.mode_button = QPushButton("Advanced mode")
        self.mode_button.setObjectName("headerButton")
        self.mode_button.setToolTip("Switch directly between Simple and Advanced interface")
        self.mode_button.clicked.connect(self.toggle_user_mode)
        layout.addWidget(self.mode_button)

        help_button = QPushButton("?")
        help_button.setObjectName("headerIcon")
        help_button.setFixedWidth(36)
        help_button.clicked.connect(self.show_help)
        layout.addWidget(help_button)

        return header

    # ------------------------------------------------------------------
    # STATUS BAR
    # ------------------------------------------------------------------

    def build_status_bar(self):

        bar = QFrame()
        bar.setObjectName("statusBar")
        bar.setFixedHeight(38)

        layout = QHBoxLayout(bar)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(14)

        self.status_message = QLabel("●  Ready")
        self.status_message.setObjectName("statusReady")
        layout.addWidget(self.status_message)

        separator = QLabel("|")
        separator.setObjectName("statusSeparator")
        layout.addWidget(separator)

        layout.addWidget(QLabel("UE5  —  preview"))
        layout.addWidget(QLabel("Godot  —  preview"))
        layout.addWidget(QLabel("Assets  —  166"))
        layout.addWidget(QLabel("Warnings  —  7"))

        layout.addStretch()

        logs = QLabel("LOGS  4")
        logs.setObjectName("statusLogs")
        layout.addWidget(logs)

        return bar

    # ------------------------------------------------------------------
    # ACTION
    # ------------------------------------------------------------------

    def build_action_page(self):

        page = QWidget()

        root = QVBoxLayout(page)
        root.setContentsMargins(34, 30, 34, 32)
        root.setSpacing(18)

        title = QLabel("Choose your workflow")
        title.setObjectName("pageTitle")
        root.addWidget(title)

        subtitle = QLabel(
            "Select what you want UE2Godot to do. "
            "Technical configuration comes after the workflow choice."
        )
        subtitle.setObjectName("pageSubtitle")
        subtitle.setWordWrap(True)
        root.addWidget(subtitle)

        info = QFrame()
        info.setObjectName("introBanner")

        info_layout = QHBoxLayout(info)
        info_layout.setContentsMargins(18, 15, 18, 15)

        info_text = QLabel(
            "The workflow defines the reconstruction objective. "
            "Modules remain configurable afterward."
        )
        info_text.setObjectName("introText")
        info_text.setWordWrap(True)
        info_layout.addWidget(info_text, 1)

        preview = Pill("STANDALONE PREVIEW", "preview")
        info_layout.addWidget(preview)

        root.addWidget(info)

        grid_widget = QWidget()
        grid = QGridLayout(grid_widget)
        grid.setContentsMargins(0, 4, 0, 0)
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(16)

        for index, workflow in enumerate(WORKFLOWS):

            card = WorkflowCard(workflow)
            card.selected.connect(self.select_workflow)

            if index == 0:
                grid.addWidget(card, 0, 0, 1, 2)
            else:
                grid.addWidget(card, (index + 1) // 2, (index + 1) % 2)

        root.addWidget(grid_widget)

        root.addStretch()

        footer = QLabel(
            "Design principle  ·  simple at first glance, "
            "powerful when configuration is required."
        )
        footer.setObjectName("muted")
        root.addWidget(footer)

        return self.scroll_page(page)

    # ------------------------------------------------------------------
    # SETUP
    # ------------------------------------------------------------------

    def build_setup_page(self):
        page = QWidget()

        root = QVBoxLayout(page)
        root.setContentsMargins(34, 30, 34, 32)
        root.setSpacing(18)

        title = QLabel("Project & Configuration")
        title.setObjectName("pageTitle")
        root.addWidget(title)

        subtitle = QLabel(
            "Prepare the reconstruction context, select a preset or customize the "
            "workflow, then review the exact configuration before execution."
        )
        subtitle.setObjectName("pageSubtitle")
        subtitle.setWordWrap(True)
        root.addWidget(subtitle)

        top_grid = QGridLayout()
        top_grid.setHorizontalSpacing(16)
        top_grid.setVerticalSpacing(16)

        project = Surface("PROJECT", "Target reconstruction context")
        project_row = QHBoxLayout()
        project_input = self.project_input = QLineEdit()
        project_input.setPlaceholderText("Racine du projet Godot (contenant project.godot)")
        project_input.textChanged.connect(
            lambda text: self.config["project"].__setitem__("godot_project", text.strip()))
        project_row.addWidget(project_input, 1)
        project_row.addWidget(self._action_button("Browse", self.browse_godot_project))
        project.content().addLayout(project_row)
        project_state = QHBoxLayout()
        project_state.addWidget(Pill("NOT CONNECTED", "neutral"))
        project_state.addWidget(QLabel("Standalone preview — no project is accessed."))
        project_state.addStretch()
        project.content().addLayout(project_state)

        source = Surface("SOURCE", "Prepared UE5 export")
        source_row = QHBoxLayout()
        source_input = self.source_input = QLineEdit()
        source_input.setPlaceholderText("Dossier Content Unreal, ou dossier d'export")
        source_input.textChanged.connect(
            lambda text: self.config["source"].__setitem__("unreal_map", text.strip()))
        source_row.addWidget(source_input, 1)
        source_row.addWidget(self._action_button("Browse", self.browse_unreal_source))
        source_row.addWidget(self._action_button("Inspect", self.analyze_source))
        source.content().addLayout(source_row)
        source_stats = QHBoxLayout()
        source_stats.addWidget(Pill("MANIFEST", "ready"))
        source_stats.addWidget(QLabel("Assets 166"))
        source_stats.addWidget(QLabel("Placements 7872"))
        source_stats.addWidget(QLabel("Level Instances 58"))
        source_stats.addStretch()
        source.content().addLayout(source_stats)

        top_grid.addWidget(project, 0, 0)
        top_grid.addWidget(source, 0, 1)
        root.addLayout(top_grid)

        self.project_intelligence = ProjectIntelligencePanel()
        root.addWidget(self.project_intelligence)

        self.capability_matrix = CapabilityMatrix()
        root.addWidget(self.capability_matrix)

        self.readiness = ReadinessCenter()
        self.readiness.set_state(
            (
                ("Source project", "READY", "UE5 source context is represented in preview mode."),
                ("Manifest", "READY", "Structural source of truth is available in the preview."),
                ("Asset map", "READY", "166 unique mesh references are represented."),
                ("Mesh library", "READY", "Prepared mesh resolution path is available."),
                ("Godot target", "WARNING", "Godot project path is still a placeholder."),
                ("Framework runtime", "READY", "Framework connection is intentionally disabled in this preview."),
            )
        )
        root.addWidget(self.readiness)

        # Presets
        presets = Surface("PRESETS", "Preset → module matrix → pipeline")
        preset_grid = QGridLayout()
        preset_grid.setHorizontalSpacing(10)
        preset_grid.setVerticalSpacing(10)
        self.preset_cards = {}
        for index, (key, title_text, description, _, _) in enumerate(PRESETS):
            card = PresetCard(key, title_text, description)
            card.selected.connect(self.select_preset)
            self.preset_cards[key] = card
            preset_grid.addWidget(card, index // 2, index % 2)
        presets.content().addLayout(preset_grid)
        root.addWidget(presets)

        configuration = Surface("CONFIGURATION", "Workflow-dependent settings")
        basic = QGridLayout()
        basic.setHorizontalSpacing(18)
        basic.setVerticalSpacing(12)

        self.objective_combo = QComboBox()
        self.objective_combo.addItems(["Scene Reconstruction", "Geometry", "Environment", "Visual", "Custom"])
        self.objective_combo.currentTextChanged.connect(self.on_configuration_changed)

        self.fidelity_combo = QComboBox()
        self.fidelity_combo.addItems(["Maximum", "High", "Balanced", "Fast preview"])
        self.fidelity_combo.currentTextChanged.connect(self.on_configuration_changed)

        self.vfx_combo = QComboBox()
        self.vfx_combo.addItems(["Markers + Substitutes", "Markers Only", "Native when available"])
        self.vfx_combo.currentTextChanged.connect(self.on_configuration_changed)

        basic.addWidget(self.field_label("OBJECTIVE"), 0, 0)
        basic.addWidget(self.objective_combo, 0, 1)
        basic.addWidget(self.field_label("FIDELITY"), 0, 2)
        basic.addWidget(self.fidelity_combo, 0, 3)
        basic.addWidget(self.field_label("VFX STRATEGY"), 1, 0)
        basic.addWidget(self.vfx_combo, 1, 1, 1, 3)
        configuration.content().addLayout(basic)

        fidelity_row = QHBoxLayout()
        fidelity_row.setSpacing(12)
        fidelity_title = QLabel("Fidelity")
        fidelity_title.setObjectName("fieldStrong")
        fidelity_row.addWidget(fidelity_title)
        progress = QProgressBar()
        progress.setRange(0, 100)
        progress.setValue(90)
        progress.setTextVisible(False)
        progress.setObjectName("fidelityBar")
        fidelity_row.addWidget(progress, 1)
        fidelity_value = QLabel("90%")
        fidelity_value.setObjectName("fieldStrong")
        fidelity_row.addWidget(fidelity_value)
        configuration.content().addLayout(fidelity_row)

        modules_header = QHBoxLayout()
        modules_title = QLabel("MODULES")
        modules_title.setObjectName("sectionSubTitle")
        modules_header.addWidget(modules_title)
        modules_hint = QLabel("Select what belongs to this workflow.")
        modules_hint.setObjectName("muted")
        modules_header.addWidget(modules_hint)
        modules_header.addStretch()
        configuration.content().addLayout(modules_header)

        self.module_grid = QGridLayout()
        self.module_grid.setHorizontalSpacing(12)
        self.module_grid.setVerticalSpacing(12)
        self.module_cards = {}
        module_names = (
            "Manifest", "Static Meshes", "Skeletal Meshes", "Landscape", "Materials",
            "Decals", "Lighting", "VFX", "Audio", "Level Instances",
        )
        for index, module in enumerate(module_names):
            card = self.create_module_card(module)
            self.module_cards[module] = card
            self.module_grid.addWidget(card, index // 3, index % 3)
        configuration.content().addLayout(self.module_grid)

        advanced_row = QHBoxLayout()
        advanced = QPushButton("Advanced / Expert")
        advanced.setObjectName("secondaryButton")
        advanced.clicked.connect(lambda: AdvancedDialog(self).exec())
        advanced_row.addWidget(advanced)
        advanced_description = QLabel(
            "Transform & Hierarchy  ·  Asset Resolution  ·  Validation  ·  "
            "Fallback  ·  Output  ·  Resume  ·  Runtime  ·  Logging"
        )
        advanced_description.setObjectName("muted")
        advanced_description.setWordWrap(True)
        advanced_row.addWidget(advanced_description, 1)
        edit_configuration = QPushButton("EDIT CONFIGURATION")
        edit_configuration.setObjectName("secondaryButton")
        edit_configuration.clicked.connect(self.open_configuration_dialog)
        advanced_row.addWidget(edit_configuration)
        configuration.content().addLayout(advanced_row)
        root.addWidget(configuration)

        self.configuration_summary = ConfigurationSummary()
        self.configuration_summary.editRequested.connect(self.open_configuration_dialog)
        root.addWidget(self.configuration_summary)

        graph = Surface("DEPENDENCY GRAPH", "Why stages are available, selected or waiting")
        self.dependency_graph = DependencyGraphWidget()
        self.dependency_graph.set_modules(self.workflow.modules)
        graph.content().addWidget(self.dependency_graph)
        graph_note = QLabel(
            "Dependencies are explicit: Manifest feeds reconstruction branches; "
            "prepared branches converge on Godot Build, then Validation."
        )
        graph_note.setObjectName("muted")
        graph_note.setWordWrap(True)
        graph.content().addWidget(graph_note)
        root.addWidget(graph)

        plan = Surface("EXECUTION PLAN", "Generated from the selected workflow — preview only")
        plan_header = QHBoxLayout()
        plan_header.addWidget(QLabel("CURRENT EXECUTION PLAN"))
        plan_header.addStretch()
        plan_header.addWidget(Pill("UI PREVIEW", "preview"))
        plan.content().addLayout(plan_header)
        self.execution_plan_layout = QVBoxLayout()
        self.execution_plan_layout.setSpacing(7)
        plan.content().addLayout(self.execution_plan_layout)
        self.execution_plan_stats = QLabel()
        self.execution_plan_stats.setObjectName("executionPlanStats")
        self.execution_plan_stats.setWordWrap(True)
        plan.content().addWidget(self.execution_plan_stats)
        self.refresh_execution_plan()
        root.addWidget(plan)

        actions = QHBoxLayout()
        actions.addStretch()
        actions.addWidget(self._action_button("Run Verification", self.run_verification))
        root.addLayout(actions)

        self._sync_configuration_summary()
        return self.scroll_page(page)

    def refresh_execution_plan(self):
        if not hasattr(self, "execution_plan_layout") and not hasattr(self, "pipeline_execution_layout"):
            return

        modules = self._selected_modules()
        steps = [
            ("01", "Preprocess", "READY", "Normalize the prepared source context.", "Source context"),
            ("02", "Manifest", "READY", "Consume scene structure and placement information.", "58 Level Instances"),
        ]

        if any(m in modules for m in ("Assets", "Static Meshes", "Skeletal Meshes")):
            steps.append(("03", "Mesh Assets", "READY", "Resolve prepared geometry and asset references.", "7,872 placements"))

        if "Landscape" in modules:
            steps.append(("04", "Landscape", "READY", "Rebuild terrain from prepared Landscape data.", "2 landscapes"))

        specialized = [m for m in modules if m in ("Materials", "Decals", "Lighting", "VFX", "Audio")]
        if specialized:
            steps.append(("05", "Specialized Modules", "READY", "Process: " + ", ".join(specialized) + ".", "Selected modules"))

        steps.extend((
            ("06", "Transfer to Godot", "READY", "Prepare the reconstruction payload for the target.", "Prepared payload"),
            ("07", "Godot Import", "READY", "Import prepared assets and scene data.", "Target project"),
            ("08", "Godot Reconstruction", "READY", "Construct the resulting Godot scene.", "Scene generation"),
            ("09", "Validation", "READY", "Run consistency checks and produce the final report.", "Validation report"),
        ))

        if hasattr(self, "execution_plan_layout"):
            while self.execution_plan_layout.count():
                item = self.execution_plan_layout.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.deleteLater()

            for number, title, state, detail, metric in steps:
                row = QFrame()
                row.setObjectName("executionPlanRow")
                row_layout = QHBoxLayout(row)
                row_layout.setContentsMargins(12, 9, 12, 9)
                row_layout.setSpacing(10)
                number_label = QLabel(number)
                number_label.setObjectName("pipelineStageNumber")
                number_label.setFixedWidth(24)
                row_layout.addWidget(number_label)
                title_label = QLabel(title)
                title_label.setObjectName("executionPlanTitle")
                row_layout.addWidget(title_label)
                detail_label = QLabel(detail)
                detail_label.setObjectName("muted")
                detail_label.setWordWrap(True)
                row_layout.addWidget(detail_label, 1)
                row_layout.addWidget(Pill(state, "ready"))
                self.execution_plan_layout.addWidget(row)

        if hasattr(self, "pipeline_execution_layout"):
            while self.pipeline_execution_layout.count():
                item = self.pipeline_execution_layout.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.deleteLater()
            self.pipeline_execution_cards = []

            # Keep the complete dependency map visible, but derive branch states
            # from the actual selected modules instead of pretending that an
            # unselected branch is running. This makes the preview useful as a
            # faithful contract for the future real executor.
            has_assets = any(m in modules for m in ("Assets", "Static Meshes", "Skeletal Meshes"))
            has_landscape = "Landscape" in modules
            specialized = [m for m in modules if m in ("Materials", "Decals", "Lighting", "VFX", "Audio")]
            has_specialized = bool(specialized)
            visual_steps = (
                ("01", "UE5 SOURCE", "READY", "Source context required", "Awaiting real source connection"),
                ("02", "PREPROCESS", "READY", "Input normalization", "Framework-owned stage"),
                ("03", "MANIFEST", "READY", "Scene structure", "Required source of truth"),
                ("04", "ASSETS", "READY" if has_assets else "SKIPPED",
                 "Selected mesh reconstruction branch" if has_assets else "No mesh module selected",
                 "Selected" if has_assets else "Not selected"),
                ("05", "LANDSCAPE", "READY" if has_landscape else "SKIPPED",
                 "Selected terrain reconstruction branch" if has_landscape else "No Landscape module selected",
                 "Selected" if has_landscape else "Not selected"),
                ("06", "SPECIALIZED", "READY" if has_specialized else "SKIPPED",
                 "Selected: " + ", ".join(specialized) if has_specialized else "No specialized module selected",
                 "Selected" if has_specialized else "Not selected"),
                ("07", "GODOT BUILD", "READY", "Target construction stage", "Requires real target project"),
                ("08", "VALIDATION", "READY", "Consistency and report", "Requires completed build"),
                ("09", "RESULT", "PENDING", "Final scene and report", "Available after real execution"),
            )
            for number, title, state, detail, metric in visual_steps:
                card = PipelineStageCard(number, title, state, detail, metric, 78 if title == "ASSETS" else None)
                card.stageClicked.connect(self.on_pipeline_stage_selected)
                self.pipeline_execution_cards.append(card)
                self.pipeline_execution_layout.addWidget(card)

        stats = (
            "Preview workload reference  ·  "
            f"{len(modules)} configured modules  ·  "
            "source metrics become live only after the framework is connected"
        )
        if hasattr(self, "execution_plan_stats"):
            self.execution_plan_stats.setText(stats)
        if hasattr(self, "pipeline_execution_stats"):
            self.pipeline_execution_stats.setText(stats)

    # ------------------------------------------------------------------
    # MODULE CARD
    # ------------------------------------------------------------------

    def create_module_card(self, name: str):

        card = QFrame()
        card.setObjectName("moduleCard")
        card.setCursor(Qt.PointingHandCursor)

        layout = QHBoxLayout(card)
        layout.setContentsMargins(14, 13, 14, 13)
        layout.setSpacing(10)

        checkbox = QCheckBox()
        checkbox.setChecked(
            name in self.workflow.modules
        )
        checkbox.setObjectName("moduleCheck")
        layout.addWidget(
            checkbox,
            0,
            Qt.AlignTop,
        )

        text = QVBoxLayout()
        text.setSpacing(3)

        title = QLabel(name)
        title.setObjectName("moduleTitle")
        text.addWidget(title)

        state = QLabel(
            "Available in framework"
        )
        state.setObjectName("moduleState")
        text.addWidget(state)

        layout.addLayout(text, 1)

        checkbox.stateChanged.connect(
            lambda state_value, module=name:
            self.module_clicked(module, state_value)
        )

        return card

    def module_clicked(self, module: str, state: int):

        self.context.set_module(module)

        selected = []
        for module_name, card in self.module_cards.items():
            checkbox = card.findChild(QCheckBox)
            if checkbox and checkbox.isChecked():
                selected.append(module_name)
        if state:
            self.logs.add(f"Module enabled: {module}")
        else:
            self.logs.add(f"Module disabled: {module}")
        self.selected_modules = selected
        self.current_preset = "custom"
        if hasattr(self, "preset_cards"):
            for card in self.preset_cards.values():
                card.set_selected(False)
        selected = self._selected_modules()
        if hasattr(self, "dependency_graph"):
            self.dependency_graph.set_modules(selected)
        self._sync_configuration_summary()
        self._sync_pipeline_configuration_summary()

    # ------------------------------------------------------------------
    # DEPENDENCY CARD
    # ------------------------------------------------------------------

    def dependency_card(
        self,
        title: str,
        requirement: str,
        state: str,
    ):

        card = QFrame()
        card.setObjectName("dependencyCard")

        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 13, 14, 13)
        layout.setSpacing(6)

        title_label = QLabel(title)
        title_label.setObjectName("dependencyTitle")
        layout.addWidget(title_label)

        requirement_label = QLabel(requirement)
        requirement_label.setObjectName("muted")
        requirement_label.setWordWrap(True)
        layout.addWidget(requirement_label)

        layout.addWidget(
            Pill(
                state,
                "ready" if state == "READY" else "neutral",
            )
        )

        return card

    # ------------------------------------------------------------------
    # PIPELINE
    # ------------------------------------------------------------------

    def build_pipeline_page(self):
        page = QWidget()
        root = QVBoxLayout(page)
        root.setContentsMargins(34, 30, 34, 32)
        root.setSpacing(18)

        title = QLabel("Pipeline")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        subtitle = QLabel(
            "Observe the execution plan, current reconstruction step, live output, "
            "dependencies, validation and final result from one surface."
        )
        subtitle.setObjectName("pageSubtitle")
        subtitle.setWordWrap(True)
        root.addWidget(subtitle)

        banner = QFrame()
        banner.setObjectName("pipelineBanner")
        banner_layout = QHBoxLayout(banner)
        banner_layout.setContentsMargins(20, 17, 20, 17)
        workflow_info = QVBoxLayout()
        self.pipeline_workflow = QLabel("FULL RECONSTRUCTION")
        self.pipeline_workflow.setObjectName("pipelineWorkflow")
        workflow_info.addWidget(self.pipeline_workflow)
        self.pipeline_subtitle = QLabel("UE5 → Godot  ·  Maximum fidelity")
        self.pipeline_subtitle.setObjectName("muted")
        workflow_info.addWidget(self.pipeline_subtitle)
        banner_layout.addLayout(workflow_info)
        banner_layout.addStretch()
        banner_layout.addWidget(Pill("READY TO PREVIEW", "ready"))
        root.addWidget(banner)

        # Configuration summary remains part of the observation surface so the
        # user can verify what the pipeline is observing before any real run.
        self.pipeline_configuration_summary = ConfigurationSummary()
        self.pipeline_configuration_summary.editRequested.connect(self.open_configuration_dialog)
        root.addWidget(self.pipeline_configuration_summary)

        # ================================================================
        # EXECUTION PLAN — primary observation surface
        # ================================================================
        execution = Surface("EXECUTION PLAN", "What the orchestrator is doing, in dependency order")
        execution_header = QHBoxLayout()
        execution_header.addWidget(QLabel("CURRENT EXECUTION PLAN"))
        execution_header.addStretch()
        execution_header.addWidget(Pill("UI PREVIEW", "preview"))
        execution.content().addLayout(execution_header)

        self.pipeline_execution_cards = []
        self.pipeline_execution_layout = QVBoxLayout()
        self.pipeline_execution_layout.setSpacing(7)
        execution.content().addLayout(self.pipeline_execution_layout)

        self.pipeline_execution_stats = QLabel()
        self.pipeline_execution_stats.setObjectName("executionPlanStats")
        self.pipeline_execution_stats.setWordWrap(True)
        execution.content().addWidget(self.pipeline_execution_stats)
        root.addWidget(execution)

        # ================================================================
        # CURRENT STEP + INSPECTOR
        # ================================================================
        current_row = QGridLayout()
        current_row.setHorizontalSpacing(16)
        current_row.setVerticalSpacing(16)

        current = Surface("CURRENT STEP", "Selected pipeline stage")
        current_layout = QVBoxLayout()
        current_layout.setSpacing(7)

        current_header = QHBoxLayout()
        self.pipeline_current_number = QLabel("04")
        self.pipeline_current_number.setObjectName("pipelineCurrentNumber")
        current_header.addWidget(self.pipeline_current_number)
        self.pipeline_current_title = QLabel("ASSET RECONSTRUCTION")
        self.pipeline_current_title.setObjectName("pipelineCurrentTitle")
        current_header.addWidget(self.pipeline_current_title)
        current_header.addStretch()
        self.pipeline_current_state = Pill("RUNNING", "running")
        current_header.addWidget(self.pipeline_current_state)
        current_layout.addLayout(current_header)

        self.pipeline_current_detail = QLabel("Importing mesh placements...")
        self.pipeline_current_detail.setObjectName("pipelineCurrentDetail")
        self.pipeline_current_detail.setWordWrap(True)
        current_layout.addWidget(self.pipeline_current_detail)

        progress_row = QHBoxLayout()
        self.pipeline_current_progress = QProgressBar()
        self.pipeline_current_progress.setRange(0, 100)
        self.pipeline_current_progress.setValue(78)
        self.pipeline_current_progress.setTextVisible(False)
        self.pipeline_current_progress.setObjectName("pipelineCurrentProgress")
        progress_row.addWidget(self.pipeline_current_progress, 1)
        self.pipeline_current_progress_value = QLabel("78%")
        self.pipeline_current_progress_value.setObjectName("pipelineProgressValue")
        progress_row.addWidget(self.pipeline_current_progress_value)
        current_layout.addLayout(progress_row)

        current_note = QLabel(
            "Preview only · no Unreal or Godot process is currently running."
        )
        current_note.setObjectName("muted")
        current_note.setWordWrap(True)
        current_layout.addWidget(current_note)
        current.content().addLayout(current_layout)
        current_row.addWidget(current, 0, 0)

        inspector = Surface("INSPECTOR", "Selected stage details")
        inspector_layout = QVBoxLayout()
        inspector_layout.setSpacing(7)
        self.pipeline_inspector_title = QLabel("ASSET RECONSTRUCTION")
        self.pipeline_inspector_title.setObjectName("pipelineInspectorTitle")
        inspector_layout.addWidget(self.pipeline_inspector_title)
        self.pipeline_inspector_detail = QLabel("Importing mesh placements...")
        self.pipeline_inspector_detail.setObjectName("muted")
        self.pipeline_inspector_detail.setWordWrap(True)
        inspector_layout.addWidget(self.pipeline_inspector_detail)

        self.pipeline_inspector_dependencies = QLabel(
            "Dependencies\n✓ Manifest\n✓ Preprocess"
        )
        self.pipeline_inspector_dependencies.setObjectName("pipelineInspectorText")
        inspector_layout.addWidget(self.pipeline_inspector_dependencies)

        self.pipeline_inspector_metrics = QLabel(
            "Metrics\n7,872 mesh placements\n166 unique meshes"
        )
        self.pipeline_inspector_metrics.setObjectName("pipelineInspectorText")
        inspector_layout.addWidget(self.pipeline_inspector_metrics)
        inspector.content().addLayout(inspector_layout)
        current_row.addWidget(inspector, 0, 1)
        root.addLayout(current_row)

        # ================================================================
        # LIVE OUTPUT + RESULT — existing Level 1–8 content retained
        # ================================================================
        lower = QGridLayout()
        lower.setHorizontalSpacing(16)
        lower.setVerticalSpacing(16)

        output = Surface("LIVE OUTPUT", "Technical execution stream")
        output_editor = QTextEdit()
        output_editor.setReadOnly(True)
        output_editor.setObjectName("pipelineOutput")
        output_editor.setPlainText(
            "[preview] Preflight completed.\n"
            "[preview] Workflow: Full Reconstruction\n"
            "[preview] Manifest: available\n"
            "[preview] Assets: 166 unique meshes\n"
            "[preview] Placements: 7872\n"
            "[preview] Level Instances: 58\n"
            "[preview] Current stage: Assets\n"
            "[preview] Progress: 78%\n"
            "[preview] No real operation is running.\n"
        )
        output.content().addWidget(output_editor)
        lower.addWidget(output, 0, 0)

        result = Surface("RESULT", "Final state preview")
        result_grid = QGridLayout()
        result_grid.setHorizontalSpacing(12)
        result_grid.setVerticalSpacing(12)
        for index, (label, value) in enumerate((
            ("STATUS", "READY"), ("MODULES", "9 / 9"), ("WARNINGS", "0"), ("ERRORS", "0")
        )):
            card = QFrame()
            card.setObjectName("resultMetric")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(12, 11, 12, 11)
            card_layout.setSpacing(4)
            label_widget = QLabel(label)
            label_widget.setObjectName("eyebrow")
            card_layout.addWidget(label_widget)
            value_widget = QLabel(value)
            value_widget.setObjectName("resultValue")
            card_layout.addWidget(value_widget)
            result_grid.addWidget(card, index // 2, index % 2)
        result.content().addLayout(result_grid)
        result_note = QLabel(
            "Final report, scene result and reconstruction diagnostics would appear here after the real pipeline is connected."
        )
        result_note.setObjectName("muted")
        result_note.setWordWrap(True)
        result.content().addWidget(result_note)
        result_actions = QHBoxLayout()
        open_result = QPushButton("Open Result")
        open_result.setObjectName("primaryButton")
        open_result.clicked.connect(lambda: self.select_page(3))
        result_actions.addWidget(open_result)
        result_actions.addWidget(self._action_button("View Report", self.show_build_report))
        result_actions.addStretch()
        result.content().addLayout(result_actions)
        lower.addWidget(result, 0, 1)
        root.addLayout(lower)

        # ================================================================
        # EXISTING OVERVIEW — retained so Level 1–8 information is not lost
        # ================================================================
        overview = Surface("PIPELINE OVERVIEW", "UE5 source → final validated result")
        overview_grid = QGridLayout()
        overview_grid.setHorizontalSpacing(10)
        overview_grid.setVerticalSpacing(10)
        self.pipeline_overview_cards = {}
        overview_specs = (
            ("01", "UE5 SOURCE", "READY", "Prepared source context", "58 Level Instances"),
            ("02", "PREPROCESS", "COMPLETED", "Input normalization", "Preview stage"),
            ("03", "MANIFEST", "COMPLETED", "Scene structure", "7,872 placements"),
            ("04", "ASSETS", "RUNNING", "Importing assets", "1,942 / 2,368", 78),
            ("05", "LANDSCAPE", "PENDING", "Terrain reconstruction", "Waiting for dependencies"),
            ("06", "SPECIALIZED", "PENDING", "Materials / VFX / audio", "Selected modules"),
            ("07", "GODOT BUILD", "PENDING", "Scene construction", "Waiting for prepared data"),
            ("08", "VALIDATION", "PENDING", "Consistency and report", "Waiting for build"),
            ("09", "RESULT", "PENDING", "Final scene and report", "Waiting for validation"),
        )
        for index, spec in enumerate(overview_specs):
            number, name, state, detail, metric, *progress = spec
            card = PipelineStageCard(number, name, state, detail, metric, progress[0] if progress else None)
            card.stageClicked.connect(self.on_pipeline_stage_selected)
            self.pipeline_overview_cards[name] = card
            overview_grid.addWidget(card, index // 3, index % 3)
        overview.content().addLayout(overview_grid)
        root.addWidget(overview)

        validation = self.validation_dashboard = ValidationDashboard()
        validation.set_rows((
            ("Meshes", "7,872", "7,872", "✓"),
            ("Unique meshes", "166", "166", "✓"),
            ("Level Instances", "58", "58", "✓"),
            ("Decal markers", "—", "—", "✓"),
            ("VFX markers", "—", "—", "✓"),
        ))
        root.addWidget(validation)

        issues = IssuesCenter()
        root.addWidget(issues)

        actions = QHBoxLayout()
        actions.setSpacing(10)
        actions.addWidget(self._action_button("Unreal Exports", self.run_unreal_exports))
        actions.addWidget(self._action_button("Build in Godot", self.run_godot_build))
        actions.addWidget(self._action_button("Details", self.toggle_logs))
        actions.addStretch()
        run = QPushButton("Run preflight preview  →")
        run.setObjectName("primaryButton")
        run.clicked.connect(lambda: self.logs.add("Preflight preview requested: configuration, dependencies and selected branches reviewed."))
        actions.addWidget(run)
        root.addLayout(actions)

        self.refresh_execution_plan()
        self._sync_pipeline_configuration_summary()
        self.on_pipeline_stage_selected("04", "ASSETS", "RUNNING", "Importing mesh placements...", "1,942 / 2,368")
        return self.scroll_page(page)

    def on_pipeline_stage_selected(self, number, title, state, detail, metric):
        """Update the Current Step and Inspector from any selected pipeline stage."""
        if not hasattr(self, "pipeline_current_title"):
            return

        self.pipeline_current_number.setText(number)
        self.pipeline_current_title.setText(title)
        self.pipeline_current_detail.setText(detail)
        self.pipeline_current_state.setText(state)
        self.pipeline_inspector_title.setText(title)
        self.pipeline_inspector_detail.setText(detail)

        progress = 78 if title == "ASSETS" else 0
        self.pipeline_current_progress.setValue(progress)
        self.pipeline_current_progress_value.setText(f"{progress}%")

        dependency_map = {
            "UE5 SOURCE": "Dependencies\n✓ Source context",
            "PREPROCESS": "Dependencies\n✓ UE5 Source",
            "MANIFEST": "Dependencies\n✓ Preprocess",
            "ASSETS": "Dependencies\n✓ Manifest\n✓ Preprocess",
            "LANDSCAPE": "Dependencies\n✓ Manifest",
            "SPECIALIZED": "Dependencies\n✓ Manifest\n✓ Selected modules",
            "GODOT BUILD": "Dependencies\n✓ Prepared reconstruction branches",
            "VALIDATION": "Dependencies\n✓ Godot Build",
            "RESULT": "Dependencies\n✓ Validation",
        }
        self.pipeline_inspector_dependencies.setText(dependency_map.get(title, "Dependencies\nPreview stage"))
        self.pipeline_inspector_metrics.setText(
            f"Metrics\n{metric or 'No stage-specific metric'}\n\nState: {state}"
        )

        # Keep the existing overview cards visually linked to the selected stage.
        for card_title, card in getattr(self, "pipeline_overview_cards", {}).items():
            card.setProperty("selected", card_title == title)
            card.style().unpolish(card)
            card.style().polish(card)

    def build_result_page(self):
        page = QWidget()
        root = QVBoxLayout(page)
        root.setContentsMargins(34, 30, 34, 32)
        root.setSpacing(18)

        title = QLabel("Result")
        title.setObjectName("pageTitle")
        root.addWidget(title)

        subtitle = QLabel(
            "Final reconstruction state, validation summary and output actions. "
            "All values shown here are representative preview data."
        )
        subtitle.setObjectName("pageSubtitle")
        subtitle.setWordWrap(True)
        root.addWidget(subtitle)

        hero = QFrame()
        hero.setObjectName("resultHero")
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(28, 24, 28, 24)
        hero_layout.setSpacing(24)

        status_box = QVBoxLayout()
        status_box.setSpacing(5)
        eyebrow = QLabel("RESULT PREVIEW")
        eyebrow.setObjectName("eyebrow")
        status_box.addWidget(eyebrow)
        check = QLabel("✓")
        check.setObjectName("resultCheck")
        status_box.addWidget(check)
        success = QLabel("NO EXECUTION PERFORMED")
        success.setObjectName("resultSuccess")
        status_box.addWidget(success)
        hero_layout.addLayout(status_box)
        hero_layout.addStretch()

        target_box = QVBoxLayout()
        target_box.setSpacing(5)
        target_label = QLabel("TARGET")
        target_label.setObjectName("eyebrow")
        target_box.addWidget(target_label)
        target = QLabel("Target project — not connected")
        target.setObjectName("resultTarget")
        target_box.addWidget(target)
        duration = QLabel("Duration   —  ·  No real run")
        duration.setObjectName("muted")
        target_box.addWidget(duration)
        hero_layout.addLayout(target_box)
        root.addWidget(hero)

        metrics = Surface("RECONSTRUCTION SUMMARY", "Representative values — replaced by live results after integration")
        metric_grid = QGridLayout()
        metric_grid.setHorizontalSpacing(12)
        metric_grid.setVerticalSpacing(12)
        for index, (value, label) in enumerate((
            ("7,872", "MESH PLACEMENTS"),
            ("166", "UNIQUE MESHES"),
            ("58", "LEVEL INSTANCES"),
            ("43", "MATERIALS"),
        )):
            card = QFrame()
            card.setObjectName("resultMetricLarge")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(16, 15, 16, 15)
            value_widget = QLabel(value)
            value_widget.setObjectName("resultMetricNumber")
            card_layout.addWidget(value_widget)
            label_widget = QLabel(label)
            label_widget.setObjectName("eyebrow")
            card_layout.addWidget(label_widget)
            metric_grid.addWidget(card, 0, index)
        metrics.content().addLayout(metric_grid)
        root.addWidget(metrics)

        lower = QGridLayout()
        lower.setHorizontalSpacing(16)
        lower.setVerticalSpacing(16)

        validation = Surface("VALIDATION", "Final checks")
        checks = (
            ("Structure", "Validated"),
            ("Assets", "Validated"),
            ("Placements", "Validated"),
            ("Scene generation", "Validated"),
        )
        for name, state in checks:
            row = QHBoxLayout()
            icon = QLabel("✓")
            icon.setObjectName("resultValidationIcon")
            row.addWidget(icon)
            label = QLabel(name)
            row.addWidget(label)
            row.addStretch()
            value = QLabel(state)
            value.setObjectName("muted")
            row.addWidget(value)
            validation.content().addLayout(row)
        lower.addWidget(validation, 0, 0)

        warnings = Surface("WARNINGS", "Non-blocking findings")
        warning_value = QLabel("7")
        warning_value.setObjectName("resultWarningNumber")
        warnings.content().addWidget(warning_value)
        warning_text = QLabel(
            "Warnings were retained in the final report. They do not block the "
            "preview build result."
        )
        warning_text.setObjectName("muted")
        warning_text.setWordWrap(True)
        warnings.content().addWidget(warning_text)
        lower.addWidget(warnings, 0, 1)
        root.addLayout(lower)

        actions = QHBoxLayout()
        actions.setSpacing(10)
        open_project = self._action_button("OPEN GODOT PROJECT", self.open_godot_project)
        output = self._action_button("OPEN OUTPUT", self.open_output_folder)
        report = QPushButton("VIEW REPORT")
        report.setObjectName("primaryButton")
        actions.addWidget(open_project)
        actions.addWidget(output)
        actions.addWidget(report)
        actions.addStretch()
        root.addLayout(actions)

        note = QLabel(
            "Ces actions ouvrent réellement le projet Godot et le dossier de sortie."
        )
        note.setObjectName("muted")
        root.addWidget(note)
        return self.scroll_page(page)

    # ------------------------------------------------------------------
    # SCROLL
    # ------------------------------------------------------------------

    @staticmethod
    def scroll_page(widget):

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarAlwaysOff
        )
        scroll.setWidget(widget)

        return scroll

    # ------------------------------------------------------------------
    # USER MODES
    # ------------------------------------------------------------------

    def show_mode_chooser(self):
        """Launch-only interface selector. It is never used by mode switching."""
        self.mode_chooser = True
        self.pages.setCurrentIndex(0)
        if hasattr(self, "header_widget"):
            self.header_widget.setVisible(False)
        self.command_strip.setVisible(False)
        self.sidebar.setVisible(False)
        self.context.setVisible(False)
        self.logs.setVisible(False)
        for name in (
            "header_context_button", "header_logs_button",
            "header_edit_button", "mode_button", "status_bar_widget"
        ):
            if hasattr(self, name):
                getattr(self, name).setVisible(False)
        self.header_page.setText("Choose interface")

    def choose_mode(self, mode):
        """Enter one of the two real working interfaces from the launch chooser."""
        self.mode_chooser = False
        if mode == "simple":
            self.show_simple_mode()
        else:
            self.enter_advanced_mode(reset_page=True)

    def show_simple_mode(self):
        """Show the Simple interface without touching Advanced navigation state."""
        self.simple_mode = True
        self.mode_chooser = False
        if hasattr(self, "header_widget"):
            self.header_widget.setVisible(True)
        self.pages.setCurrentIndex(1)
        self.command_strip.setVisible(False)
        self.sidebar.setVisible(False)
        self.context.setVisible(False)
        self.logs.setVisible(False)
        for name in (
            "header_context_button", "header_logs_button",
            "header_edit_button", "status_bar_widget"
        ):
            if hasattr(self, name):
                getattr(self, name).setVisible(False)
        if hasattr(self, "mode_button"):
            self.mode_button.setVisible(True)
            self.mode_button.setText("Advanced mode")
            self.mode_button.setToolTip("Switch directly to the Advanced interface")
        self.header_page.setText("Simple interface")

    def enter_advanced_mode(self, keep_page=False, reset_page=False):
        """Enter Advanced directly; the chooser is never part of this transition."""
        self.simple_mode = False
        self.mode_chooser = False
        if reset_page:
            self.advanced_page = 0
        elif keep_page:
            self.advanced_page = max(0, min(self.advanced_page, 3))

        self.current_page = self.advanced_page
        if hasattr(self, "header_widget"):
            self.header_widget.setVisible(True)
        self.command_strip.setVisible(True)
        self.sidebar.setVisible(self.sidebar_visible and not self.focus_mode)
        self.context.setVisible(self.context_visible and not self.focus_mode)
        self.logs.setVisible(self.logs_visible and not self.focus_mode)
        for name in (
            "header_context_button", "header_logs_button",
            "header_edit_button", "status_bar_widget"
        ):
            if hasattr(self, name):
                getattr(self, name).setVisible(True)
        if hasattr(self, "mode_button"):
            self.mode_button.setVisible(True)
            self.mode_button.setText("Simple mode")
            self.mode_button.setToolTip("Switch directly to the Simple interface")
        self.select_page(self.advanced_page)

    def toggle_user_mode(self):
        """Directly toggle Simple <-> Advanced. The chooser is launch-only."""
        if self.mode_chooser:
            return
        if self.simple_mode:
            self.enter_advanced_mode(keep_page=True)
        else:
            self.show_simple_mode()

    # ------------------------------------------------------------------
    # NAVIGATION
    # ------------------------------------------------------------------

    def select_page(self, index: int):

        # Advanced navigation is completely independent from the launch chooser
        # and from the Simple wizard. Navigation controls are simply disabled
        # while Simple/Chooser is active; they never trigger a mode transition.
        if self.simple_mode or self.mode_chooser:
            return
        index = max(0, min(int(index), 3))
        self.current_page = index
        self.advanced_page = index

        self.pages.setCurrentIndex(index + 2)
        self.sidebar.set_current_page(index)

        names = (
            "01 Action",
            "02 Project & Configuration",
            "03 Pipeline",
            "04 Result",
        )

        self.header_page.setText(names[index])

        self.status_message.setText(
            f"●  {names[index]}  ·  Preview"
        )

        self._update_command_strip(index)

    def select_workflow(self, key: str):
        self.workflow = next(workflow for workflow in WORKFLOWS if workflow.key == key)
        self.selected_modules = list(self.workflow.modules)
        self.current_preset = "custom" if key == "custom" else next(
            (preset_key for preset_key, _, _, workflow_key, _ in PRESETS if workflow_key == key),
            "custom",
        )
        self.sidebar.set_workflow(self.workflow)
        self.context.set_workflow(self.workflow)
        if hasattr(self, "dependency_graph"):
            self.dependency_graph.set_modules(self.workflow.modules)
        if hasattr(self, "pipeline_workflow"):
            self.pipeline_workflow.setText(self.workflow.title.upper())
            self.pipeline_subtitle.setText(f"UE5 → Godot  ·  {self.workflow.subtitle}")
        self.refresh_execution_plan()
        self._sync_configuration_summary()
        self._sync_pipeline_configuration_summary()
        if hasattr(self, "preset_cards"):
            for preset_key, card in self.preset_cards.items():
                card.set_selected(preset_key == self.current_preset)
        self.logs.add(f"Workflow selected: {self.workflow.title}")
        self.select_page(1)

    def select_preset(self, key: str):
        preset = next(item for item in PRESETS if item[0] == key)
        _, title, _, workflow_key, fidelity = preset
        self.current_preset = key
        if workflow_key != "custom":
            workflow = next(item for item in WORKFLOWS if item.key == workflow_key)
            self.workflow = workflow
            self.objective_value = "Scene Reconstruction" if key == "maximum" else (
                "Geometry" if key == "geometry" else "Environment"
            )
            self.fidelity_value = fidelity
            if hasattr(self, "objective_combo"):
                self.objective_combo.blockSignals(True)
                self.objective_combo.setCurrentText(self.objective_value)
                self.objective_combo.blockSignals(False)
            if hasattr(self, "fidelity_combo"):
                self.fidelity_combo.blockSignals(True)
                self.fidelity_combo.setCurrentText(fidelity)
                self.fidelity_combo.blockSignals(False)
            self.selected_modules = list(workflow.modules)
            for module, card in self.module_cards.items():
                checkbox = card.findChild(QCheckBox)
                if checkbox:
                    checkbox.blockSignals(True)
                    checkbox.setChecked(module in self.selected_modules)
                    checkbox.blockSignals(False)
        else:
            self.objective_value = "Custom"
            self.selected_modules = self._selected_modules()
        self.sidebar.set_workflow(self.workflow)
        self.context.set_workflow(self.workflow)
        if hasattr(self, "dependency_graph"):
            self.dependency_graph.set_modules(self.workflow.modules)
        self.refresh_execution_plan()
        self._sync_configuration_summary()
        self._sync_pipeline_configuration_summary()
        for preset_key, card in getattr(self, "preset_cards", {}).items():
            card.set_selected(preset_key == key)
        self.logs.add(f"Preset selected: {title}")

    def on_configuration_changed(self, _value: str):
        self.current_preset = "custom"
        self.objective_value = self.objective_combo.currentText()
        self.fidelity_value = self.fidelity_combo.currentText()
        if hasattr(self, "vfx_combo"):
            self.vfx_value = self.vfx_combo.currentText()
        self.selected_modules = self._selected_modules()
        for card in getattr(self, "preset_cards", {}).values():
            card.set_selected(False)
        self._sync_configuration_summary()
        self._sync_pipeline_configuration_summary()

    def _selected_modules(self):
        return list(self.selected_modules)

    def apply_configuration(self, objective: str, fidelity: str, vfx_mode: str, modules, source: str = "Configuration"):
        self.objective_value = objective
        self.fidelity_value = fidelity
        self.vfx_value = vfx_mode
        self.selected_modules = list(modules) or ["Manifest", "Godot", "Validation"]
        self.current_preset = "custom"

        # Keep the workflow object generic while allowing the submitted module matrix
        # to become the shared configuration state. The Custom workflow represents this composition.
        custom = next(item for item in WORKFLOWS if item.key == "custom")
        self.workflow = custom
        self.sidebar.set_workflow(self.workflow)
        self.context.set_workflow(self.workflow)
        if hasattr(self, "pipeline_workflow"):
            self.pipeline_workflow.setText(self.workflow.title.upper())
            self.pipeline_subtitle.setText(f"UE5 → Godot  ·  {self.workflow.subtitle}")

        if hasattr(self, "module_cards"):
            for module, card in self.module_cards.items():
                checkbox = card.findChild(QCheckBox)
                if checkbox:
                    checkbox.blockSignals(True)
                    checkbox.setChecked(module in self.selected_modules)
                    checkbox.blockSignals(False)

        if hasattr(self, "objective_combo"):
            self.objective_combo.blockSignals(True)
            self.objective_combo.setCurrentText(self.objective_value)
            self.objective_combo.blockSignals(False)
        if hasattr(self, "fidelity_combo"):
            self.fidelity_combo.blockSignals(True)
            self.fidelity_combo.setCurrentText(self.fidelity_value)
            self.fidelity_combo.blockSignals(False)
        if hasattr(self, "vfx_combo"):
            self.vfx_combo.blockSignals(True)
            self.vfx_combo.setCurrentText(self.vfx_value)
            self.vfx_combo.blockSignals(False)

        if hasattr(self, "preset_cards"):
            for card in self.preset_cards.values():
                card.set_selected(False)
        if hasattr(self, "dependency_graph"):
            self.dependency_graph.set_modules(self.selected_modules)
        self.refresh_execution_plan()
        self._sync_configuration_summary()
        self._sync_pipeline_configuration_summary()
        self.logs.add(f"Configuration applied from {source}.")

    def open_configuration_dialog(self):
        dialog = ConfigurationDialog(self)
        dialog.exec()

    def _sync_configuration_summary(self):
        if hasattr(self, "objective_combo"):
            self.objective_combo.blockSignals(True)
            self.objective_combo.setCurrentText(self.objective_value)
            self.objective_combo.blockSignals(False)
        if hasattr(self, "fidelity_combo"):
            self.fidelity_combo.blockSignals(True)
            self.fidelity_combo.setCurrentText(self.fidelity_value)
            self.fidelity_combo.blockSignals(False)
        if hasattr(self, "vfx_combo"):
            self.vfx_combo.blockSignals(True)
            self.vfx_combo.setCurrentText(self.vfx_value)
            self.vfx_combo.blockSignals(False)
        if not hasattr(self, "configuration_summary"):
            return
        self.configuration_summary.set_configuration(
            next(title for key, title, _, _, _ in PRESETS if key == self.current_preset),
            self.objective_value,
            self.fidelity_value,
            self._selected_modules(),
            self.vfx_value,
            self.advanced_configured,
        )

    def _sync_pipeline_configuration_summary(self):
        if not hasattr(self, "pipeline_configuration_summary"):
            return
        self.pipeline_configuration_summary.set_configuration(
            next(title for key, title, _, _, _ in PRESETS if key == self.current_preset),
            self.objective_value,
            self.fidelity_value,
            self._selected_modules(),
            self.vfx_value,
            self.advanced_configured,
        )

    # ------------------------------------------------------------------
    # SHELL TOGGLES
    # ------------------------------------------------------------------

    def toggle_sidebar(self):
        self.sidebar_visible = not self.sidebar_visible
        self.sidebar.setVisible(self.sidebar_visible and not self.focus_mode)
        if hasattr(self, "sidebar"):
            self.sidebar.toggle_button.setText("Hide Sidebar" if self.sidebar_visible else "Show Sidebar")

    def toggle_context(self):
        self.context_visible = not self.context_visible
        self.context.setVisible(self.context_visible and not self.focus_mode)
        if hasattr(self, "context"):
            self.context.hide_button.setText("Hide" if self.context_visible else "Show")

    def toggle_logs(self):
        self.logs_visible = not self.logs_visible
        self.logs.setVisible(self.logs_visible and not self.focus_mode)
        if hasattr(self, "logs"):
            self.logs.hide_button.setText("Hide" if self.logs_visible else "Show")
        if hasattr(self, "shell_splitter"):
            self.shell_splitter.setSizes([930, 0] if not self.logs_visible else [650, 285])

    def toggle_theme(self):
        self.theme_mode = "light" if self.theme_mode == "dark" else "dark"
        self.apply_theme()
        if hasattr(self, "theme_button"):
            self.theme_button.setText("☾ Dark" if self.theme_mode == "light" else "☀ Light")
            self.theme_button.setToolTip(
                "Switch to dark theme" if self.theme_mode == "light" else "Switch to light theme"
            )

    # ------------------------------------------------------------------
    # HELP
    # ------------------------------------------------------------------

    def show_help(self):

        QMessageBox.information(
            self,
            "UE2Godot Studio",
            "Standalone UI / UX Preview\n\n"
            "This application is intentionally disconnected from "
            "the UE2Godot framework.\n\n"
            "Nothing is read, created, modified or executed.",
        )

    # ------------------------------------------------------------------
    # SMALL HELPERS
    # ------------------------------------------------------------------

    @staticmethod
    def field_label(text: str):

        label = QLabel(text)
        label.setObjectName("fieldLabel")
        return label

    # ------------------------------------------------------------------
    # THEME
    # ------------------------------------------------------------------

    @staticmethod
    def _light_theme_stylesheet(stylesheet: str) -> str:
        """Derive the light theme from the same complete stylesheet.

        Property-aware replacement keeps dialog widgets, scroll areas, lists,
        buttons and custom surfaces on the same light visual language.
        """
        import re

        def background(match):
            value = match.group(1).lower()
            if value in ("#ffffff",):
                return "background: #ffffff"
            if value in ("#0e1117", "#13171f", "#151923"):
                return "background: #f4f6f9"
            if value in ("#151a22", "#151a23", "#151a23"):
                return "background: #ffffff"
            if value in ("#181d27", "#191e27", "#191e28", "#191e29", "#1a1f29", "#1b2029", "#1b202a", "#1d232d", "#1d232e", "#1e2430", "#202632", "#202633", "#222832", "#222833", "#242b38", "#252c38", "#252c39"):
                return "background: #f8fafc"
            return "background: #ffffff"

        def border(match):
            return "border: " + ("1px solid #d7dde6" if match.group(1).lower() != "transparent" else "1px solid transparent")

        def color(match):
            value = match.group(1).lower()
            accents = {
                "#8b7cff": "#635bdb", "#9b91ff": "#635bdb", "#9d95ff": "#635bdb",
                "#a59dff": "#635bdb", "#a9a1ff": "#635bdb", "#b4abff": "#635bdb",
                "#b6adff": "#635bdb", "#6f63dc": "#5147c9", "#7b70e6": "#5147c9",
                "#4fc39b": "#23845f", "#8fd0b2": "#23845f", "#91d0b3": "#23845f",
                "#9ad3b5": "#23845f", "#9ed4b8": "#23845f", "#e4b56f": "#a85f00",
                "#e4a94d": "#a85f00", "#dc7181": "#b4233a", "#e99aaa": "#b4233a",
                "#5c9cff": "#245bb5",
            }
            if value in accents:
                return "color: " + accents[value]
            if value in ("#ffffff", "#f2f4f7", "#f1f4f8", "#f0f2f5", "#e7eaf0", "#e8ebef", "#e8ebf0", "#e6e9ee", "#e5e8ee", "#e4e7ec", "#dfe3e9", "#dce0e7", "#dce2ea", "#d8dce3", "#d8dde6", "#d9dde4", "#d7dbe3", "#cfd4dc", "#cdd2da", "#c9ced8", "#c7ccd5", "#b8bec9", "#b7beca", "#abb3c0", "#aeb5c1", "#aeb5c2", "#aeb6c4", "#a9b0bd"):
                return "color: #1f2937"
            if value in ("#5e6675", "#687181", "#6e7787", "#727b8a", "#727b8b", "#727b8c", "#747d8d", "#7e8797", "#7f8898", "#7f8998", "#858e9e", "#8e97a6", "#9098a7", "#9098a8", "#929aaa", "#969eae", "#9aa2b0", "#9ba3b2"):
                return "color: #5f6b7a"
            if value.startswith("#"):
                try:
                    rgb = tuple(int(value[i:i+2], 16) for i in (1,3,5))
                    lum = sum(rgb) / 3
                    if lum < 100:
                        return "color: #263241"
                    if lum > 180:
                        return "color: #1f2937"
                except ValueError:
                    pass
            return "color: " + value

        stylesheet = re.sub(r"background:\s*(#[0-9a-fA-F]{6})", background, stylesheet)
        stylesheet = re.sub(r"border:\s*1px solid\s*(#[0-9a-fA-F]{6})", border, stylesheet)
        stylesheet = re.sub(r"border-color:\s*(#[0-9a-fA-F]{6})", lambda m: "border-color: #cbd3df", stylesheet)
        stylesheet = re.sub(r"color:\s*(#[0-9a-fA-F]{6})", color, stylesheet)
        stylesheet = stylesheet.replace("selection-background-color: #252c39", "selection-background-color: #e4e9f0")
        return stylesheet

    def apply_theme(self):

        # ================================================================
        # THEME SYSTEM
        #
        # One visual language is maintained for the entire shell, including
        # dialogs. The light theme is derived from the same selectors so
        # dialogs cannot accidentally remain dark while the shell changes.
        #
        # Dark visual hierarchy:
        #
        #   #0e1117  application background
        #   #151923  main surfaces
        #   #191e29  elevated surfaces
        #   #1e2430  interactive surfaces
        #   #252c39  borders
        #
        # The goal is contrast through surface hierarchy, not through
        # making every component almost black.
        # ================================================================

        dark_stylesheet = r"""
            /* ============================================================
               GLOBAL
               ============================================================ */

            QWidget {
                background: #0e1117;
                color: #e7eaf0;
                font-family: "Segoe UI";
                font-size: 13px;
            }

            QMainWindow,
            QScrollArea,
    QSplitter,
            QScrollArea > QWidget > QWidget {
                background: #0e1117;
            }

            QLabel {
                background: transparent;
            }

            /* ============================================================
               HEADER
               ============================================================ */

            #header {
                background: #151923;
                border-bottom: 1px solid #2a303c;
            }

            #headerLogo {
                color: #ffffff;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: 1px;
            }

            #headerPage {
                color: #aeb5c2;
                font-size: 13px;
            }

            #headerButton,
            #headerIcon {
                background: #1d232e;
                border: 1px solid #303744;
                border-radius: 7px;
                color: #d7dbe3;
                padding: 7px 12px;
            }

            #headerButton:hover,
            #headerIcon:hover {
                background: #252c38;
                border-color: #434c5c;
            }

            /* ============================================================
               SIDEBAR
               ============================================================ */

            #sidebar {
                background: #13171f;
                border-right: 1px solid #2a303c;
                min-width: 215px;
                max-width: 215px;
            }

            #brand {
                color: #ffffff;
                font-size: 25px;
                font-weight: 850;
                padding-left: 6px;
                padding-top: 2px;
            }

            #brandName {
                color: #7f8898;
                font-size: 11px;
                padding-left: 7px;
            }

            #sidebarSection {
                color: #687181;
                font-size: 10px;
                font-weight: 750;
                letter-spacing: 1.3px;
                padding-left: 6px;
            }

            #navButton {
                background: transparent;
                border: 1px solid transparent;
                border-radius: 8px;
                color: #9098a8;
                min-height: 43px;
                padding: 9px 11px;
                text-align: left;
            }

            #navButton:hover {
                background: #1b202a;
                color: #e5e8ee;
            }

            #navButton:checked {
                background: #202632;
                border-color: #343c4b;
                color: #ffffff;
            }

            #sidebarCurrent {
                background: #1a1f29;
                border: 1px solid #292f3b;
                border-radius: 8px;
                color: #c9ced8;
                padding: 11px 12px;
            }

            #sidebarState {
                background: #191e27;
                border: 1px solid #2a303b;
                border-radius: 9px;
            }

            #sidebarStateTitle {
                color: #687181;
                font-size: 9px;
                font-weight: 750;
                letter-spacing: 1px;
            }

            #readyText {
                color: #8fd0b2;
                font-weight: 650;
            }

            #sidebarHint {
                color: #5e6675;
                font-size: 9px;
                letter-spacing: 1.2px;
                padding-top: 8px;
            }

            /* ============================================================
               PAGE
               ============================================================ */

            #pageTitle {
                color: #ffffff;
                font-size: 29px;
                font-weight: 780;
            }

            #pageSubtitle {
                color: #969eae;
                font-size: 14px;
                line-height: 1.4;
            }

            /* ============================================================
               SURFACES
               ============================================================ */

            #surface {
                background: #151a23;
                border: 1px solid #2a303c;
                border-radius: 11px;
            }

            #surfaceTitle {
                color: #f2f4f7;
                font-size: 14px;
                font-weight: 750;
                letter-spacing: 0.2px;
            }

            #surfaceSubtitle {
                color: #727b8c;
                font-size: 11px;
            }

            #introBanner {
                background: #181d27;
                border: 1px solid #2d3441;
                border-radius: 10px;
            }

            #introText {
                color: #b8bec9;
                line-height: 1.35;
            }

            /* ============================================================
               WORKFLOW CARDS
               ============================================================ */

            #workflowCard {
                background: #181d27;
                border: 1px solid #2c333f;
                border-radius: 11px;
            }

            #workflowCard:hover {
                background: #1d232e;
                border-color: #4a5363;
            }

            #workflowNumber {
                color: #9b91ff;
                font-size: 11px;
                font-weight: 850;
            }

            #workflowTitle {
                color: #ffffff;
                font-size: 18px;
                font-weight: 750;
            }

            #workflowSubtitle {
                color: #b7beca;
                font-size: 13px;
                font-weight: 650;
            }

            #workflowDescription {
                color: #858e9e;
                line-height: 1.4;
            }

            #moduleChip {
                background: #222833;
                border: 1px solid #303744;
                border-radius: 7px;
                color: #9098a7;
                font-size: 10px;
                padding: 4px 7px;
            }

            #cardAction {
                color: #a9a1ff;
                font-size: 11px;
                font-weight: 650;
            }

            /* ============================================================
               CONTEXT
               ============================================================ */

            #contextPanel {
                background: #151a23;
                border-left: 1px solid #2a303c;
                min-width: 275px;
                max-width: 275px;
            }

            #panelTitle {
                color: #f0f2f5;
                font-size: 11px;
                font-weight: 800;
                letter-spacing: 1.2px;
            }

            #contextWorkflow {
                color: #ffffff;
                font-size: 19px;
                font-weight: 760;
            }

            #contextModuleTitle {
                color: #e8ebf0;
                font-size: 16px;
                font-weight: 700;
            }

            #contextDescription {
                color: #929aaa;
                line-height: 1.4;
            }

            #contextNote {
                background: #1b2029;
                border: 1px solid #2d3440;
                border-radius: 8px;
            }

            #noteTitle {
                color: #c7ccd5;
                font-size: 11px;
                font-weight: 700;
            }

            #separator {
                background: #2a303b;
            }

            /* ============================================================
               MODULE CARDS
               ============================================================ */

            #moduleCard {
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 9px;
            }

            #moduleCard:hover {
                background: #1e2430;
                border-color: #404957;
            }

            #moduleTitle {
                color: #d9dde4;
                font-weight: 650;
            }

            #moduleState {
                color: #727b8a;
                font-size: 10px;
            }

            #moduleCheck {
                spacing: 6px;
            }

            #moduleCheck::indicator {
                width: 16px;
                height: 16px;
            }

            /* ============================================================
               DEPENDENCIES
               ============================================================ */

            #dependencyCard {
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 8px;
            }

            #dependencyTitle {
                color: #dce0e7;
                font-weight: 700;
            }

            /* ============================================================
               CONFIGURATION / PRESETS / VALIDATION
               ============================================================ */

            #configurationSummary,
            #validationDashboard,
            #issuesCenter {
                background: #151a23;
                border: 1px solid #2a303c;
                border-radius: 11px;
            }

            #configSummaryValue {
                color: #cfd4dc;
                font-size: 11px;
                font-weight: 600;
            }

            #configSummaryModules {
                color: #a9b0bd;
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 7px;
                padding: 8px 10px;
            }

            #presetCard {
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 8px;
            }

            #presetCard:hover {
                background: #1e2430;
                border-color: #404957;
            }

            #presetTitle {
                color: #e4e7ec;
                font-weight: 700;
            }

            #presetRadio::indicator {
                width: 16px;
                height: 16px;
            }

            #validationCell,
            #validationCellState {
                color: #b8bec9;
                font-size: 11px;
                padding: 4px 0;
            }

            #validationCellState {
                color: #91d0b3;
                font-weight: 800;
            }

            #validationChecks {
                color: #9ed4b8;
                background: #19251f;
                border: 1px solid #2e4d3c;
                border-radius: 7px;
                padding: 8px 10px;
            }

            #validationScore {
                color: #b6adff;
                font-size: 12px;
                font-weight: 800;
                letter-spacing: 0.5px;
            }

            #issueRow {
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 7px;
            }

            #issueTitle {
                color: #dfe3e9;
                font-weight: 700;
            }

            #mutueIssue {
                color: #9ba3b2;
                font-size: 10px;
            }

            /* ============================================================
               PIPELINE
               ============================================================ */

            #pipelineStageCard {
                background: #191e28;
                border: 1px solid #2a313d;
                border-radius: 9px;
            }

            #pipelineStageCard:hover {
                background: #1e2430;
                border-color: #404957;
            }

            #pipelineStageCard[selected="true"] {
                background: #202633;
                border-color: #625bd1;
            }

            #pipelineCurrentNumber {
                color: #9d95ff;
                font-size: 12px;
                font-weight: 850;
                min-width: 24px;
            }

            #pipelineCurrentTitle {
                color: #f0f2f5;
                font-size: 14px;
                font-weight: 800;
                letter-spacing: 0.2px;
            }

            #pipelineCurrentDetail {
                color: #b8bec9;
                font-size: 12px;
            }

            #pipelineCurrentProgress {
                background: #222833;
                border: 1px solid #303744;
                border-radius: 4px;
                height: 8px;
            }

            #pipelineCurrentProgress::chunk {
                background: #7b70e6;
                border-radius: 4px;
            }

            #pipelineInspectorTitle {
                color: #e8ebef;
                font-size: 12px;
                font-weight: 800;
            }

            #pipelineInspectorText {
                color: #9fa7b5;
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 7px;
                padding: 8px 10px;
                font-size: 10px;
            }

            #pipelineStageNumber {
                color: #9d95ff;
                font-size: 10px;
                font-weight: 850;
            }

            #pipelineStageTitle {
                color: #e8ebef;
                font-size: 12px;
                font-weight: 750;
            }

            #pipelineStageDetail {
                color: #9aa2b0;
                font-size: 10px;
            }

            #pipelineStageMetric,
            #executionPlanStats {
                color: #7f8998;
                font-size: 10px;
            }

            #pipelineProgress {
                background: #222833;
                border: 1px solid #303744;
                border-radius: 4px;
                height: 6px;
            }

            #pipelineProgress::chunk {
                background: #7b70e6;
                border-radius: 4px;
            }

            #pipelineProgressValue {
                color: #b6adff;
                font-size: 9px;
                font-weight: 750;
            }

            #executionPlanRow {
                background: #191e28;
                border: 1px solid #2a313d;
                border-radius: 7px;
            }

            #executionPlanTitle {
                color: #dfe3e9;
                font-weight: 700;
                min-width: 125px;
            }

            #readinessCenter {
                background: #151a23;
                border: 1px solid #2a303c;
                border-radius: 11px;
            }

            #readinessItem {
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 7px;
            }

            #readinessTitle {
                color: #dce0e7;
                font-weight: 650;
            }

            #readinessReady {
                color: #91d0b3;
                font-size: 15px;
                font-weight: 800;
            }

            #readinessWarning {
                color: #e4a94d;
                font-size: 15px;
                font-weight: 800;
            }

            #readinessBlocking {
                color: #dc7181;
                font-size: 15px;
                font-weight: 800;
            }

            #pill_warning {
                background: #3a2e1c;
                border: 1px solid #6a5130;
                border-radius: 10px;
                color: #e9b967;
                font-size: 9px;
                font-weight: 800;
                padding: 5px 8px;
            }

            #pill_blocked {
                background: #3b2229;
                border: 1px solid #6b3945;
                border-radius: 10px;
                color: #e99aaa;
                font-size: 9px;
                font-weight: 800;
                padding: 5px 8px;
            }


            #pipelineBanner {
                background: #181d27;
                border: 1px solid #303744;
                border-radius: 10px;
            }

            #pipelineWorkflow {
                color: #ffffff;
                font-size: 14px;
                font-weight: 780;
                letter-spacing: 0.3px;
            }

            #pipelineRow {
                background: #191e28;
                border: 1px solid #2a313d;
                border-radius: 8px;
            }

            #pipelineActive {
                background: #202633;
                border: 1px solid #454e5e;
                border-radius: 8px;
            }

            #pipelineNumber {
                color: #9d95ff;
                font-weight: 800;
            }

            #pipelineTitle {
                color: #e8ebef;
                font-size: 13px;
                font-weight: 700;
            }

            #pipelineConnector {
                color: #4b5362;
            }

            /* ============================================================
               RESULT
               ============================================================ */

            #resultMetric {
                background: #1b202a;
                border: 1px solid #2b323e;
                border-radius: 8px;
            }

            #resultValue {
                color: #e6e9ee;
                font-size: 17px;
                font-weight: 750;
            }

            /* ============================================================
               LOGS
               ============================================================ */

            #logDrawer {
                background: #13171f;
                border-top: 1px solid #2a303c;
            }

            #logEditor,
            #pipelineOutput {
                background: #171c25;
                border: 1px solid #2b323e;
                border-radius: 8px;
                color: #abb3c0;
                font-family: Consolas, "Cascadia Mono", monospace;
                font-size: 11px;
                padding: 8px;
            }

            #logFilter,
            #smallButton {
                background: #1d232e;
                border: 1px solid #2e3542;
                border-radius: 6px;
                color: #aeb5c1;
                padding: 5px 9px;
            }

            #logFilter:hover,
            #smallButton:hover {
                background: #252c38;
            }

            /* ============================================================
               STATUS
               ============================================================ */

            #statusBar {
                background: #151923;
                border-top: 1px solid #2a303c;
                color: #747d8d;
                font-size: 10px;
            }

            #statusReady {
                color: #91d0b3;
                font-weight: 700;
            }

            #statusSeparator {
                color: #3d4552;
            }

            #statusLogs {
                color: #a59dff;
                font-weight: 700;
            }

            /* ============================================================
               BUTTONS
               ============================================================ */

            QPushButton,
            QToolButton {
                background: #1d232e;
                border: 1px solid #303744;
                border-radius: 7px;
                color: #d8dce3;
                padding: 8px 12px;
            }

            QPushButton:hover,
            QToolButton:hover {
                background: #252c38;
                border-color: #454e5d;
            }

            #primaryButton {
                background: #6f63dc;
                border: 1px solid #8177e8;
                color: #ffffff;
                font-weight: 700;
                padding: 10px 16px;
            }

            #primaryButton:hover {
                background: #7b70e6;
            }

            #secondaryButton {
                background: #1e2430;
                border: 1px solid #343c4a;
            }

            /* ============================================================
               INPUTS
               ============================================================ */

            QLineEdit,
            QComboBox {
                background: #191e27;
                border: 1px solid #303744;
                border-radius: 7px;
                color: #dce0e7;
                padding: 9px 10px;
                min-height: 18px;
            }

            QLineEdit:focus,
            QComboBox:focus {
                border-color: #575f70;
            }

            QComboBox QAbstractItemView {
                background: #1b202a;
                border: 1px solid #343b48;
                color: #e1e4ea;
                selection-background-color: #303847;
            }

            /* ============================================================
               PROGRESS
               ============================================================ */

            #fidelityBar {
                background: #222833;
                border: 1px solid #303744;
                border-radius: 5px;
                height: 7px;
            }

            #fidelityBar::chunk {
                background: #7b70e6;
                border-radius: 5px;
            }

            /* ============================================================
               TEXT / LABEL HELPERS
               ============================================================ */

            #muted,
            QLabel#muted {
                color: #7e8797;
            }

            #fieldLabel {
                color: #727b8b;
                font-size: 10px;
                font-weight: 800;
                letter-spacing: 1px;
            }

            #fieldStrong {
                color: #cdd2da;
                font-weight: 650;
            }

            #sectionSubTitle {
                color: #cfd4dc;
                font-size: 11px;
                font-weight: 800;
                letter-spacing: 1px;
            }

            #successText {
                color: #8fcdae;
                font-weight: 650;
            }

            #eyebrow {
                color: #6e7787;
                font-size: 9px;
                font-weight: 800;
                letter-spacing: 1px;
            }

            /* ============================================================
               PILLS
               ============================================================ */

            #pill_ready {
                background: #1d332b;
                border: 1px solid #315846;
                border-radius: 10px;
                color: #9ad3b5;
                font-size: 9px;
                font-weight: 800;
                padding: 5px 8px;
            }

            #pill_running {
                background: #29263e;
                border: 1px solid #514b79;
                border-radius: 10px;
                color: #b6adff;
                font-size: 9px;
                font-weight: 800;
                padding: 5px 8px;
            }

            #pill_preview {
                background: #28233d;
                border: 1px solid #463c68;
                border-radius: 10px;
                color: #b4abff;
                font-size: 9px;
                font-weight: 800;
                padding: 5px 8px;
            }

            #pill_neutral {
                background: #222832;
                border: 1px solid #303744;
                border-radius: 10px;
                color: #8e97a6;
                font-size: 9px;
                font-weight: 800;
                padding: 5px 8px;
            }

            /* ============================================================
               SCROLLBARS
               ============================================================ */

            QScrollBar:vertical {
                background: #11151c;
                border: none;
                width: 9px;
                margin: 2px;
            }

            QScrollBar::handle:vertical {
                background: #353d4b;
                border-radius: 4px;
                min-height: 35px;
            }

            QScrollBar::handle:vertical:hover {
                background: #465062;
            }

            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0;
            }

            /* ============================================================
               EMPTY
               ============================================================ */

            #emptyState {
                background: #181d27;
                border: 1px dashed #363e4c;
                border-radius: 9px;
            }

            #emptyTitle {
                color: #dce0e7;
                font-weight: 700;
            }

            #configurationSummary,
            #projectIntelligence,
            #capabilityMatrix {
                background: #151a23;
                border: 1px solid #2a303c;
                border-radius: 11px;
            }

            #configSummaryValue {
                color: #cdd2da;
                font-size: 11px;
            }

            #configSummaryModules {
                color: #aeb6c4;
                font-size: 11px;
                line-height: 1.4;
            }

            #presetCard {
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 8px;
            }

            #presetCard:hover {
                background: #1e2430;
                border-color: #414a59;
            }

            #presetTitle {
                color: #dfe3e9;
                font-weight: 700;
            }

            #intelligenceMetric,
            #intelligenceCategory,
            #capabilityRow {
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 7px;
            }

            #intelligenceValue {
                color: #e8ebef;
                font-size: 16px;
                font-weight: 760;
            }

            #capabilityRow:hover {
                background: #1e2430;
            }

            /* ============================================================
               DIALOG
               ============================================================ */

            QDialog {
                background: #11151c;
            }

            #dialogTitle {
                color: #ffffff;
                font-size: 22px;
                font-weight: 780;
            }

            #expertCard {
                background: #191e28;
                border: 1px solid #2b323e;
                border-radius: 8px;
            }

            #expertTitle {
                color: #dce0e7;
                font-size: 13px;
                font-weight: 700;
            }

            /* ============================================================
               RESULT + ACTIVITY TIMELINE
               ============================================================ */

            #resultHero {
                background: #171c25;
                border: 1px solid #303746;
                border-radius: 12px;
            }

            #resultCheck {
                color: #8fd0b2;
                font-size: 44px;
                font-weight: 800;
                line-height: 1;
            }

            #resultSuccess {
                color: #f1f4f8;
                font-size: 21px;
                font-weight: 800;
                letter-spacing: 0.7px;
            }

            #resultTarget {
                color: #dce2ea;
                font-size: 14px;
                font-weight: 650;
            }

            #resultMetricLarge {
                background: #191f29;
                border: 1px solid #2b3341;
                border-radius: 9px;
            }

            #resultMetricNumber {
                color: #ffffff;
                font-size: 24px;
                font-weight: 800;
            }

            #resultValidationIcon {
                color: #8fd0b2;
                font-size: 15px;
                font-weight: 800;
            }

            #resultWarningNumber {
                color: #e4b56f;
                font-size: 32px;
                font-weight: 800;
            }

            #activityTimeline,
            #activityDetail {
                background: #151a22;
                border: 1px solid #2b3340;
                border-radius: 8px;
                color: #d8dde6;
            }

            #activityTimeline {
                padding: 5px;
            }

            #activityTimeline::item {
                padding: 8px 10px;
                border-radius: 6px;
            }

            #activityTimeline::item:selected {
                background: #242b38;
                color: #ffffff;
            }

            #activityTimeline::item:hover {
                background: #1d232d;
            }

            #activityDetail {
                padding: 10px;
            }

            /* ============================================================
               SHELL CONTROLS / RESIZABLE DRAWERS
               ============================================================ */

            #sidebarToggle,
            #panelToggle {
                background: #1d232e;
                border: 1px solid #303744;
                border-radius: 6px;
                color: #aeb5c2;
                padding: 5px 9px;
            }

            #sidebarToggle:hover,
            #panelToggle:hover {
                background: #252c38;
                border-color: #434c5c;
                color: #ffffff;
            }

            #shellSplitter::handle {
                background: #252c39;
                height: 7px;
            }

            #shellSplitter::handle:hover {
                background: #6f63dc;
            }
    
            /* ============================================================
               SIMPLE USER MODE
               ============================================================ */
            #simpleBrand { color: #a9a1ff; font-size: 14px; font-weight: 800; letter-spacing: 1.5px; }
            #simpleTitle { color: #ffffff; font-size: 30px; font-weight: 750; }
            #simpleSubtitle { color: #9aa2b0; font-size: 14px; }
            #simpleProgress { color: #8b7cff; font-size: 12px; font-weight: 700; padding: 9px 0; }
            #simpleStepTitle { color: #f2f4f7; font-size: 21px; font-weight: 700; }
            #simpleHelp { color: #8e97a6; font-size: 13px; }
            #simpleChoice { background: #151923; border: 1px solid #303744; border-radius: 10px; }
            #simpleChoice:hover { background: #1d232e; border-color: #6258bd; }
            #simpleChoiceTitle { color: #f2f4f7; font-size: 15px; font-weight: 700; }
            #simpleChoiceDescription { color: #8e97a6; }
            #simpleNote { background: #191e29; border: 1px solid #303744; border-radius: 9px; }
            #simpleNoteTitle { color: #9b91ff; font-weight: 700; }
            #simplePrimary { background: #6f63dc; border: 1px solid #7b70e6; border-radius: 8px; color: #ffffff; padding: 11px 22px; font-weight: 700; }
            #simplePrimary:hover { background: #7b70e6; }
            #simpleSecondary { background: #1d232e; border: 1px solid #303744; border-radius: 8px; color: #d7dbe3; padding: 9px 15px; }
            #simpleSecondary:hover { background: #252c38; border-color: #434c5c; }

            /* ============================================================
               MODE CHOOSER / LANDING
               ============================================================ */
            #chooserBrand { color: #a9a1ff; font-size: 14px; font-weight: 800; letter-spacing: 1.8px; }
            #chooserTitle { color: #ffffff; font-size: 30px; font-weight: 750; }
            #chooserSubtitle { color: #9aa2b0; font-size: 14px; max-width: 900px; }
            #chooserHint { color: #727c8c; font-size: 12px; }
            #modeCard { background: #151923; border: 1px solid #303744; border-radius: 14px; }
            #modeCard:hover { border-color: #6258bd; background: #181d27; }
            #modePreview { background: #0e1117; border: 1px solid #292f3b; border-radius: 10px; }
            #modeCardTitle { color: #f2f4f7; font-size: 18px; font-weight: 750; }
            #modeCardBadge { color: #a9a1ff; background: #242039; border: 1px solid #413b69; border-radius: 12px; padding: 4px 9px; font-size: 11px; font-weight: 700; }
            #modeCardDescription { color: #8e97a6; font-size: 13px; min-height: 38px; }
            #modeCardButton { background: #6f63dc; border: 1px solid #7b70e6; border-radius: 8px; color: #ffffff; padding: 10px 16px; font-weight: 700; }
            #modeCardButton:hover { background: #7b70e6; }
        """

        if self.theme_mode == "light":
            light = self._light_theme_stylesheet(dark_stylesheet)
            light += r"""
                #simpleBrand { color: #5147c9; }
                #simpleTitle { color: #1f2937; }
                #simpleSubtitle, #simpleHelp { color: #5f6b7a; }
                #simpleProgress { color: #5147c9; }
                #simpleStepTitle { color: #263241; }
                #simpleChoice { background: #ffffff; border-color: #d7dde6; }
                #simpleChoice:hover { background: #f4f6f9; border-color: #5147c9; }
                #simpleChoiceTitle { color: #263241; }
                #simpleChoiceDescription { color: #5f6b7a; }
                #simpleNote { background: #f4f6f9; border-color: #d7dde6; }
                #simpleNoteTitle { color: #5147c9; }
                #simpleSecondary { background: #ffffff; border-color: #cbd3df; color: #263241; }
                #chooserBrand { color: #5147c9; }
                #chooserTitle { color: #1f2937; }
                #chooserSubtitle { color: #5f6b7a; }
                #chooserHint { color: #7b8796; }
                #modeCard { background: #ffffff; border-color: #d7dde6; }
                #modeCard:hover { background: #f8f9fb; border-color: #5147c9; }
                #modePreview { background: #f4f6f9; border-color: #d7dde6; }
                #modeCardTitle { color: #263241; }
                #modeCardBadge { color: #5147c9; background: #efedff; border-color: #d8d4ff; }
                #modeCardDescription { color: #5f6b7a; }
                #modeCardButton { background: #5147c9; border-color: #5147c9; }
                #modeCardButton:hover { background: #6258d6; }
            """
            self.setStyleSheet(light)
        else:
            self.setStyleSheet(dark_stylesheet)


# ============================================================================
# APPLICATION ENTRY
# ============================================================================


def main():
    app = QApplication(sys.argv)

    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)

    window = MainWindow()
    window.show()

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
